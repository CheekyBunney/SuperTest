import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";
const API_URL = '/questions';
class QuestionService {

    getQuestions(assessmentUUID){
        return api.get(API_URL + "/UC/list/" + assessmentUUID, { headers: authHeader() });
    }

    resolveQuestion(questionUUID){
        return api.put(API_URL + "/resolve/" + questionUUID , null, { headers: authHeader() });
    }
}
export default new QuestionService();
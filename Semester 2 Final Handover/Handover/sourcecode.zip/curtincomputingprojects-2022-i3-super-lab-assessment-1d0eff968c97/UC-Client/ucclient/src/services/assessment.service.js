
import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";
const API_URL = '/assessments/';
class AssessmentService {

    getAllAssessments(){
        return api.get(API_URL + "UC/list", { headers: authHeader() });
    }

    createAssessment(name, unitCode, startsAt, duration, studentList, invigilatorList, fileList){
        const formData = new FormData()
        formData.append("name", name);
        formData.append("unitCode", unitCode)
        formData.append("startsAt", startsAt)
        formData.append("duration", duration)
        formData.append("students", studentList)
        formData.append("invigilators", invigilatorList)
        fileList.forEach(file => {
            formData.append("files", file)
        })

        return api.put(API_URL, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                ...authHeader()
            },

        })
    }
}
export default new AssessmentService();
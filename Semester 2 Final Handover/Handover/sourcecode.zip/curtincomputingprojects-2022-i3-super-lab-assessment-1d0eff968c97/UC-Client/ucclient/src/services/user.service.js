
import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";

const API_URL = '/users/';
class UserService {
    getUserDetails() {
        return api.get(API_URL, { headers: authHeader() });
    }
    getAllUsers(){
        return api.get(API_URL + "list", { headers: authHeader() });
    }
}
export default new UserService();
import { createRouter, createWebHistory } from 'vue-router'

import AuthService from "../../../../Commons/services/auth.service"
import DashboardView from "@/views/DashboardView";
import SideBarTemplate from "@/views/SideBarTemplate";

export var validRoles = ["UC", "INVIGILATOR"]

const routes = [
  {
    path: '/login',
    name: "login",
    component: () => import(/* webpackChunkName: "LoginView" */ '../views/LoginView.vue'),
  },
  //WITH SESSION
  {
    path: '/assessment/:assessment',
    name: "with_session",
    component: SideBarTemplate,
    children: [
      {
        path: '',
        name: 'assessment',

        component: () => import('../views/OngoingAssessment')
      }
    ]
  },
  //WITHOUT SESSION
  {
    path: '',
    name: "without_session",
    component: SideBarTemplate,
    children: [
      {
        path: '',
        name: 'dashboard',
        component: DashboardView
      },
      {
        path: '/assessment/create',
        name: 'createAssessment',
        component: () => import(/* webpackChunkName: "Assessment" */ '../views/CreateAssessmentView.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const publicPages = ['/login'];
  const authRequired = !publicPages.includes(to.path);
  let roles = AuthService.getRoles();
  const isLoggedIn = roles.filter(r => validRoles.includes(r)).length > 0;
  // trying to access a restricted page + not logged in
  // redirect to login page
  if (authRequired && !isLoggedIn) {
    next('/login');
  } else {
    next();
  }

})
export default router

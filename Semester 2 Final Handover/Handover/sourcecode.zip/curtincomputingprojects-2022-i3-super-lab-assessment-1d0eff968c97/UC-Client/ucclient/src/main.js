import { createApp } from 'vue'
import '@fortawesome/fontawesome-free/js/all'
import App from './App.vue'
import router from './router/router'
import store from './store/store'
import {BootstrapVue3} from 'bootstrap-vue-3'
import  'boostrap-scss/boostrap-custom.scss'
import VueSidebarMenu from 'vue-sidebar-menu'
import 'vue-sidebar-menu/dist/vue-sidebar-menu.css'
import setupInterceptors from "../../../Commons/axios/setupInterceptors";
import 'tinyduration'
import 'moment'
import Toast from "vue-toastification"
import "vue-toastification/dist/index.css"
setupInterceptors(store);
// library.add(fas)
createApp(App)
    .use(store)
    .use(router)
    .use(BootstrapVue3)
    .use(Toast)
    .use(VueSidebarMenu)
    .mount('#app')

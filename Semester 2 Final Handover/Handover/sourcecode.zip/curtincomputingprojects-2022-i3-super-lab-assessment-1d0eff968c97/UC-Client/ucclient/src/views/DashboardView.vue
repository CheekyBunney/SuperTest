<script>
import AssessmentCard from "@/components/AssessmentCard";
import AssessmentService from "../services/assessment.service"
import UserService from "@/services/user.service";
import dueAssessmentCard from "@/components/DueAssessmentCard";
import NotificationsBarUC from "@/components/bars/notificationsBar/NotificationsBarUC";
import { notificationsBarWidth } from "../../../../Commons/NotificationsBar-Commons/state";
import {parse} from "tinyduration";

export default {
  name: 'App',
  components: {
    AssessmentCard,
    dueAssessmentCard,
    NotificationsBarUC
  },
  data(){
    return{
      allAssessments:[],
      userDetails:{},
      notificationsBarWidth
    }
  },
  mounted() {
    AssessmentService.getAllAssessments().then(res => {
      this.allAssessments = res.data;
    })
    UserService.getUserDetails().then(res => {
      this.userDetails = res.data;
    })
  },
  methods:{
    getPastAssessments(){
      return this.$data.allAssessments.filter(ass => (new Date(ass.startsAt)) < new Date())
    },
    getUpcomingAssessments(){
      return this.$data.allAssessments.filter(ass => (new Date(ass.startsAt)) >= new Date())
    },
    getDueAssessment(){
      return this.$data.allAssessments.filter(ass => {
        var duration = parse(ass.duration)
        //get dates
        var startDate = new Date(ass.startsAt);
        var endDate = new Date(ass.startsAt);
        //adjust endDate based off of duration
        if(duration.hours){
          endDate.setHours(endDate.getHours() + duration.hours);
        }
        if(duration.minutes){
          endDate.setMinutes(endDate.getMinutes() + duration.minutes);
        }
        var now = new Date(Date.now())
        //start time is before the actual start time to show countdown
        var minShowTime = new Date(Date.now());
        minShowTime.setHours(minShowTime.getHours() - 1);

        return startDate >= minShowTime &&  now < endDate
      });
    },
    goToCreateAssessment(){
        this.$router.push("/assessment/create");
    }
  }
}
</script>


<template>

  <div class="content">

    <!-- main view column -->
    <div
        class="column view-body"
        :style="{ 'margin-right': notificationsBarWidth }">

      <div class="Dashboard View">
        <b-card no-body class="text-center border-0">
          <div class="text-dark">
            <h1 style="color:#507DBC">Welcome!</h1>
          </div>
        </b-card>
      </div>

      <!--Staff info and upcoming assessments cards-->
      <div class="info-cards">
        <b-card-group deck>
          <b-card class="text-white bg-secondary border-0">
            <b-card-text class="text-center">
              <h1>{{userDetails.firstName}} {{userDetails.lastName}}</h1>
            </b-card-text>
            <b-card-text class="text-center">
              <h4>Staff ID: {{userDetails.curtinId}}</h4>
            </b-card-text>
          </b-card>
          <b-card title="Due Assessments" class="bg-light border-0">
            <dueAssessmentCard v-for="assessment in getDueAssessment()"
                               :key="assessment.uuid"
                               :assessment="assessment"/>
          </b-card>
        </b-card-group>
      </div>

      <b-card no-body class="create">
        <b-button
            variant="secondary"
            class="text-white"
            @click="goToCreateAssessment"
        >+  Create Assessment
        </b-button>
      </b-card>

      <b-card class="info-cards bg-primary text-white" title="Future Assessments">
        <div>
          <b-card no-body class="text-white bg-transparent m-0 border-0">
            <b-row>
              <b-col>Unit Name</b-col>
              <b-col>Unit Code</b-col>
              <b-col>Duration</b-col>
              <b-col>Start Date</b-col>
            </b-row>
          </b-card>
          <AssessmentCard
              v-for="assessment in getUpcomingAssessments()"
              :key="assessment.uuid"
              :assessment="assessment"/>
        </div>

      </b-card>
      <b-card class="info-cards bg-primary my-3 text-white" title="Past Assessments">
        <div>
          <b-card no-body class="text-white bg-transparent m-0 border-0">
            <b-row>
              <b-col>Unit Name</b-col>
              <b-col>Unit Code</b-col>
              <b-col>Duration</b-col>
              <b-col>Start Date</b-col>
            </b-row>
          </b-card>
          <AssessmentCard v-for="assessment in getPastAssessments()"
                          :key="assessment.uuid"
                          :assessment="assessment"/>
        </div>
      </b-card>
    </div>

    <!-- notification bar column -->
    <div class="column notification-bar">

      <NotificationsBarUC
          :withSession="false"/>
    </div>
  </div>
</template>


<style>

.column{
  height: 100%;
  box-sizing: border-box;
}
.view-body{
  height: 100%;
  max-width: 100%;
}
.info-cards{
  margin: 15px 150px 15px 150px;
  width: available;
  text-align: left;
  border: 0;
  opacity: 0.9;
}
.create{
  width:available;
  margin: 15px 150px 15px 150px;
}

.notification-bar{
  height: 100%;
}

.content:after {
  content: "";
  display: table;
  clear: both;
}
</style>


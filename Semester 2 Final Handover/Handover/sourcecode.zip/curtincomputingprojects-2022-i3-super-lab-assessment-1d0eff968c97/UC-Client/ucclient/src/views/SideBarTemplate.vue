<script>

import SideBarUC from "@/components/bars/sidebar/SideBarUC";
import { sidebarWidth } from "../../../../Commons/Sidebar-Commons/state";

export default {
  components: { SideBarUC },
  setup() {
    return { sidebarWidth }
  }
}
</script>


<template>

  <SideBarUC/>

  <div :style="{ 'margin-left': sidebarWidth }">
    <router-view />
  </div>


</template>

<style>
#nav {
  padding: 30px;
  /*test words*/
}
#nav a {
  font-weight: bold;
  color: #2c3e50;
}
#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
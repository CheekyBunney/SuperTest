<script>

import AssessmentService from "../services/assessment.service";
import timerComponent from "@/components/timerComponent";
import NotificationsBarUC from "@/components/bars/notificationsBar/NotificationsBarUC";
import { notificationsBarWidth } from "../../../../Commons/NotificationsBar-Commons/state";
import {parse} from "tinyduration";
import ToastNotificationService from "@/services/toast.notification.service";

export default {
  name: "App",
  components: {
    timerComponent,
    NotificationsBarUC
  },

  data() {
    return {
      allAssessments: [],
      ongoingAssessment: [],
      notificationsBarWidth
    }
  },

  //called after the OngoingAssessment view is mounted
  mounted() {
    //gets all assessments
    AssessmentService.getAllAssessments().then(res => {
      this.allAssessments = res.data;
    });
    this.getOngoingAssessment();
  },

  //all methods involved with the OngoingAssessment view
  methods: {
    getOngoingAssessment() {
      return this.$data.allAssessments.filter((ass => ((new Date(ass.startsAt)-new Date())/60000+(parse(ass.duration).hours*60) + (parse(ass.duration).minutes)) >= 0 && ((new Date(ass.startsAt)-new Date())/60000) <= 1))
    },
    doSaveNotification() {
      ToastNotificationService.doSaveNotification();
    }
  }
};
</script>


<template>

  <div class="content">

    <!-- main view column -->
    <div
        class="column view-body"
        :style="{ 'margin-right': notificationsBarWidth }">

      <!-- timer component -->
      <div class="timer-component">

        <timerComponent v-for="assessment in getOngoingAssessment()"
                        :key="assessment.uuid"
                        :assessment="assessment"/>
      </div>

      <div class="close-button-tray">

        <b-card class="close-assessment-button">

          <b-button variant="primary" class="text-white" href="/">Close</b-button>
        </b-card>
      </div>
    </div>

    <!-- notification bar column -->
    <div class="column notification-bar">

      <NotificationsBarUC
          :withSession="true"/>
    </div>
  </div>
</template>

<style>

/*DEBUG*/
/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

body {
  background-color: #fff;
}

.column{
  height: 100%;
  box-sizing: border-box;
}
.view-body{
  height: 100%;
  max-width: 100%;
}
.timer-component{
  margin-bottom: 50px;
}
.close-button-tray{
  width: 100%;
  margin: auto;
}
.close-assessment-button{
  border: none;
}

.notification-bar{
  height: 100%;
}

.content:after {
  content: "";
  display: table;
  clear: both;
}
</style>

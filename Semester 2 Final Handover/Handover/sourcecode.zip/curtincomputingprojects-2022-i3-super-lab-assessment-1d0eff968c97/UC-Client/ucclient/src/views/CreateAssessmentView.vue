<script>
import AssessmentService from "@/services/assessment.service";
import {serialize} from "tinyduration";
import {toRaw} from "vue"
import ToastNotificationService from "@/services/toast.notification.service";
import {useToast} from "vue-toastification";

export default {
  data() {
    return {
      invigilators:[],
      students:[],
      assessmentFiles:[],
    }
  },
  //calls after the view is mounted
  mounted() {

    //adds event listeners to each button
    this.addButtonListener('input-staff-id', 'add-staff-button');
    this.addButtonListener('input-student-id', 'add-student-button');
  },

  methods: {

    //adds event listeners to buttons
    addButtonListener(inputID, buttonID) {
      //adds event listener on ENTER key to press ADD button
      const input = document.getElementById(inputID);
      input.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
          event.preventDefault();
          document.getElementById(buttonID).click();
        }
      });
    },

    //adds individual IDs to UI ID list element
    addIndividualID(inputID, listID) {

      //creates new list element
      let listItem = document.createElement("li");
      const itemValue = document.getElementById(inputID).value;

      //validation
      if (itemValue === '') {
        ToastNotificationService.pushNotification("Please insert ID Number");
      }else {

        //appends list UI element and adds close button
        this.appendList(itemValue, listItem, listID);
      }

      //resets ID input to blank
      document.getElementById(inputID).value = "";
    },

    //selects which list is to be appended to
    getDataListFromListID(listID) {
      return listID === "staff-id-list" ? this.invigilators : this.students;
    },

    //takes in uploaded PDF file to display titles in UI list elements
    uploadPDFFile(assessmentFileID) {

      //creates new list element
      const listItem = document.createElement("li");

      const fileElement = document.getElementById(assessmentFileID);
      const file = fileElement.files[0];
      const fileName = file.name;

      const textNode = document.createTextNode(fileName);

      this.assessmentFiles.push(file);

      //appends list UI element
      listItem.appendChild(textNode);
      document.getElementById('assessment-files-list').appendChild(listItem);

      //creates close button for list element
      this.addCloseButton(listItem);
    },

    //validation for CSV file uploads
    uploadCSVFile(listFileID, listID) {

      const fileInput = document.getElementById(listFileID);
      const file = fileInput.value;

      //allow for only csv files
      const allowedExtensions = /(\.csv)$/i;

      //if not a CSV file, ToastNotificationService.pushNotification the user
      if (!allowedExtensions.exec(file)) {

        ToastNotificationService.pushNotification('Invalid file type');
        fileInput.value = '';
      }
      //otherwise, read CSV file to add IDs to list
      else {

        //starts new file reader
        const reader = new FileReader();

        reader.onload = () => {

          //splits csv text on comma or new line
          const IDList = reader.result.split(/[,\n]+/);

          //for each list element in file
          for(let i = 0; i < IDList.length - 1; i++) {

            //creates new list element
            let listItem = document.createElement("li");
            const itemValue = IDList[i];

            //checks if array already includes the to be added list element
            let old = true;
            for(let j = 0; j < (this.getDataListFromListID(listID).length); j++) {

              //if the strings are equal, it is a duplicate ID
              if (itemValue === this.getDataListFromListID(listID)[j]) {
                old = false;
              }
            }
            if(old) {
              //appends list UI element, including close button
              this.appendList(itemValue, listItem, listID);
            }
          }
        }
        //starts reading the file, then calls above onload event
        reader.readAsText(fileInput.files[0]);
      }
    },

    //appends the appropriate list with the appropriate element
    appendList(itemValue, listItem, listID) {

      //appends list UI element
      const textNode = document.createTextNode(itemValue);
      listItem.appendChild(textNode);
      document.getElementById(listID).appendChild(listItem);

      //adds ID to appropriate ID array
      this.getDataListFromListID(listID).push(itemValue);

      //creates close button for list element
      this.addCloseButton(listItem)
    },

    //creates close button for list element
    addCloseButton(listItem) {

      let span = document.createElement("SPAN");
      const txt = document.createTextNode("\u00D7");
      span.className = "close";
      span.appendChild(txt);
      listItem.appendChild(span);

      span.onclick = () => this.onCloseButtonClick(span);
    },

    onCloseButtonClick(span) {
      //parent div to be removed
      let listItemElement = span.parentElement;
      let listElement = listItemElement.parentElement;

      //temp copy of list
      let IDList = this.getDataListFromListID(listElement.id);

      //removes single ID from array
      for(let i = 0; i < IDList.length; i++) {

        //if the list elements are equal
        if( (IDList[i] - "\r").toString() === listItemElement.innerText.split("\n")[0]) {
          //removes element from list
          IDList.splice(i, 1);
        }
      }
      //gets rid of that list element in the UI
      listItemElement.style.display = "none";
    },

    //submits form for creation
    submitForm() {
      //method fields
      let unitCode, assessmentName, date, startTime, duration;
      let staffList, studentList, assessmentFiles;

      //field initialisation
      //TEXT
      unitCode = document.getElementById("unit-code").value;
      // unitName = document.getElementById("unit-name").value;
      assessmentName = document.getElementById("assessment-name").value;
      date = document.getElementById("assessment-date").value;
      startTime = document.getElementById("assessment-start-time").value;
      duration = document.getElementById("assessment-duration").value;

      //LISTS
      staffList = this.invigilators
      studentList = this.students

      //FILES
      assessmentFiles = toRaw(this.assessmentFiles)

      //validation
      if(unitCode == null || unitCode === "") {
        ToastNotificationService.shortNotification("Must include unit code");
      }else if(assessmentName == null || assessmentName === "") {
        ToastNotificationService.shortNotification("Must include assessment name");
      }else if(date == null || date === "") {
        ToastNotificationService.shortNotification("Must include assessment date");
      }else if(startTime == null || startTime === "") {
        ToastNotificationService.shortNotification("Must include assessment start time");
      }else if(duration == null || duration === "") {
        ToastNotificationService.shortNotification("Must include assessment duration");
      }
      else if(studentList.length === 0) {
        ToastNotificationService.shortNotification("Must include list of students");
      }else if(document.getElementById("assessment-files-list").innerHTML.trim() === "") {
        ToastNotificationService.shortNotification("Must include assessment files");
      }
      else {

        //attempts to create assessment
        try {

          //converts duration to ints (minutes and hours)
          let durationMins = parseInt(duration);

          //creates a Duration obj from string
          const durationObj = serialize({minutes:durationMins});

          //converts start time to Date obj
          const startsAtDate = new Date(date + 'T' + startTime);
          if(startsAtDate < Date.now()){
            alert("the assessment cannot begin in the past")
          }

          //calls backend createAssessment function
          AssessmentService.createAssessment(assessmentName, unitCode, startsAtDate, durationObj, staffList, studentList, assessmentFiles)
              .then(() => {
                const toast = useToast();
                toast.info("Assessment Created!", {
                  timeout: 2000,
                  showCloseButtonOnHover: true,
                  pauseOnFocusLoss: false
                });
              }).catch(() => {
                const toast = useToast();
                toast.info("Failed to create assessment", {
                  timeout: 2000,
                  showCloseButtonOnHover: true,
                  pauseOnFocusLoss: false
                });
          })
        }
        catch(err) {
          ToastNotificationService.pushNotification(err.message);
        }
      }
    }
  }
}
</script>

<template>

  <!-- view header -->
  <h1 class="view-header">Create Assessment</h1>

  <!-- Card Deck -->
  <div class="details-deck">

    <!-- Details Card -->
    <b-card no-body class="text-white details-card">

      <!-- Details Card Heading -->
      <h1 class="card-headers">Details</h1>

        <!-- First Row -->
        <b-container fluid >
          <b-row class="details-card-content">

            <!-- Unit Code Input -->
            <b-col>
              <b-form-group id="input-unit-code">
                <label for="unit-code">Unit Code:</label>
                <b-form-input id="unit-code" placeholder="Unit Code"
                ></b-form-input>
              </b-form-group>
            </b-col>

            <!-- Unit Name Input -->
            <b-col cols="8">
              <b-form-group>
                <label for="unit-name">Unit Name:</label>
                <b-form-input id="unit-name" placeholder="Unit Name"
                ></b-form-input>
              </b-form-group>
          </b-col>
          </b-row>

        <!-- Second Row -->
        <b-row class="details-card-content">

          <!-- Assessment Name Input -->
          <b-form-group>
            <label for="assessment-name">Assessment Name:</label>
            <b-form-input id="assessment-name" placeholder="Assessment Name"
            ></b-form-input>
          </b-form-group>
        </b-row>

        <!-- Third Row -->
          <b-row class="details-card-content">

            <!-- Date Input -->
            <b-col>
              <b-form-group>
                <label for="input-assessment-date">Date:</label>
                <form class="details-forms" id="input-assessment-date">
                  <input class="details-inputs" type="text" id="assessment-date" placeholder="DD/MMM/YYYY" onfocus="(this.type='date')">
                </form>
              </b-form-group>
            </b-col>

            <!-- Start Time Input -->
            <b-col>
              <b-form-group>
                <label for="input-assessment-start-time">Start Time:</label>
                <form class="details-forms" id="input-assessment-start-time">
                  <input class="details-inputs" type="text" id="assessment-start-time" placeholder="HH:MM" onfocus="(this.type='time')">
                </form>
              </b-form-group>
            </b-col>

            <!-- Duration Input -->
            <b-col>
              <b-form-group>
                <label for="input-assessment-duration">Duration:</label>
                <form class="details-forms" id="input-assessment-duration">
                  <input class="details-inputs" type="text" id="assessment-duration" step="5" placeholder="Minutes" onfocus="(this.type='number')">
                </form>
              </b-form-group>
            </b-col>
          </b-row>
        </b-container>
    </b-card>

    <!-- Staff Card -->
    <b-card no-body class="text-light add-ids-card" bg-variant="primary">

      <!-- Staff Card Heading -->
      <h1 class="card-headers">Staff</h1>
      <b-row class="add-ids-card-content">

        <!-- Staff File Upload -->
        <b-col>
          <div class="file-upload-box">
            <b-form-group>
              <form id="input-invigilator-list">

                <div class="file-upload-text">
                  <!-- icon and prompt text -->
                  <i class="fas fa-upload"></i>
                  <h1 class="file-upload-label">Click below to<br/>upload CSV file</h1>
                </div>

                <!-- file upload button -->
                <input
                    class="file-upload-button"
                    type="file"
                    id="staff-list-file"
                    @change="uploadCSVFile('staff-list-file', 'staff-id-list')"
                >
              </form>
            </b-form-group>
          </div>
        </b-col>

        <!-- Individual Staff Add -->
        <b-col>
          <b-row id="add-individual-staff">

            <!-- label -->
            <label for="input-staff-id">Add Staff Member</label>

            <!-- Input Staff ID -->
            <b-col cols="10">
              <b-form-input class="input-individual-id" id="input-staff-id" placeholder="Staff ID"></b-form-input>
            </b-col>

            <!-- Add Staff Button -->
            <b-col cols="2">
              <button
                  id="add-staff-button"
                  class="add-button"
                  @click="addIndividualID('input-staff-id', 'staff-id-list')">Add
              </button>
            </b-col>
          </b-row>

          <!-- Staff ID List -->
          <b-row>
            <div class="list-box"/>
            <ul
                class="list staff-id-list"
                id="staff-id-list"
            />

          </b-row>
        </b-col>
      </b-row>
    </b-card>

    <!-- Students Card -->
    <b-card no-body class="text-light add-ids-card" bg-variant="primary">

      <!-- Students Card Heading -->
      <h1 class="card-headers">Students</h1>
      <b-row class="add-ids-card-content">

        <!-- Students File Upload -->
        <b-col>
          <div class="file-upload-box">
            <b-form-group>
              <form id="input-student-list">

                <div class="file-upload-text">
                  <!-- icon and prompt text -->
                  <i class="fas fa-upload"></i>
                  <h1 class="file-upload-label">Click below to<br/>upload CSV file</h1>
                </div>

                <input
                    class="file-upload-button"
                    type="file"
                    id="student-list-file"
                    @change="uploadCSVFile('student-list-file', 'student-id-list')"
                >
              </form>
            </b-form-group>
          </div>
        </b-col>

        <!-- Individual Student Add -->
        <b-col>
          <label for="add-individual-student">Add Student</label>
          <b-row id="add-individual-student">

            <!-- Input Student ID -->
            <b-col cols="10">
              <b-form-input class="input-individual-id" id="input-student-id" placeholder="Student ID"></b-form-input>
            </b-col>

            <!-- Add Button -->
            <b-col cols="2">
              <button
                  id="add-student-button"
                  class="add-button"
                  @click="addIndividualID('input-student-id', 'student-id-list')">Add
              </button>
            </b-col>
          </b-row>

          <!-- Student ID List -->
          <b-row>
            <div class="list-box"/>
            <ul
                class="list student-id-list"
                id="student-id-list"
            />
          </b-row>
        </b-col>
      </b-row>
    </b-card>

    <!-- Assessment Files Card -->
    <b-card no-body class="text-light add-ids-card" bg-variant="primary">

      <!-- Assessment Files Card Heading -->
      <h1 class="card-headers">Assessment Files</h1>
      <b-row class="add-ids-card-content">

        <!-- Assessment Files Upload -->
        <b-col>
          <div class="file-upload-box">
            <b-form-group>
              <form id="input-assessment-files-list">

                <div class="file-upload-text">
                  <!-- icon and prompt text -->
                  <i class="fas fa-upload"></i>
                  <h1 class="file-upload-label">Click below to<br/>upload PDF file</h1>
                </div>

                <input
                    class="file-upload-button"
                    type="file"
                    id="assessment-files"
                    @change="uploadPDFFile('assessment-files')"
                    multiple
                >
              </form>
            </b-form-group>
          </div>
        </b-col>

        <b-col>
          <!-- Assessment Files List -->
          <b-row>
            <label for="assessmentListBox">Assessment Files List</label>
            <div class="list-box assessment-list-box" id="assessmentListBox"/>
            <ul
                class="list assessment-files-list"
                id="assessment-files-list"
            />
          </b-row>
        </b-col>
      </b-row>
    </b-card>
  </div>

  <!-- button tray -->
  <div class="button-tray">

    <!-- back button -->
    <button
        class="form-button back-button"
        @click="$router.go(-1)"
    >
      <b>Back</b>
    </button>

    <!-- submit button -->
    <button
        class="form-button submit-button"
        @click="submitForm()"
    >
      <b>Submit</b>
    </button>
  </div>
</template>



<style>

/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.view-header{
  color: #507DBC;
  margin-top: 30px;
  font-size: 48px;
}

/* Deck */
.details-deck{
  margin: 30px 150px;
  width: available;
}
.card-headers{
  margin-left: 20px;
  margin-top: 10px;
  font-size: 32px;
  color: white;
}

/* Details Card */
.details-card{
  text-align: left;
  margin-bottom: 30px;
  margin-top: 30px;
  background: #3685D3;
  opacity: 0.8;
}
.details-card-content{
  margin-left: 20px;
  margin-right: 20px;
  margin-bottom: 10px;
}
.details-forms{
  width: available;
  background: #FCFCFC;
  border-radius: 5px;
  padding: 5px;
}
.details-inputs{
  width: 100%;
  border: 0;
}

/* IDs Cards */
.add-ids-card{
  text-align: left;
  margin-bottom: 30px;
  margin-top: 30px;
  opacity: 0.9;
}
.add-ids-card-content{
  margin-left: 30px;
  margin-right: 30px;
}
.file-upload-text{
  margin-top: 15px;
  text-align: center;
  font-size: 24px;
  color: #507DBC;
}
.file-upload-label{
  font-size: 24px;
}
.file-upload-box{
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
  margin-bottom: 15px;
  background: #D3E1F1;
  height: 185px;
  width: 90%;
  border: 2px dashed #507DBC;
  border-radius: 15px;
}
input[type=file]::-webkit-file-upload-button {
  visibility: hidden;
}
.file-upload-button{
  color: #507DBC;
  background: #FCFCFC;
  border: 2px solid #A1C6EA;
  border-radius: 10px;
  width: 100%;
  height: 35px;
  cursor: pointer;
}

.input-individual-id{
  width: 100%;
  margin-left: -10px;
}

.add-button{
  height: 100%;
  width: 100%;
  background-color: white;
  border: 2px solid #A1C6EA;
  border-radius: 10px;
  float: right;
  color: #507DBC;
  text-align: center;
  font-size: 16px;
  margin-right: 5px;
  cursor: pointer;
}
.list-box{
  width: 97%;
  margin-top: 10px;
  margin-left: 0;
  height: 120px;
  background: #FCFCFC;
  border: 2px solid #A1C6EA;
  border-radius: 10px;
}
.assessment-list-box{
  margin-top: 0;
  height: 170px;
}
.list{
  padding: 10px 0 0 10px;
  margin: -115px 5px 5px 5px;
  height: 110px;
  color: #507DBC;
  overflow: auto;
  list-style-type: none;
}

.assessment-files-list{
  height: 160px;
  margin: -165px 10px 5px 5px;
}

.list li {
  font-size: 18px;
  width: 95%;
  padding-left: 10px;
}
.list li:nth-child(odd) {
  background: #EEEEEE;
}

/*eslint-disable-next-line no-unused-vars*/
.close {
  float: right;
  padding: 0 8px;
  cursor: pointer;
}

.close:hover {
  background-color: #CA968F;
  color: white;
}

/* BUTTONS */
.button-tray{
  height: 75px;
  margin-left: 150px;
  margin-right: 150px;
}
.form-button{
  color: #FCFCFC;
  width: 150px;
  border: 2px solid #8BA9D3;
  border-radius: 10px;
  padding: 10px;
}
.back-button{
  float: left;
  background: #CA968F;
  opacity: 90%;
}
.submit-button{
  float: right;
  background: #507DBC;
  opacity: 80%;
}

.list::-webkit-scrollbar {
  width: 10px;
}

/* Track */
.list::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px #8BA9D3;
  border-radius: 10px;
}

/* Handle */
.list::-webkit-scrollbar-thumb {
  background: #FCFCFC;
  border-radius: 10px;
}

/* Handle on hover */
.list::-webkit-scrollbar-thumb:hover {
  background: #EEEEEE;
}

</style>
<script>

//imports
import { collapsed, toggleNotificationsBar, notificationsBarWidth } from '../../../../../../Commons/NotificationsBar-Commons/state'
import NBTabButtons from "../../../../../../Commons/NotificationsBar-Commons/NBTabButtons";
import NBTabContent from "../../../../../../Commons/NotificationsBar-Commons/NBTabContent";

export default {
  name: "NotificationsBarUC",
  props: [
      'withSession'
  ],
  components: {
    NBTabButtons,
    NBTabContent
  },

  //all data involved with the Notifications Bar view
  data() {
    return{
      showBadge: true,
      clientName: 'UC',
      userDetails: {},
      allIncomingMessages: [],
      newIncomingMessages: [],
      allOutgoingMessages: []
    }
  },

  //called after the Notifications Bar view is mounted
  mounted() {
    //adds event listener to check for click outside notification bar
    document.addEventListener('click', event => {
      //check to see if element exists
      if(document.getElementById('notificationsBarUC') !== null) {
        const isClickInside = document.getElementById('notificationsBarUC').contains(event.target);
        //collapses bar if click outside is detected
        if (!isClickInside) {
          //if bar not already collapsed
          if (!collapsed.value) {
            //toggles bar to collapsed state
            toggleNotificationsBar();
            //sets all tab buttons to inactive state
            let tabButtons = document.getElementsByClassName("tab-buttons");
            for (let i = 0; i < tabButtons.length; i++) {
              tabButtons[i].className = tabButtons[i].className.replace(" active", "");
            }
            //sets all tab contents to invisible
            let tabContent = document.getElementsByClassName("tab-content");
            for (let i = 0; i < tabContent.length; i++) {
              tabContent[i].style.display = "none";
            }
            //sets notification badge to invisible
            this.showBadge = true;
            this.clearNewIncomingMessages();
          }
        }
      }
    });
  },

  //called after Notifications Bar is set up
  setup() {
    return { collapsed, toggleNotificationsBar, notificationsBarWidth }
  },

  //all methods involved with the Notifications Bar
  methods:{

    //updates the question list when UC makes an announcement
    updateOutgoingMessages(announcement) {
      this.allOutgoingMessages.push(announcement);
      console.log("new UC Announcement created: " + announcement.message);
    },

    //updates the notification lists when api is polled
    updateIncomingMessages(studentQuestion) {
      this.newIncomingMessages.push(studentQuestion);
    },

    //sets notification badge's visibility
    setBadgeVisibility(isVisible) {
      this.showBadge = isVisible;
    },

    //clears new notifications
    clearNewIncomingMessages() {
      //adds new notifications to all notifications list
      this.newIncomingMessages.forEach(message => this.allIncomingMessages.push(message));
      //clears new notifications list
      this.newIncomingMessages.length = 0;
    }
  }
}
</script>

<!-- TEMPLATE -->
<template>

  <!-- notifications bar -->
  <div
      class="notifications-bar"
      :style="{ width: notificationsBarWidth }"
      id="notificationsBarUC">

    <!-- content -->
    <div class="content">

      <!-- tab buttons -->
      <div class="column tabs-col">

        <NBTabButtons
            :withSession="withSession"
            :showBadge="showBadge"
            :clientName="clientName"
            :numNotifications="newIncomingMessages.length"/>
      </div>

      <!-- body -->
      <div
          class="column body-col"
          id="bodyColumn">

        <NBTabContent
            :clientName="clientName"
            :allIncomingMessages="allIncomingMessages"
            :newIncomingMessages="newIncomingMessages"
            :allOutgoingMessages="allOutgoingMessages"
            @updateOutgoingMessages="updateOutgoingMessages"
            @updateIncomingMessages="updateIncomingMessages"/>
      </div>
    </div>
  </div>
</template>

<style>
:root {
  --notificationsBar-bg-color: #8BA9D3;
}
</style>

<style scoped>

/*DEBUG*/
/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/


.notifications-bar {
  color: white;
  background-color: var(--notificationsBar-bg-color);
  float: left;
  position: fixed;
  z-index: 1;
  top: 0;
  right: 0;
  bottom: 0;
  transition: 0.2s ease;
  display: flex;
  flex-direction: column;
  border-bottom-left-radius: 20px;
  border-top-left-radius: 20px;
}

.content{
  height: 100%;
}

/*COLUMNS*/
.column{
  height: 100%;
  box-sizing: border-box;
  float: left;
}
.tabs-col{
  height: 100%;
  width: 60px;
}
.body-col{
  background: #507DBC;
  height: 100%;
  width: 85%;
  border-bottom-left-radius: 20px;
  border-top-left-radius: 20px;
  box-shadow: -2px 2px 2px rgba(0, 0, 0, 0.5);
 }
.content:after {
  content: "";
  display: table;
  clear: both;
}

</style>
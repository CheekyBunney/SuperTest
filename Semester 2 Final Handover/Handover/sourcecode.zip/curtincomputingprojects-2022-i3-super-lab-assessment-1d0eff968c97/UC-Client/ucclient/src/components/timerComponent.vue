<script>
import {parse} from "tinyduration";
import ToastNotificationService from "@/services/toast.notification.service";
export default{

  props: ['assessment'],
  data: ()=> ({
    displayDays: 0,
    displayHours: 0,
    displayMinutes: 0,
    displaySeconds: 0,
    loaded: false,
    expired: false,
    fifteenMin: false,
    fiveMin: false,
  }),

  computed: {
    _seconds:() => 1000,
    _minutes() {
      return this._seconds * 60
    },
    _hours() {
      return this._minutes * 60
    },
    _days() {
      return this._hours * 24
    }
  },
  mounted(){
    this.showRemaining();
  },
  methods: {
    formatNum: num => (num < 10 ? '0' + num : num),
    getEnd(duration, date){
      date.setTime(date.getTime() + (duration.hours * 60 * 1000 * 60) + ((duration.minutes) * 60 * 1000))

      return date;
    },

    showRemaining(){

      const timer = setInterval(() => {
        const durationObj = parse(this.assessment.duration);
        const assessmentStart = new Date(this.assessment.startsAt);

        const now = new Date();
        const end = this.getEnd(durationObj, assessmentStart);
        const distance = end.getTime() - now.getTime();
        if(distance < 0){
          clearInterval(timer);
          this.expired = true;
          return
        }
        else if (distance/60000 < 15 && this.fifteenMin === false){
          ToastNotificationService.doFifteenNotification(this.assessment.unitCode+" "+this.assessment.name+" has 15 minutes remaining");
          this.fifteenMin = true;
        }
        else if (distance/60000 < 5 && this.fiveMin === false){
          ToastNotificationService.doFiveNotification(this.assessment.unitCode+" "+this.assessment.name+ " has 5 minutes remaining");
          this.fiveMin = true;
        }
        const days = Math.floor((distance / this._days));
        const hours = Math.floor((distance % this._days) / this._hours);
        const minutes = Math.floor ((distance % this._hours) / this._minutes);
        const seconds = Math.floor((distance % this._minutes) / this._seconds);
        this.displayMinutes = this.formatNum(minutes);
        this.displaySeconds = this.formatNum(seconds);
        this.displayHours = this.formatNum(hours);
        this.displayDays = this.formatNum(days);
        this.loaded = true;
      }, 1000);
    }
  }



}
</script>

<template>
  <div class="view-header text-secondary">
    <h1>
      {{assessment.name}}

    </h1>
    <h2>
      {{assessment.unitCode}}
    </h2>
  </div>

  <div v-if="!expired">

    <div v-if="loaded">

      <b-row class="text-primary">

        <b-col>
          <h1>{{displayHours}}</h1>
          <h3> Hours </h3>
        </b-col>

        <b-col>
          <h1>{{displayMinutes}}</h1>
          <h3> Minutes </h3>
        </b-col>

        <b-col>
          <h1>{{displaySeconds}}</h1>
          <h3> Seconds </h3>
        </b-col>
      </b-row>
    </div>
  </div>

  <div v-else>

    <h1 class="text-danger"> Assessment has Ended </h1>
  </div>
</template>

<style>

.view-header{
  margin-bottom: 100px;
}

</style>

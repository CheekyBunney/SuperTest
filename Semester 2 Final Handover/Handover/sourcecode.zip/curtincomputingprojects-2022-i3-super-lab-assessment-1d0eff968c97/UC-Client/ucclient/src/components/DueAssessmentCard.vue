<script>
import moment from 'moment'
export default{
  props: ['assessment'],
  data(){
    return{
      showButton: false,
      timer: '',
      startString: ""
    }
  },
  mounted () {
    this.getTimeToStart();
  },
  computed: {
    _seconds: () => 1000,
    _minutes() {
      return this._seconds * 60
    },
    _hours() {
      return this._minutes * 60
    },
    _days() {
      return this._hours * 24
    }
  },
  methods: {
    checkTime(num, str, typeCheck){
      if (num !== 0)
      {
        if (num > 1)
          this.startString += num + " " + str + "s";
        else if (num === 1)
          this.startString += num + " " + str;
        if (typeCheck === 0)
          this.startString += ", "
        else if (typeCheck === 1)
          this.startString += " and "
        else if (typeCheck === 2)
          this.startString += " ago"
      }
    },

    startAssessment() {
      this.$router.push({path:"/assessment/" + this.assessment.uuid});
    },

    getTimeToStart(){
      this.timer = setInterval(() => {
        const startDate = new Date(this.assessment.startsAt);
        const now = new Date();
        const distance = startDate - now

        const numHours = Math.floor(Math.abs(((distance)%(this._days) / (this._hours))))
        const numMinutes = Math.floor(Math.abs(((distance)%(this._hours)/(this._minutes))))
        const numSeconds = Math.floor(Math.abs(((distance)%(this._minutes)/(this._seconds))))

        if ((startDate - now) / 60000 >= 0) {
          this.startString = "Starts in: ";
          this.checkTime(numHours, "Hour", 0);
          this.checkTime(numMinutes, "Minute", 1);
          this.checkTime(numSeconds, "Second", 3)

        } else {
          this.startString = "Started "
          this.showButton = true;
          this.checkTime(numHours, "Hour", 0);
          this.checkTime(numMinutes, "Minute", 1)
          this.checkTime(numSeconds, "Second", 2)
        }
      },1000)
    },
    cancelAutoUpdate(){
      clearInterval(this.timer);
    },
    formattedTime(){
      return moment(new Date(this.assessment.startsAt)).calendar();
    }
  },
  unmounted() {
    this.cancelAutoUpdate();
  }

}
</script>
<template>
  <div class="upcoming">
    <b-card class="bg-primary text-white border-0">
      <b-row>
        <b-col class="text-center">
          <h4><u>Assessment</u></h4>
          {{assessment.name}}
        </b-col>
        <b-col class="text-center">
          <h4><u>Unit</u></h4>
          {{assessment.unitCode}}
        </b-col>
        <b-col class="text-center">
          <h4><u>Starting Time</u></h4>
          {{formattedTime()}}
        </b-col>
      </b-row>
    </b-card>
  </div>
  <div class="card-footer bg-transparent border-0">
    {{startString}}
    <b-button v-if="showButton" class="text-white w-25" @click="startAssessment()" variant="secondary">Join</b-button>
  </div>
</template>

<style>
.card-footer{
  text-align: right;
}
</style>
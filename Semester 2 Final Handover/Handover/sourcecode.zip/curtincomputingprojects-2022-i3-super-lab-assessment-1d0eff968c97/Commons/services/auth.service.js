
import api, {noAuthHeader} from "../axios/api"
import axios from "axios";
const API_URL = '/auth/';
class AuthService {
    login({user, validRoles}) {
        return api
            .post(API_URL + 'login', {
                curtinID: user.curtinID,
                password: user.password
            },{transformRequest: [noAuthHeader, ...axios.defaults.transformRequest]})
            .then(response => {
                var roleIntersection = response.data['roles'].filter(role => validRoles.includes(role));
                if(roleIntersection.length === 0){
                    throw new Error("User does not contain a valid role")
                }
                if (response.data['access_token']) {
                    localStorage.setItem('tokenInfo', JSON.stringify(response.data));
                }
                return response.data;
            });
    }

    logout() {
        return api.post(API_URL + "logout", this.getRefreshToken(), {transformRequest: noAuthHeader}).then(() => {
            this.clearTokenInfo();
        }).catch(() => this.clearTokenInfo());
    }


    clearTokenInfo() {
        localStorage.removeItem('tokenInfo');
    }

    getTokenInfo(){
        return JSON.parse(localStorage.getItem("tokenInfo"));
    }

    getAccessToken(){
        let tokenInfo = this.getTokenInfo();
        if(tokenInfo !== null){
            return tokenInfo['access_token']
        }
    }
    getRefreshToken(){
        let tokenInfo = this.getTokenInfo();
        if(tokenInfo !== null){
            return tokenInfo['refresh_token']
        }
    }

    updateLocalAccessToken(accessToken) {
        let tokenInfo = JSON.parse(localStorage.getItem("tokenInfo"));
        tokenInfo['access_token'] = accessToken;
        localStorage.setItem("tokenInfo", JSON.stringify(tokenInfo));
    }

    getRoles(){
        let tokenInfo = this.getTokenInfo();
        if(tokenInfo !== null){
            return tokenInfo['roles']
        }
        return []
    }
}
export default new AuthService();
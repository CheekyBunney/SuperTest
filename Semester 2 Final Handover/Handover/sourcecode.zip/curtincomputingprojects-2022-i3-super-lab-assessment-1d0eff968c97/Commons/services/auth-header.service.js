export default function authHeader() {
    let tokenInfo = JSON.parse(localStorage.getItem('tokenInfo'));
    if (tokenInfo && tokenInfo['access_token']) {
        return { Authorization: 'Bearer ' + tokenInfo['access_token'] };
    } else {
        return {};
    }
}
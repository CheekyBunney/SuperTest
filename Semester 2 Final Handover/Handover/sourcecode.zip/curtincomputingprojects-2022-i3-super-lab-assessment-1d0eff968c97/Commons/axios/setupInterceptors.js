import axiosInstance, {noAuthHeader} from "./api";
import AuthService from "../services/auth.service";
import eventBus from "../util/eventBus";
import axios from "axios";
const setup = (store) => {
    axiosInstance.interceptors.request.use(
        (config) => {
            const token = AuthService.getAccessToken()
            if (token) {
                config.headers["Authorization"] = 'Bearer ' + token;
            }
            return config;
        },
        (error) => {
            return Promise.reject(error);
        }
    );
    axiosInstance.interceptors.response.use(
        (res) => {
            return res;
        },
        async (err) => {
            const originalConfig = err.config;
            if (originalConfig.url !== "/auth/login" && err.response) {
                // Access Token was expired
                if (err.response.status === 401 && !originalConfig._retry) {
                    originalConfig._retry = true;
                    try {
                        console.log("refreshing token")
                        var fs =  await axiosInstance.post(`/auth/refresh`, AuthService.getRefreshToken(),
                        {
                                transformRequest: [noAuthHeader, ...axios.defaults.transformRequest],
                                headers: {
                                        'Content-Type' : 'text/plain' //needed to send string as body
                                }
                        })
                            .then(response => {
                                //get a new refresh token
                                const accessToken = response.data["access_token"]
                                store.dispatch('auth/refreshToken', accessToken);
                                AuthService.updateLocalAccessToken(accessToken);
                                return axiosInstance(originalConfig);
                            })
                            .catch(error =>{
                                //if the auth refresh token api returns 403 it means the refreshToken has expired and we need the user must log in again
                                if(error.response){
                                    if(error.response.status === 403){
                                        console.trace("received 403 returning to login screen")
                                        eventBus.dispatch("logout")
                                    }
                                }
                            });
                        return fs;
                    } catch (_error) {
                        return Promise.reject(_error);
                    }
                }
            }
            return Promise.reject(err);
        }
    );
};
export default setup;
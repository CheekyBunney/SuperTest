import axios from "axios";



const isDevelopment = process.env.NODE_ENV !== 'production'
var baseURL;
if (isDevelopment) {
    baseURL = "http://localhost:8080/"
} else {
    baseURL = "http://ec2-54-206-75-170.ap-southeast-2.compute.amazonaws.com:8080"
}
const instance = axios.create({
    baseURL: baseURL,
    headers: {
        "Content-Type": "application/json",
    },
});
export function noAuthHeader(data, headers){
    delete headers.common['Authorization'];
    delete headers['Authorization'];
    return data;
}
export default instance;
<script>

//imports
import {collapsed, toggleNotificationsBar} from "./state";

export default {
  name: "NBTabButtons",
  props: [
    'withSession',
    'showBadge',
    'clientName',
    'numNotifications'
  ],

  //all data involved with the Tab Buttons view
  data() {
    return {
      incomingMessagesTabHeading: '',
      outgoingMessagesTabHeading: '',
      collapsed,
      toggleNotificationsBar
    }
  },

  //called after the Tab Buttons view is mounted
  mounted() {
    //sets tab headings according to client type
    if(this.clientName === 'UC') {
      this.incomingMessagesTabHeading = 'Student Questions';
      this.outgoingMessagesTabHeading = 'Make an Announcement';
    }else {
      this.incomingMessagesTabHeading = 'Notifications';
      this.outgoingMessagesTabHeading = 'Ask a Question';
    }

    //sets all tab contents to invisible
    let tabcontent = document.getElementsByClassName("tab-content");
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  },

  //all methods involved with the Tab Buttons view
  methods:{

    //used to wait for element to be loaded
    waitForElement(id, callback){
      const interval = setInterval(function(){
        if(document.getElementById(id)){
          clearInterval(interval);
          callback();
        }
      }, 50);
    },

    //called when a tab is clicked
    openTab(tabButtonID, tabContentID, tabHeading) {
      //method fields
      let i, tabcontent, tabButtons;
      //sets all tab contents to invisible
      tabcontent = document.getElementsByClassName("tab-content");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      //sets all tab buttons to inactive state
      tabButtons = document.getElementsByClassName("tab-buttons");
      for (i = 0; i < tabButtons.length; i++) {
        tabButtons[i].className = tabButtons[i].className.replace(" active", "");
      }
      //displays tab heading
      document.getElementById('tabHeading').innerHTML = tabHeading;
      //displays tab content
      document.getElementById(tabContentID).style.display = "block";
      //sets current tab button to active state
      document.getElementById(tabButtonID).className += " active";

      //if bar is collapsed
      if(collapsed.value) {
        //waits for tab content element to be loaded while bar opens
        this.waitForElement(tabContentID, function() {
          //displays current tab's content
          document.getElementById(tabContentID).style.display = "block";
        });
        //toggles bar to open state
        toggleNotificationsBar();
      }
      //if bar is not collapsed
      else {
        //displays tab content
        document.getElementById(tabContentID).style.display = "block";
      }
      //sets badge to invisible
      if(tabButtonID === 'incoming-messages-tb') {
        this.$emit('setBadgeVisibility', false);
      }
    }
  }
}
</script>


<template>

  <!-- tab buttons area -->
  <div class="tab-buttons-area"
       :class="{withoutSessionStyling: withSession === false}"
       id="tabButtonsArea">

    <!-- BUTTONS FOR WITH SESSION -->
    <div v-if="withSession === true">

      <!-- INCOMING MESSAGES TAB BUTTON -->
      <button
          class="tab-buttons"
          @click="openTab(
              'incoming-messages-tb',
              'incoming-messages-tc',
              incomingMessagesTabHeading)"
          id="incoming-messages-tb"
      >
        <!-- bell icon -->
        <i class="far fa-bell"/>

        <!-- notification icon: display only if more than 0 -->
        <span v-if="numNotifications > 0">
          <span class="badge">
            {{numNotifications}}
          </span>
        </span>
      </button>

      <!-- OUTGOING MESSAGES TAB BUTTON -->
      <button
          class="tab-buttons"
          @click="openTab(
              'outgoing-messages-tb',
              'outgoing-messages-tc',
              outgoingMessagesTabHeading)"
          id="outgoing-messages-tb"
      >
        <!-- question mark icon -->
        <i class="far fa-circle-question"></i>
      </button>
    </div>

    <!-- SETTINGS TAB BUTTON -->
    <button
        class="tab-buttons"
        @click="openTab(
            'settings-tb',
            'settings-tc',
            'Settings')"
        id="settings-tb"
    >
      <!-- question mark icon -->
      <i class="fas fa-gear"></i>
    </button>
  </div>
</template>


<style scoped>

/*DEBUG*/
/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.tab-buttons-area{
  height: 100%;
  padding-top: 450%;
}
.withoutSessionStyling{
  padding-top: 600%;
}

.tab-buttons{
  position: relative;
  padding: 10% 20% 10% 0;
  margin-left: 10%;
  display: block;
  background-color: inherit;
  color: black;
  width: 90%;
  border: none;
  outline: none;
  text-align: right;
  cursor: pointer;
  font-size: 32px;
  transition: 0.1s;
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
}

.fa-bell{
  color: #FCFCFC;
}
.tab-buttons .badge {
  font-size: 40%;
  line-height: 125%;
  position: absolute;
  top: 10%;
  right: 10%;
  padding: 2% 7%;
  border-radius: 50%;
  background-color: red;
  color: white;
  border: 4px solid inherit;
}
.fa-circle-question{
  color: #FCFCFC;
  padding: 0 0 0 25%;
}
.fa-gear{
  color: #FCFCFC;
}

.tab-buttons:hover{
  font-size: 34px;
  background-color: #507DBC;
  opacity: 50%;
  transition: 0.1s;
}
.tab-buttons.active{
  font-size: 36px;
  background-color: #507DBC;
  box-shadow: -2px 2px 2px rgba(0, 0, 0, 0.5);
}
.tab-buttons.active:hover{
  opacity: 100%;
}
</style>
<script>


export default{

  props: [
    'message',
    'messageType',
    'isNew',
    'outgoing'
  ],

  data() {
    return {
    }
  },

  methods: {

    getMessage() {
      if(this.message == null) {
        return '';
      }else {
        if(this.messageType === 'studentQuestion') {
          return this.message.question;
        }else {
          return this.message.message;
        }
      }
    },

    //gets time sent from message/question object
    getTimeSent() {
      if(this.message == null) {
        return '';
      }else {
        let hour = Number(this.message.createdAt.substring(11,16).split(':')[0]) + 8;
        let minute = Number(this.message.createdAt.substring(11,16).split(':')[1]);
        let afternoon = false;

        if(hour > 12) {
          if(hour > 24) {
            hour -= 24;
          }else {
            hour -= 12;
            afternoon = true;
          }
        }
        if(minute < 10) {
          minute = "0" + minute;
        }
        let time = hour + ":" + minute;
        if(afternoon === true) {
          time = time + " pm";
        }else {
          time = time + " am";
        }
        return time;
      }
    }
  }
}
</script>

<template>

  <!-- message card -->
  <div class="message-card">

    <!-- staff member's name -->
    <div class="staff-name">

<!--      Staff-->

    </div>

    <!-- message card -->
    <div class="message-bubble"
         :class="{newMessage: isNew === true}">

      <!-- message content -->
      <div class="message-content">

        <strong>{{this.getMessage()}}</strong>

      </div>

      <!-- speech bubble triangle -->
      <div class="speech-triangle"
           :class="{
              newTriangle: isNew === true,
              outgoingTriangle: outgoing === true
            }"/>
    </div>

    <!-- time sent -->
    <div class="time-sent">

      {{this.getTimeSent()}}

    </div>
  </div>

</template>

<style scoped>

/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.staff-name{
  text-align: left;
  margin-left: 15px;
  width: 100%;
}
.message-bubble{
  text-align: left;
  color: #507DBC;
  border-radius: 15px;
  background: #C2DAF2;
  padding: 10px 15px;
  width: 100%;
}
.newMessage{
  background: #DAE3E5;
}

.message-content{
  font-size: 20px;
}
.speech-triangle{
  float: left;
  margin-top: -5px;
  margin-left: -15px;
  width: 0;
  height: 0;
  border-left: 0 solid transparent;
  border-right: 30px solid transparent;
  border-top: 30px solid #C2DAF2;
}
.outgoingTriangle{
  float: right;
  margin-right: -15px;
  margin-left: 0;
  border-left: 30px solid transparent;
  border-right: 0 solid transparent;
}
.newTriangle{
  border-top: 30px solid #DAE3E5;
}
.time-sent{
  float: right;
  text-align: right;
  margin-top: -15px;
  margin-right: 15px;
  width: 100%;
}

</style>
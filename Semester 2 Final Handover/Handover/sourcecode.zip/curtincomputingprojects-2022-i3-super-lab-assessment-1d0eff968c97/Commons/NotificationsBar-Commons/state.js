import {ref, computed} from 'vue'

export const collapsed = ref(true)
export const toggleNotificationsBar = () => (collapsed.value = !collapsed.value)

export const NOTIFICATIONS_BAR_WIDTH = 400
export const NOTIFICATIONS_BAR_WIDTH_COLLAPSED = 60
export const notificationsBarWidth = computed(
    () => `${collapsed.value ? NOTIFICATIONS_BAR_WIDTH_COLLAPSED : NOTIFICATIONS_BAR_WIDTH}px`
)

<script>

//imports
import IncomingMessagesTC from "./tabContent/IncomingMessagesTC";
import OutgoingMessagesTC from "./tabContent/OutgoingMessagesTC";
import SettingsTC from "./tabContent/SettingsTC";

export default {
  name: "NBTabContent",
  props: ['clientName', 'allIncomingMessages', 'newIncomingMessages', 'allOutgoingMessages'],
  components: {
    SettingsTC,
    IncomingMessagesTC,
    OutgoingMessagesTC
  },

  //all data involved with the Notification Bar Body Content view
  data() {
    return{
    }
  },
  setup() {
  },

  //all methods involved with the Notification Bar Body Content view
  methods:{

    //updates the all questions list in parent view
    updateOutgoingMessages(outGoingMessage) {
      this.$emit('updateOutgoingMessages', outGoingMessage);
    },

    //updates the all notifications list in parent view
    updateIncomingMessages(incomingMessage) {
      this.$emit('updateIncomingMessages', incomingMessage);
    },
  }
}
</script>


<!-- TEMPLATE -->
<template>

  <div class="body">

    <!-- tab headings -->
    <h1
        class="tab-heading"
        id="tabHeading"/>

    <!-- INCOMING MESSAGES -->
    <div
        id="incoming-messages-tc"
        class="tab-content">

      <IncomingMessagesTC
          :clientName="clientName"
          :allIncomingMessages="allIncomingMessages"
          :newIncomingMessages="newIncomingMessages"
          @updateIncomingMessages="updateIncomingMessages"/>
    </div>

    <!-- OUTGOING MESSAGES -->
    <div
        id="outgoing-messages-tc"
        class="tab-content">

      <OutgoingMessagesTC
          :clientName="clientName"
          :allOutgoingMessages="allOutgoingMessages"
          @updateOutgoingMessages="updateOutgoingMessages"/>
    </div>

    <!-- SETTINGS -->
    <div
        id="settings-tc"
        class="tab-content">

      <SettingsTC/>
    </div>

  </div>
</template>


<!-- STYLE -->
<style scoped>

/*DEBUG*/
/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.body{
  height: 100%;
}
.tab-heading {
  font-size: 32px;
  margin-top: 40px;
  margin-bottom: 20px;
  margin-left: 20px;
  text-align: left;
}
.tab-content {
  float: left;
  width: 100%;
  border-left: none;
  height: 100%;
  animation: fadeIn 1s;
  -webkit-animation: fadeIn 1s;
}
@keyframes fadeIn {
  0% { opacity: 0; }
  100% { opacity: 1; }
}

</style>
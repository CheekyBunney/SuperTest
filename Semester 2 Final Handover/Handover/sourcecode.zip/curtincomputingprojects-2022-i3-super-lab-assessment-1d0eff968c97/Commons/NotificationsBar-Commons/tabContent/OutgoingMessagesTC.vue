<script>

import OutgoingMessageStudent from "../../../Student-Client/studentclient/src/services/question.service";
import OutgoingMessageUC from "../../../UC-Client/ucclient/src/services/notification.service";
import MessageCard from "../MessageCard";
import {useToast} from "vue-toastification";
import ToastNotificationService from "../../../UC-Client/ucclient/src/services/toast.notification.service";

export default {
  name: "AskAQuestionTC",
  props: [
    'clientName',
    'allOutgoingMessages'
  ],
  components: { MessageCard },

  //all data involved with the Ask A Question view
  data() {
    return{
      messageType: ''
    }
  },

  //called after the Ask a Question view is mounted
  mounted() {

    //sets message type for display
    if(this.clientName === 'UC') {
      this.messageType = 'uCAnnouncement'
    }else{
      this.messageType = 'studentQuestion'
    }

    //gets all new outgoing messages and adds them to array
    this.getOutgoingMessages();

    //adds event listener for ENTER key pressed to send message
    document.getElementById("message-input").addEventListener("keypress", function(event) {
      if (event.key === "Enter") {
        event.preventDefault();
        document.getElementById("send-message-button").click();
      }
    });
  },

  //all methods involved with the Ask a Question view
  methods:{
    pushNotification(toastContent){
      const toast = useToast();
      toast.info(toastContent, {
        timeout: false,
        pauseOnFocusLoss: false
      });
    },
    //gets all new questions and adds them to the array
    getOutgoingMessages() {
      //checks if current assessment exists
      if(this.$route.params.assessment !== undefined) {
        //if in the UC client
        if(this.clientName === 'UC') {
          //calls the backend api to get list of announcements from database
          OutgoingMessageUC.getNotifications(this.$route.params.assessment).then(response => {
            const announcementList = response.data;
            const newAnnouncements = this.getNewItems(this.allOutgoingMessages, announcementList);
            //calls parent view's method: adds question to the new questions list
            newAnnouncements.forEach(announcement => this.$emit('updateOutgoingMessages', announcement));
          }).catch(error => {
            console.error(error);
            this.pushNotification("failed to get outgoing messages");
          });
        //if in the student client
        }else {
          //calls the backend api to get list of questions
          OutgoingMessageStudent.getQuestions(this.$route.params.assessment).then(response => {
            const questionList = response.data;
            const newQuestions = this.getNewItems(this.allOutgoingMessages, questionList);
            //calls parent view's method: adds question to the new questions list
            newQuestions.forEach(question => this.$emit('updateOutgoingMessages', question));
          }).catch(error => {
            console.error(error);
            this.pushNotification("failed to get outgoing messages");
          });
        }
      }
    },

    getNewItems(oldArray, newArray) {
      const oldUUIDs = oldArray.map(oldOutgoing => oldOutgoing.uuid);
      return newArray.filter(newOutgoing => !oldUUIDs.includes(newOutgoing.uuid));
    },

    sendMessage() {
      //validation
      let message = document.getElementById("message-input").value;
      if(message == null || message === "") {
        //toast notification for empty message field
        ToastNotificationService.shortNotification("Please enter message to send");
      }
      else {
        //if in the UC client
        if (this.clientName === 'UC') {
          //creates new announcement
          OutgoingMessageUC.createNotification(this.$route.params.assessment, message).then(() => {
            this.getOutgoingMessages();
          }).catch(error => {
            console.error(error);
            this.pushNotification("failed to create announcement");
          });
        //if in the student client
        } else {
          //creates new question
          OutgoingMessageStudent.createQuestion(message, this.$route.params.assessment).then(() => {
            this.getOutgoingMessages();
          }).catch(error => {
            console.error(error);
            this.pushNotification("failed to create announcement");
          });
        }
        //resets message input area to empty
        document.getElementById("message-input").value = '';

        //toast notification for message confirmation
        ToastNotificationService.shortNotification("Message Sent");
      }
    }
  }
}
</script>


<template>

  <!-- body area -->
  <div class="body-area">

    <!-- sent messages area -->
    <div class="sent-messages-box">

        <MessageCard
            class="sent-messages-list"
            v-for="question in allOutgoingMessages"
            :key="question.uuid"
            :message="question"
            :messageType="messageType"
            :outgoing="true"/>
    </div>

    <!-- user input area -->
    <div class="user-input-box">

      <!-- message box -->
      <textarea
          class="message-input"
          type="text"
          id="message-input"
      />

      <!-- send button -->
      <button
          class="send-message-button"
          id="send-message-button"
          @click="sendMessage()"
      >
        <i class="fa-solid fa-paper-plane"></i>

      </button>
    </div>
  </div>
</template>


<style scoped>

/*DEBUG*/
/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.body-area{
  height: 100%;
  width: 100%;
}

.sent-messages-box{
  height: 65%;
  padding: 0 10%;
  overflow: auto;
  margin: 0 5px 0 5px;
  background: #406DAC;
  border-radius: 10px;
}

.sent-messages-list{
  list-style-type: none;
  margin: 35px 0 15px 0;
  padding: 0;
}

/*SCROLLBAR*/
::-webkit-scrollbar {
  width: 10px;
}
::-webkit-scrollbar-track {
  background: #8BA9D3;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb {
  background: #DAE3E5;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
  background: #FCFCFC;
}

/* USER INPUT */
.user-input-box{
  position: fixed;
  padding-bottom: 20px;
  width: 335px;
  bottom: 0;
  box-sizing: border-box;
}
.message-input{
  margin-right: 1%;
  margin-bottom: -10px;
  color: #507DBC;
  border-radius: 10px;
  border: 3px solid #8BA9D3;
  padding-left: 10px;
  height: 100px;
  width: 85%;
  font-size: 24px;
  overflow-wrap: break-word;
  hyphens: manual;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.send-message-button{
  text-align: left;
  width: 10%;
  border: none;
  color: #FCFCFC;
  background: none;
  font-size: 24px;
  cursor: pointer;
}
.user-input-box:after {
  content: "";
  display: table;
  clear: both;
}
</style>
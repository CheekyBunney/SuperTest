<script>

//imports
import IncomingMessagesUC from "../../../UC-Client/ucclient/src/services/question.service";
import IncomingMessagesStudent from "../../../Student-Client/studentclient/src/services/notification.service";
import MessageCard from "../MessageCard";
import {useToast} from "vue-toastification";

export default {
  name: "StudentQuestionsTC",
  props: [
      'clientName',
      'newIncomingMessages',
      'allIncomingMessages'
  ],
  components: {MessageCard},

  //all data involved with the Student Questions Tab Content view
  data() {
    return{
      messageType: '',
      polling: null
    }
  },

  //called after the Notifications Bar Body Content view is mounted
  mounted() {

    if(this.clientName === 'UC') {
      this.messageType = 'studentQuestion'
    }else {
      this.messageType = 'uCAnnouncement'
    }

    //calls the local polling method
    this.pollData();
  },

  //called before Notifications Bar is unmounted
  beforeUnmount () {
    //clears the new Student Question polling interval
    clearInterval(this.polling);
  },

  //all methods involved with the Student Questions Tab Content view
  methods:{

    pushNotification(toastContent){
      const toast = useToast();
      toast.info(toastContent, {
        timeout: false,
        pauseOnFocusLoss: false
      });
    },

    //sets poll interval: 5 secs
    pollData() {
      //checks if current assessment exists
      if(this.$route.params.assessment !== undefined) {
        //list of new incoming messages
        let importIncoming;
        //polls backend apis to get incoming messages
        this.polling = setInterval(() => {
          //if UC client
          if (this.clientName === 'UC') {
            IncomingMessagesUC.getQuestions(this.$route.params.assessment).then(response => {
              importIncoming = response.data;
            }).catch(error => {
              console.error(error);
              this.pushNotification("failed to get incoming messages");
            });
            //if student client
          } else {
            IncomingMessagesStudent.getNotifications(this.$route.params.assessment).then(response => {
              importIncoming = response.data;
            }).catch(error => {
              console.error(error);
              this.pushNotification("failed to get incoming messages");
            });
          }
          //checks if incoming messages are new
          this.filterNewMessages(importIncoming);

          console.log("polling for new Incoming Messages");
        }, 5000)
      }
    },

    filterNewMessages(importIncoming) {
      //check to avoid undefined forEach error
      if (importIncoming !== undefined) {
        //loops through imported student questions from api
        importIncoming.forEach(importIncomingMessage => {
          //assume current student question is new
          let old = false;
          //loops through all student questions to check for match
          this.allIncomingMessages.forEach(incomingMessage => {
            if (importIncomingMessage.uuid === incomingMessage.uuid) {
              //sets current student question to old
              old = true;
            }
          });
          //loops through new student questions to check for match
          this.newIncomingMessages.forEach(incomingMessage => {
            //if current student question already exists in list
            if (importIncomingMessage.uuid === incomingMessage.uuid) {
              //sets current student question to old
              old = true;
            }
          });
          //if current student question is new
          if (!old) {
            //calls parent view's method: adds it to all student question list
            this.$emit('updateIncomingMessages', importIncomingMessage);
          }
        });
      }
    }
  }
}
</script>


<!-- TEMPLATE -->
<template>

  <!-- scrollable area -->
  <div class="scrollable-area">

    <!-- ALL QUESTIONS -->
    <MessageCard
        class="notifications-list"
        v-for="message in allIncomingMessages"
        :key="message.uuid"
        :message="message"
        :messageType="messageType"
        :isNew="false"
        :outgoing="false"
    />

    <!-- NEW QUESTIONS -->
    <MessageCard
        class="notifications-list"
        v-for="message in newIncomingMessages"
        :key="message.uuid"
        :message="message"
        :messageType="messageType"
        :isNew="true"
        :outgoing="false"
    />

  </div>
</template>


<!-- STYLE -->
<style scoped>

/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

.scrollable-area{
  height: 80%;
  padding: 0 10%;
  overflow: auto;
  margin: 0 5px 0 5px;
  background: #406DAC;
  border-radius: 10px;
}

.notifications-list{
  list-style-type: none;
  margin: 35px 0 15px 0;
  padding: 0;
}

/*SCROLLBAR*/
::-webkit-scrollbar {
  width: 10px;
}
::-webkit-scrollbar-track {
  background: #8BA9D3;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb {
  background: #DAE3E5;
  border-radius: 10px;
}
::-webkit-scrollbar-thumb:hover {
  background: #FCFCFC;
}

</style>
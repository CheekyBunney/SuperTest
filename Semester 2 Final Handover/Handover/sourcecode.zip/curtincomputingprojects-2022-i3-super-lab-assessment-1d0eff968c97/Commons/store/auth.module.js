import AuthService from '../services/auth.service';
const tokeninfo = JSON.parse(localStorage.getItem('tokenInfo'));
const initialState = tokeninfo
    ? { status: { loggedIn: true }, tokenInfo: tokeninfo }
    : { status: { loggedIn: false }, tokenInfo: null };
export const auth = {
    namespaced: true,
    state: initialState,
    actions: {
        login({ commit }, user) {
            console.trace("login")
            return AuthService.login(user).then(
                tokenResponse => {
                    commit('loginSuccess', tokenResponse);
                    return Promise.resolve(tokenResponse);
                },
                error => {
                    commit('loginFailure');
                    return Promise.reject(error);
                }
            );
        },
        logout({ commit }) {
            console.trace("logout")
            AuthService.logout();
            commit('logout');
        },
        refreshToken({commit}, tokenResponse){
            commit("refreshToken", tokenResponse)
        }
    },
    mutations: {
        loginSuccess(state, tokenInfo) {
            state.status.loggedIn = true;
            state.tokenInfo = tokenInfo;
        },
        loginFailure(state) {
            state.status.loggedIn = false;
            state.tokenInfo = null;
        },
        logout(state) {
            state.status.loggedIn = false;
            state.tokenInfo = null;
        },
        refreshToken(state, tokenInfo){
            state.status.loggedIn = true;
            state.tokenInfo = tokenInfo;
        }
    }
};
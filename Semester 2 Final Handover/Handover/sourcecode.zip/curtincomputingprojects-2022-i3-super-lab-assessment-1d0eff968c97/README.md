# I3-Super-Lab-Assessment
## To Run UC Client
Go to http://i3-uc-client.s3-website-ap-southeast-2.amazonaws.com/assessment/f6b621d1-7efa-40d9-90e9-c7cbe31f2983
log in with credentials (test credentials are user: 10110111, password: uc)

## To Run Student Client
Download .deb file
In download directory, run sudo apt install ./SuperTest_0.1.0_amd64.deb
Then inside SuperTest directory which gets created, run ./supertest
Log in with credentials (test credentials are user: 12321452, password: student)
## Merge strategy

* Create branch based off of ticket name e.g 'init-database-setup'
* Add commits to branch
* Push branch to origin
* Create pull request from your branch to the branch 'master
* Other group member approves pull requests or makes comments

##Repo setup
* Student Client
* UC Client
* Backend

#!/bin/bash
exec /usr/sbin/sshd -D -e "$@" &
java -jar /app.jar &
wait
exit $?
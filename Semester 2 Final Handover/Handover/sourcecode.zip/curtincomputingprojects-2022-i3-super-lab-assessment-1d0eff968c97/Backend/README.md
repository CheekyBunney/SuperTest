#Backend Server
##Spring project
- Java sdk 17
- Language level 16


to initialise docker containers
`docker-compose -f docker-compose-dev.yml up`

to rerun existing docker containers `docker-compose -f docker-compose-dev.yml start`

to stop running docker containers `docker-compose -f docker-compose-dev.yml stop`

to destroy docker containers 'docker-compose -f docker-compose-dev.yml down'


#to run backend docker on server
##locally
docker save -o BackendImage f8c
##on server
//copy accross docker-compose file and run that aswell
sudo docker load -i BackendImage
sudo docker run -d -p 8080:8080 -p 5005:5005 -p 23:22 -e JAVA_TOOL_OPTIONS='-Dspring.profiles.active=dev,docker,prod -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005' --name spring <imageid>

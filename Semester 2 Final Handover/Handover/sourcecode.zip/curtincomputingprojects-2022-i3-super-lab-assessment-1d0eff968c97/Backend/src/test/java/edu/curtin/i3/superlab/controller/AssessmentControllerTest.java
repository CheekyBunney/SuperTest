package edu.curtin.i3.superlab.controller;

import com.google.common.io.Resources;
import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import edu.curtin.i3.superlab.repository.AssessmentRepository;
import edu.curtin.i3.superlab.repository.InvigilatorAssessmentDetailsRepository;
import edu.curtin.i3.superlab.repository.StudentAssessmentDetailsRepository;
import edu.curtin.i3.superlab.service.UserService;
import org.apache.commons.lang3.text.StrBuilder;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AssessmentControllerTest extends AbstractControllerTest{


    String ASSESSMENT_FILES_LOCATION = "assessmentCreationFiles";
    String STUDENT_PASSWORD = "123454";
    String UC_PASSOWRD  = "awegqweg";
    String INVIGILATOR_PASSWORD = "test123";
    User student;
    User student2;
    User uc;
    User invigilator;
    Assessment assessment1;
    Assessment assessment2;

    @Autowired
    private UserService userService;
    @Autowired
    private AssessmentRepository assessmentRepository;
    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;
    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;

    @BeforeEach
    public void setup() throws SignupException {
        createUsers();
        createAssessments();
    }

    @Test
    public void testListAssessmentsForStudents(){
        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD);
        ResponseEntity<Assessment[]> userListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/assessments/student/list",
                HttpMethod.GET,
                httpEntityWithAuthHeader,
                Assessment[].class
        );
        Assessment[] assessments = userListResponse.getBody();
        Assertions.assertNotNull(assessments);
        Assertions.assertEquals(2, assessments.length);
    }

    @Test
    public void testCreateAssessment() throws URISyntaxException, IOException {

        //prepare files we are going to send
        File imageO = new File(Resources.getResource(this.ASSESSMENT_FILES_LOCATION + File.separator + "img_0.png").toURI());

        String assessmentName = "test assessment creation";
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.set("name", assessmentName);
        body.set("unitCode", "unit test");
        body.set("startsAt", addDays(new Date(),1).toLocaleString());
        body.set("duration", Duration.ofHours(2).toString());
        body.set("students", student.getCurtinId());
        body.set("invigilators", invigilator.getCurtinId());
        body.set("files", new FileSystemResource(imageO));

        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        HttpHeaders headers = HttpHeaders.writableHttpHeaders(httpEntityWithAuthHeader.getHeaders());
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> assessmentCreationHttpEntity = new HttpEntity<MultiValueMap<String, Object>>(body, headers);

        ResponseEntity<Void> assessmentCreationResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/assessments/",
                HttpMethod.PUT,
                assessmentCreationHttpEntity,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.OK, assessmentCreationResponse.getStatusCode());

        //check that assessment was created
        List<Assessment> matchingAssessments = assessmentRepository.findAll().stream().filter(a -> a.getName().equals(assessmentName)).collect(Collectors.toList());
        Assertions.assertEquals(1, matchingAssessments.size());
    }

    @Test
    public void testUpdateAssessment() throws URISyntaxException, IOException {

        //prepare files we are going to send
        File imageO = new File(Resources.getResource(this.ASSESSMENT_FILES_LOCATION + File.separator + "img_0.png").toURI());

        String assessmentName = "test assessment creation";
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.set("name", assessmentName);
        body.set("unitCode", "unit test");
        body.set("startsAt", new Date().toLocaleString());
        body.set("duration", Duration.ofHours(2).toString());
        body.set("students", student.getCurtinId() + "," + student2.getCurtinId());
        body.set("invigilators", invigilator.getCurtinId());
        body.set("files", new FileSystemResource(imageO));

        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        HttpHeaders headers = HttpHeaders.writableHttpHeaders(httpEntityWithAuthHeader.getHeaders());
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> assessmentCreationHttpEntity = new HttpEntity<MultiValueMap<String, Object>>(body, headers);

        ResponseEntity<Void> assessmentCreationResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/assessments/update/" +  assessment1.getUuid() + "?updateFiles=true",
                HttpMethod.PUT,
                assessmentCreationHttpEntity,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.OK, assessmentCreationResponse.getStatusCode());

        //check that assessment was created
        Assessment assessment = assessmentRepository.findById(assessment1.getUuid()).orElse(null);//.stream().filter(a -> a.getName().equals(assessmentName)).collect(Collectors.toList());
        Assertions.assertEquals(assessmentName, assessment.getName());
        List<StudentAssessmentDetails> studentAssessmentDetails = studentAssessmentDetailsRepository.findByAssessmentUuid(assessment1.getUuid());
        Assertions.assertEquals(2, studentAssessmentDetails.size());
    }

    private void createUsers() throws SignupException {
        student = this.getFakeStudent();
        Signup signup = createSignup(student, STUDENT_PASSWORD);
        student = userService.createUser(signup, "STUDENT");

        student2 = this.getFakeStudent();
        student2.setCurtinId(34561232);
        student2.setEmail("test12213@ttest.com");
        Signup signup1 = createSignup(student2, "TEST PASSOWRD");
        student2 = userService.createUser(signup1, "STUDENT");

        uc = this.getFakeUC();
        Signup ucSignup = this.createSignup(uc, UC_PASSOWRD);
        uc = this.userService.createUser(ucSignup, "UC");

        invigilator = this.getFakeInvigilator();
        Signup invigSignup = this.createSignup(invigilator, INVIGILATOR_PASSWORD);
        invigilator = this.userService.createUser(invigSignup, "INVIGILATOR");
    }


    @AfterEach
    public void tearDown(){
        userService.deleteUser(student.getId());
        userService.deleteUser(student2.getId());
        userService.deleteUser(uc.getId());
        userService.deleteUser(invigilator.getId());
        studentAssessmentDetailsRepository.deleteAll();
        invigilatorAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();
    }

    private void createAssessments() {
        Assessment tmpAssessment1 = this.getFakeAssessment(this.uc);
        Assessment tmpAssessment2 = this.getFakeAssessment(this.uc);{{
            tmpAssessment2.setName("other assessment");
        }}
        assessment1 = assessmentRepository.saveAndFlush(tmpAssessment1);
        assessment2 = assessmentRepository.saveAndFlush(tmpAssessment2);
        StudentAssessmentDetails studentAssessmentDetails = this.getFakeStudentAssessmentDetails(assessment1, student);
        StudentAssessmentDetails studentAssessmentDetails2 = this.getFakeStudentAssessmentDetails(assessment2, student);
        studentAssessmentDetailsRepository.saveAndFlush(studentAssessmentDetails);
        studentAssessmentDetailsRepository.saveAndFlush(studentAssessmentDetails2);
    }

    public Date addDays(Date date, long days){
        LocalDateTime localDateTime = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime addedTime = localDateTime.plusDays(days);
        return toDate(addedTime);
    }
    public Date toDate(LocalDateTime dateToConvert) {
        return Date.from(dateToConvert.atZone(ZoneId.systemDefault()).toInstant());
    }


}

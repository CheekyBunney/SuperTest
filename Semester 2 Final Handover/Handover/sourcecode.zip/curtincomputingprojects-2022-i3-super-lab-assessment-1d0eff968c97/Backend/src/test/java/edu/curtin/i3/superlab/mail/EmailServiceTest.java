package edu.curtin.i3.superlab.mail;


import edu.curtin.i3.superlab.service.EmailService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@ActiveProfiles({"test", "dev"})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class EmailServiceTest {

    @Autowired
    private EmailService emailService;


    @Test
    public void testSendEmailWithTemplate(){
        Email testEmail = new Email();
        testEmail.setTo("emailRecieve@testEmail.com");
        testEmail.setFrom("superlab@superlab.curtin.com");
        testEmail.setSubject("test email");
        testEmail.setTemplate("exampleTemplate.html");
        Map<String, Object> templateVariables = new HashMap<>();
        templateVariables.put("words", Arrays.asList("exaple", "word"));
        templateVariables.put("date", new Date());
        testEmail.setProperties(templateVariables);
        Assertions.assertDoesNotThrow(() -> emailService.sendHtmlMessage(testEmail));
    }
}

package edu.curtin.i3.superlab.controller;


import edu.curtin.i3.superlab.data.dto.Login;
import edu.curtin.i3.superlab.data.dto.PasswordResetDTO;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.data.orm.PasswordResetToken;
import edu.curtin.i3.superlab.repository.PasswordResetTokenRepository;
import edu.curtin.i3.superlab.service.UserService;
import org.junit.jupiter.api.*;

import org.keycloak.representations.AccessTokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.UUID;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AuthControllerTest extends AbstractControllerTest{

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordResetTokenRepository passwordResetTokenRepository;

    private User user;
    private String PASSWORD = "Test123";
    private UUID validPasswordResetToken;

    @BeforeEach
    public void setup() throws SignupException {
        user = this.getFakeStudent();
        Signup signup = createSignup(user, PASSWORD);
        user = userService.createUser(signup, "STUDENT");
        PasswordResetToken passwordResetToken = new PasswordResetToken();
        passwordResetToken.setCreatedBy(user.getId());
        passwordResetToken.setExpiryDate(this.getExpiryDate());
        validPasswordResetToken = passwordResetTokenRepository.saveAndFlush(passwordResetToken).getToken();
    }

    @AfterEach
    public void tearDown(){
        userService.deleteUser(user.getId());
    }


    @Test
    public void testLogin(){
        Login login = new Login();
        login.setCurtinID(user.getCurtinId());
        login.setPassword(PASSWORD);

        ResponseEntity<AccessTokenResponse> response = login(login);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testLoginBadPassword(){
        Login login = new Login();
        login.setCurtinID(user.getCurtinId());
        login.setPassword("incorrect");

        ResponseEntity<AccessTokenResponse> response = login(login);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testLogout(){

        Login login = new Login();
        login.setCurtinID(user.getCurtinId());
        login.setPassword(PASSWORD);
        //login
        ResponseEntity<AccessTokenResponse> loginResponse = login(login);
        //create headers

        String refreshToken = loginResponse.getBody().getRefreshToken();

        //hit refresh token api, should be authorized
        ResponseEntity<AccessTokenResponse> refeshTokenResponse = getNewAccessToken(refreshToken);
        Assertions.assertEquals(HttpStatus.OK,  refeshTokenResponse.getStatusCode());
        //update tokens
        refreshToken = refeshTokenResponse.getBody().getRefreshToken();

        // logout
        ResponseEntity<Void> logoutResponse = this.logout(refreshToken);
        Assertions.assertEquals(HttpStatus.OK, logoutResponse.getStatusCode());

        //hit refresh token api again, should be unauthorized now
        ResponseEntity<AccessTokenResponse> refeshTokenResponse2 = getNewAccessToken(refreshToken);
        Assertions.assertEquals(HttpStatus.FORBIDDEN, refeshTokenResponse2.getStatusCode());

    }

    @Test
    public void testPasswordReset(){
        String newPassword = "new password";
        PasswordResetDTO passwordResetDTO = new PasswordResetDTO();
        passwordResetDTO.setToken(this.validPasswordResetToken);
        passwordResetDTO.setCurtinId(this.user.getCurtinId());
        passwordResetDTO.setNewPassword(newPassword);
        ResponseEntity<Void> passwordResetResponseEntity = this.resetUserPassword(passwordResetDTO);
        Assertions.assertEquals(HttpStatus.OK,passwordResetResponseEntity.getStatusCode());
        //check that login works
        Login login = new Login();
        login.setCurtinID(user.getCurtinId());
        login.setPassword(newPassword);
        ResponseEntity<AccessTokenResponse> loginResponse = login(login);
        Assertions.assertEquals(HttpStatus.OK,loginResponse.getStatusCode());
    }

    @Test
    public void testPasswordResetFailsWithBadToken(){
        String newPassword = "new password";
        UUID invalidToken = UUID.randomUUID();
        //check that the random token is not equal,
        Assertions.assertNotEquals(validPasswordResetToken, invalidToken);
        PasswordResetDTO passwordResetDTO = new PasswordResetDTO();
        passwordResetDTO.setToken(invalidToken);
        passwordResetDTO.setCurtinId(this.user.getCurtinId());
        passwordResetDTO.setNewPassword(newPassword);
        ResponseEntity<Void> passwordResetResponseEntity = this.resetUserPassword(passwordResetDTO);
        Assertions.assertNotEquals(HttpStatus.OK,passwordResetResponseEntity.getStatusCode());

    }

    private ResponseEntity<Void> resetUserPassword(PasswordResetDTO passwordResetDTO){
        HttpEntity<PasswordResetDTO> httpEntity = new HttpEntity<PasswordResetDTO>(passwordResetDTO);
        return this.restTemplate.exchange(
                "http://localhost:" + this.port + "/auth/password/reset",
                HttpMethod.POST,
                httpEntity,
                Void.class
        );
    }


    private ResponseEntity<AccessTokenResponse> getNewAccessToken(String refreshToken) {
        HttpEntity<String> he = new HttpEntity<>(refreshToken);
        return this.restTemplate.exchange(
                "http://localhost:" + this.port + "/auth/refresh",
                HttpMethod.POST,
                he,
                AccessTokenResponse.class
                );
    }

    private ResponseEntity<Void> logout(String refreshToken){
        HttpEntity<String> httpEntity = new HttpEntity<String>(refreshToken);
        return this.restTemplate.exchange(
                "http://localhost:" + this.port + "/auth/logout",
                HttpMethod.POST,
                httpEntity,
                Void.class
        );

    }

    private Date getExpiryDate() {
        LocalDateTime expiryDate = LocalDateTime.now().plusHours(5);
        return Date.from(expiryDate.atZone(ZoneId.systemDefault()).toInstant());
    }


}

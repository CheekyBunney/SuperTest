package edu.curtin.i3.superlab.selenium.student.client;

import edu.curtin.i3.superlab.selenium.AbstractPageTest;

public abstract class AbstractStudentClientPageTest extends AbstractPageTest {

    private static int STUDENT_CLIENT_PORT = 4001;


    @Override
    protected String getApplicationUrl() {
        return "http://localhost:" + STUDENT_CLIENT_PORT;
    }
}

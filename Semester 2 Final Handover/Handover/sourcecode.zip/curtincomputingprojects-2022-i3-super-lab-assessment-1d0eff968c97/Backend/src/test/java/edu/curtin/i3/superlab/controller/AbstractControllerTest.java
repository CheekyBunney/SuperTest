package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.Login;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.util.AbstractDataGenerator;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@ActiveProfiles({"test", "dev"})
public class AbstractControllerTest extends AbstractDataGenerator {

    @Autowired
    protected TestRestTemplate restTemplate;

    @LocalServerPort
    protected int port;

    protected ResponseEntity<AccessTokenResponse> login(Login login) {
        return this.restTemplate.postForEntity("http://localhost:" + this.port + "/auth/login", login, AccessTokenResponse.class);
    }


    protected HttpEntity loginAndGetAuthHttpEntity(User uc, String uc_passowrd) {
        Login ucLogin = new Login();
        ucLogin.setCurtinID(uc.getCurtinId());
        ucLogin.setPassword(uc_passowrd);
        ResponseEntity<AccessTokenResponse> loginToken = this.login(ucLogin);
        return getHttpEntityWithAuthHeader(loginToken);
    }

    private HttpEntity getHttpEntityWithAuthHeader(ResponseEntity<AccessTokenResponse> accessTokenResponseResponseEntity){
        AccessTokenResponse token = accessTokenResponseResponseEntity.getBody();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token.getToken());
        return new HttpEntity(headers);
    }
}

package edu.curtin.i3.superlab.selenium;

import edu.curtin.i3.superlab.util.AbstractDataGenerator;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@Testcontainers
@ActiveProfiles({"test", "dev"})
public abstract class AbstractPageTest  extends AbstractDataGenerator{

    protected abstract String getApplicationUrl();

    protected ChromeDriver getChromeDriver(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions chromeOptions = new ChromeOptions();
        return new ChromeDriver(chromeOptions);
    }

    protected void loadWebsite(WebDriver webDriver){
        try{
            webDriver.navigate().to(getApplicationUrl());
        } catch (WebDriverException e){
            String msg = "failed to load site, check that the website is running at " + this.getApplicationUrl();
            throw new WebDriverException(msg, e);
        }
    }

}

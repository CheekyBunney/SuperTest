package edu.curtin.i3.superlab.util;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.*;

import java.time.Duration;
import java.util.Date;

public abstract class AbstractDataGenerator {
    protected User getFakeStudent(){
        User student = new User();
        student.setId("ID_STUDENT");
        student.setCurtinId(123);
        student.setEmail("Caesar.Augustus@student.curtin.edu.au");
        student.setFirstName("Caesar");
        student.setLastName("Augustus");
        //student.setRole("student");
        return student;
    }

    protected User getFakeUC(){
        User uc = new User();
        uc.setCurtinId(123325);
        uc.setId("ID_UC");
        uc.setEmail("Nero.Claudius@lecturer.curtin.edu.au");
        uc.setFirstName("Nero");
        uc.setLastName("Claudius");
        //uc.setRole("UC");
        return uc;
    }

    protected User getFakeInvigilator(){
        User invigilator = new User();
        invigilator.setCurtinId(1892325);
        invigilator.setId("ID_INVIGILATOR");
        invigilator.setEmail("test_invigi@lecturer.curtin.edu.au");
        invigilator.setFirstName("john");
        invigilator.setLastName("smith");
        //uc.setRole("UC");
        return invigilator;
    }

    protected UCNotification getFakeUCNotification(User uc, Assessment assessment){
        UCNotification ucNotification = new UCNotification();
        if(assessment != null){
            ucNotification.setAssessment(assessment.getUuid());
        }

        ucNotification.setMessage("hellpp!!! ");
        ucNotification.setCreatedAt(new Date());
        ucNotification.setCreatedBy(uc.getId());
        return  ucNotification;
    }

    protected Assessment getFakeAssessment(User creator) {
        Assessment assessment = new Assessment();
        assessment.setName("The comp60000012 ultimate assesment");
        assessment.setCreatedAt(new Date());
        assessment.setCreatedBy(creator.getId());
        assessment.setStartsAt(new Date());
        assessment.setDuration(Duration.ofHours(2));
        assessment.setReleasedToStudents(false);
        return assessment;
    }

    protected StudentAssessmentDetails getFakeStudentAssessmentDetails(Assessment assessment, User student) {
        StudentAssessmentDetails details = new StudentAssessmentDetails();
        details.setAssessment(assessment);
        details.setStudent(student.getId());
        details.setFinishTime(new Date());
        details.setWorkFolderPath("testPath");
        return details;
    }

    protected DurationModification getFakeDurationModification(User creator, StudentAssessmentDetails studentAssessmentDetails) {
        DurationModification durationModification = new DurationModification();
        durationModification.setStudentAssessmentDetails(studentAssessmentDetails.getUuid());
        durationModification.setCreatedBy(creator.getId());
        durationModification.setCreatedAt(new Date());
        durationModification.setDuration(Duration.ofMinutes(10));
        durationModification.setReason("just because");
        return durationModification;
    }

    protected StudentQuestion getFakeStudentQuestion(StudentAssessmentDetails studentAssessmentDetails, User uc) {
        StudentQuestion studentQuestion = new StudentQuestion();
        studentQuestion.setStudentAssessmentDetails(studentAssessmentDetails.getUuid());
        studentQuestion.setQuestion("how do i get the answer?");
        studentQuestion.setCreatedAt(new Date());
        studentQuestion.setResolvedBy(uc.getId());
        studentQuestion.setResolvedAt(new Date());
        return studentQuestion;
    }

    protected Signup createSignup(User user, String password){
        Signup signup = new Signup();
        signup.setCurtinId(user.getCurtinId());
        signup.setEmail(user.getEmail());
        signup.setFirstName(user.getFirstName());
        signup.setLastName(user.getLastName());
        signup.setPassword(password);
        return signup;
    }
}

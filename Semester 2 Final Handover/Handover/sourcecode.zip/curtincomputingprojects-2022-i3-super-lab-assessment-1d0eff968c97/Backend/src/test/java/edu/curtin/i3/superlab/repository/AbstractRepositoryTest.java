package edu.curtin.i3.superlab.repository;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.*;

import edu.curtin.i3.superlab.util.AbstractDataGenerator;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.Duration;
import java.util.Date;
import java.util.HashSet;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@Testcontainers
@ActiveProfiles({"test", "dev"})
public abstract class AbstractRepositoryTest extends AbstractDataGenerator {

}

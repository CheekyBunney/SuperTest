package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.UCNotification;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UCNotificationRepositoryTest extends AbstractRepositoryTest{

    @Autowired
    private UCNotificationRepository ucNotificationRepository;
    @Autowired
    private AssessmentRepository assessmentRepository;
    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;
    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    private User uc;
    private Assessment assessment;

    @BeforeEach
    public void setup() {
        uc = this.getFakeUC();

        assessment = this.getFakeAssessment(uc);
        assessment = assessmentRepository.saveAndFlush(assessment);
    }

    @AfterEach
    public void tearDown(){
        ucNotificationRepository.deleteAll();
        invigilatorAssessmentDetailsRepository.deleteAll();
        studentAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();
    }
    @Test
    public void createUCNotification() throws Exception {

        UCNotification ucNotification = this.getFakeUCNotification(this.getFakeUC(), assessment);
        ucNotificationRepository.save(ucNotification);
        UCNotification readUCNotification = this.ucNotificationRepository.findById(ucNotification.getUuid()).orElseThrow(() -> new Exception("test failed, cant find uc notification"));
        Assertions.assertEquals(ucNotification.getAssessment(), readUCNotification.getAssessment());
        Assertions.assertEquals(ucNotification.getCreatedBy(), readUCNotification.getCreatedBy());
        Assertions.assertEquals(ucNotification.getCreatedAt(), readUCNotification.getCreatedAt());
        Assertions.assertEquals(ucNotification.getMessage(), readUCNotification.getMessage());
    }

    @Test
    public void failToCreateUCNotificationWithNoAssessment(){
        UCNotification ucNotification1 = this.getFakeUCNotification(this.getFakeUC(), null);
        Assertions.assertThrows(DataIntegrityViolationException.class, ()-> ucNotificationRepository.save(ucNotification1));

    }

}

package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.UCNotificationCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.UCNotification;
import edu.curtin.i3.superlab.repository.*;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.UCNotificationServiceImpl;
import edu.curtin.i3.superlab.service.UserService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.util.Date;
import java.util.HashSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class NotificationsControllerTest extends AbstractControllerTest{

    private String STUDENT_PASSWORD = "123454";
    private String UC_PASSOWRD  = "awegqweg";
    private String INVIG_PASSWORD = "ikewek";
    private String INVALID_INVIG_PASSWORD = "ikewek";


    private Assessment assessment;

    private User student;
    private User uc;
    private User invig;
    private User invalidInvig;

    @Autowired
    private UserService userService;

    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private UCNotificationServiceImpl ucNotificationService;

    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    @Autowired
    private UCNotificationRepository ucNotificationRepository;


    @BeforeEach
    public void setup() throws SignupException, IOException {
        this.createUsers();
        AssessmentCreation assessmentCreation = new AssessmentCreation();
        assessmentCreation.setName("new test assessment");
        assessmentCreation.setUnitCode("abc");
        assessmentCreation.setStartsAt(new Date());
        assessmentCreation.setDuration(Duration.ofHours(2));
        assessmentCreation.setStudents(Stream.of(student.getCurtinId()).collect(Collectors.toCollection(HashSet::new)));
        assessmentCreation.setInvigilators(Stream.of(invig.getCurtinId()).collect(Collectors.toCollection(HashSet::new)));
        assessmentCreation.setFiles(new MultipartFile[]{});
        this.assessment = assessmentService.createAssessment(uc, assessmentCreation);

        //create notification
        UCNotificationCreation ucNotificationCreation = new UCNotificationCreation();
        ucNotificationCreation.setAssessment(assessment.getUuid());
        ucNotificationCreation.setMessage("test notification");
        ucNotificationService.createUCNotification(ucNotificationCreation, invig);
    }

    @AfterEach
    public void tearDown(){
        this.deleteUsers();
        this.ucNotificationRepository.deleteAll();
        this.studentAssessmentDetailsRepository.deleteAll();
        this.invigilatorAssessmentDetailsRepository.deleteAll();
        this.assessmentRepository.deleteAll();
    }

    @Test
    public void testGetNotifications(){

        //check that valid students & uc can retrieve
        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD);
        ResponseEntity<UCNotification[]> validUCNotifcationListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications/list/" + assessment.getUuid(),
                HttpMethod.GET,
                httpEntityWithAuthHeader,
                UCNotification[].class
        );
        assertEquals(HttpStatus.OK, validUCNotifcationListResponse.getStatusCode());
        assertEquals(1, validUCNotifcationListResponse.getBody().length);
        //check that invalid invigilator cannot retrieve
        HttpEntity invalidhttpEntityWithAuthHeader = loginAndGetAuthHttpEntity(invalidInvig, INVALID_INVIG_PASSWORD);
        ResponseEntity<UCNotification[]> invalidUCNotifcationListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications/list/" + assessment.getUuid(),
                HttpMethod.GET,
                invalidhttpEntityWithAuthHeader,
                UCNotification[].class
        );
        assertEquals(HttpStatus.FORBIDDEN, invalidUCNotifcationListResponse.getStatusCode());
    }

    @Test
    public void testCreateNotification(){

        //check that uc can create
        HttpEntity ucHttpEntity = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        HttpHeaders ucAuthHeaders = ucHttpEntity.getHeaders();
        UCNotificationCreation ucNotificationCreation = new UCNotificationCreation();
        ucNotificationCreation.setAssessment(assessment.getUuid());
        ucNotificationCreation.setMessage("test12213344");
        HttpEntity<UCNotificationCreation> ucCreateNotification = new HttpEntity<UCNotificationCreation>(ucNotificationCreation, ucAuthHeaders);
        ResponseEntity<Void> validUCNotifcationCreateResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications",
                HttpMethod.PUT,
                ucCreateNotification,
                Void.class
        );
        //check that new entry has been created
        Assertions.assertEquals(HttpStatus.OK, validUCNotifcationCreateResponse.getStatusCode());
        ResponseEntity<UCNotification[]> validUCNotifcationListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications/list/" + assessment.getUuid(),
                HttpMethod.GET,
                ucHttpEntity,
                UCNotification[].class
        );
        assertEquals(2, validUCNotifcationListResponse.getBody().length);

        //check that invalid invigilator cannot create
        HttpHeaders invaligInvigHeaders = loginAndGetAuthHttpEntity(invalidInvig, INVALID_INVIG_PASSWORD).getHeaders();
        HttpEntity<UCNotificationCreation> invalidInvigCreateNotificationEntity = new HttpEntity<UCNotificationCreation>(ucNotificationCreation, invaligInvigHeaders);
        ResponseEntity<Void> invalidInvigUCNotifcationCreateResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications",
                HttpMethod.PUT,
                invalidInvigCreateNotificationEntity,
                Void.class
        );
        assertEquals(HttpStatus.FORBIDDEN, invalidInvigUCNotifcationCreateResponse.getStatusCode());

        //check that student cannot create
        HttpHeaders studentHeaders = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD).getHeaders();
        HttpEntity<UCNotificationCreation> studentCreateNotificationEntity = new HttpEntity<UCNotificationCreation>(ucNotificationCreation, studentHeaders);
        ResponseEntity<Void> studentUCNotificationCreateResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/notifications",
                HttpMethod.PUT,
                studentCreateNotificationEntity,
                Void.class
        );
        assertEquals(HttpStatus.FORBIDDEN, studentUCNotificationCreateResponse.getStatusCode());
    }



    private void createUsers() throws SignupException {
        student = this.getFakeStudent();
        Signup signup = createSignup(student, STUDENT_PASSWORD);
        student = userService.createUser(signup, "STUDENT");

        uc = this.getFakeUC();
        Signup ucSignup = this.createSignup(uc, UC_PASSOWRD);
        uc = this.userService.createUser(ucSignup, "UC");

        invig = this.getFakeInvigilator();
        Signup invigSignup = createSignup(invig, INVIG_PASSWORD);
        invig = this.userService.createUser(invigSignup, "INVIGILATOR");

        invalidInvig = this.getFakeInvigilator();
        invalidInvig.setCurtinId(1982398498);
        invalidInvig.setEmail("test@t.com");
        Signup invalidInvigSignup = createSignup(invalidInvig, INVALID_INVIG_PASSWORD);
        invalidInvig = this.userService.createUser(invalidInvigSignup, "INVIGILATOR");
    }

    private void deleteUsers(){
        userService.deleteUser(student.getId());
        userService.deleteUser(uc.getId());
        userService.deleteUser(invig.getId());
        userService.deleteUser(invalidInvig.getId());
    }


}

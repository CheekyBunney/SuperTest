package edu.curtin.i3.superlab.selenium.uc.client;

import edu.curtin.i3.superlab.selenium.AbstractPageTest;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public abstract class AbstractUCClientPageTest extends AbstractPageTest {

    private static int UC_CLIENT_PORT = 4000;


    @Override
    protected String getApplicationUrl() {
        return "http://localhost:" + UC_CLIENT_PORT;
    }
}

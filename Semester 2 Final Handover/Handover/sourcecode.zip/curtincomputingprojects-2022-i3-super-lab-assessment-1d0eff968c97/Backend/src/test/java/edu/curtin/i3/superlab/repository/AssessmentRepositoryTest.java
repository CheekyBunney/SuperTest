package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;

import javax.transaction.Transactional;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AssessmentRepositoryTest extends AbstractRepositoryTest{

    @Autowired
    private AssessmentRepository assessmentRepository;


    private User uc;
    private User student;

    @BeforeEach
    public void setup(){
        uc = this.getFakeUC();
        student = this.getFakeStudent();
    }

    @AfterEach
    public void tearDown(){
        assessmentRepository.deleteAll();
    }

    @Test
    @Transactional
    public void createAssessment() throws Exception {
        Assessment assessment = this.getFakeAssessment(this.uc);
        assessmentRepository.save(assessment);
        Assessment readAssessment = assessmentRepository.findById(assessment.getUuid()).orElseThrow(() -> new Exception("test failed, cant find assessment"));
        Assertions.assertEquals(assessment.getName(),readAssessment.getName());
        Assertions.assertEquals(assessment.getCreatedAt(),readAssessment.getCreatedAt());
        Assertions.assertEquals(assessment.getCreatedBy(),readAssessment.getCreatedBy());
        Assertions.assertEquals(assessment.getStartsAt(),readAssessment.getStartsAt());
        Assertions.assertEquals(assessment.getDuration(),readAssessment.getDuration());
        Assertions.assertEquals(assessment.isReleasedToStudents(),readAssessment.isReleasedToStudents());
    }


}

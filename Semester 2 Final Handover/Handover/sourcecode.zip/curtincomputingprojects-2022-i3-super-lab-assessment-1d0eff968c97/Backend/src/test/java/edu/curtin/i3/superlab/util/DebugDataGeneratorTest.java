package edu.curtin.i3.superlab.util;

import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.repository.*;
import edu.curtin.i3.superlab.service.UserService;
import org.checkerframework.checker.units.qual.A;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.Duration;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = { "super_lab.create_debug_data=true" })
@Testcontainers
@ActiveProfiles({"test", "dev"})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class DebugDataGeneratorTest {

    @Autowired
    private AssessmentRepository assessmentRepository;
    @Autowired
    private DurationModificationsRepository durationModificationsRepository;
    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;
    @Autowired
    private StudentAssessmentDetailsRepository assessmentDetailsRepository;
    @Autowired
    private StudentQuestionsRepository studentQuestionsRepository;
    @Autowired
    private UCNotificationRepository ucNotificationRepository;

    @AfterEach
    public void tearDown(){
        durationModificationsRepository.deleteAll();
        studentQuestionsRepository.deleteAll();
        ucNotificationRepository.deleteAll();
        assessmentDetailsRepository.deleteAll();
        invigilatorAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();

    }

    @Test
    public void testDebugDataGenerator() {
        Assertions.assertEquals(6, assessmentRepository.count());
        Assertions.assertEquals(8, invigilatorAssessmentDetailsRepository.count());
        Assertions.assertEquals(21, assessmentDetailsRepository.count());
        Assertions.assertEquals(5, durationModificationsRepository.count());
        Assertions.assertEquals(3, studentQuestionsRepository.count());
        Assertions.assertEquals(3, ucNotificationRepository.count());

    }
}

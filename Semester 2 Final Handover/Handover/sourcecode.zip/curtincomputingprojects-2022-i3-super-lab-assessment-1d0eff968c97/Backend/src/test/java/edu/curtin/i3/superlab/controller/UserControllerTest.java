package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.Login;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.service.UserService;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.*;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;

import java.util.Arrays;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class UserControllerTest extends AbstractControllerTest{
    @Autowired
    private UserService userService;

    String STUDENT_PASSWORD = "123454";
    String UC_PASSOWRD  = "awegqweg";
    User student;
    User uc;

    @BeforeAll
    public void setup() throws SignupException {
        student = this.getFakeStudent();
        Signup signup = createSignup(student, STUDENT_PASSWORD);
        student = userService.createUser(signup, "STUDENT");
        uc = this.getFakeUC();
        Signup ucSignup = this.createSignup(uc, UC_PASSOWRD);
        uc = this.userService.createUser(ucSignup, "UC");
    }

    @AfterAll
    public void tearDown(){
        userService.deleteUser(student.getId());
        userService.deleteUser(uc.getId());
    }

    @Test
    public void testListCustomers(){
        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        ResponseEntity<User[]> userListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/users/list",
                HttpMethod.GET,
                httpEntityWithAuthHeader,
                User[].class
        );
        Assertions.assertEquals(HttpStatus.OK, userListResponse.getStatusCode());
        User[] users = userListResponse.getBody();
        boolean hasStudent = Arrays.stream(users).anyMatch(u -> u.getId().equals(student.getId()));
        Assertions.assertTrue(hasStudent);
        boolean hasUC = Arrays.stream(users).anyMatch(u -> u.getId().equals(uc.getId()));
        Assertions.assertTrue(hasUC);
    }



    @Test
    public void testListCustomersOnlyWorksForUC(){
        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD);
        ResponseEntity<Void> userListResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/users/list",
                HttpMethod.GET,
                httpEntityWithAuthHeader,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.FORBIDDEN, userListResponse.getStatusCode());
    }


}

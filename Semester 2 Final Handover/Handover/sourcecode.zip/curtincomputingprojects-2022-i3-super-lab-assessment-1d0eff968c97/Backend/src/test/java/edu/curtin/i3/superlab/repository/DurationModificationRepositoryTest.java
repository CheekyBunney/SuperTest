package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.DurationModification;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;


@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class DurationModificationRepositoryTest extends AbstractRepositoryTest{
    @Autowired
    private DurationModificationsRepository durationModificationsRepository;
    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;
    @Autowired
    private AssessmentRepository assessmentRepository;
    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;

    private User uc;
    private User student;
    private Assessment assessment;
    private StudentAssessmentDetails studentAssessmentDetails;

    @BeforeEach
    public void setup() {
        uc = this.getFakeUC();
        student = this.getFakeStudent();

        assessment = this.getFakeAssessment(uc);
        assessmentRepository.saveAndFlush(assessment);
        studentAssessmentDetails = this.getFakeStudentAssessmentDetails(assessment, student);
        studentAssessmentDetailsRepository.saveAndFlush(studentAssessmentDetails);
    }

    @AfterEach
    public void tearDown(){
        durationModificationsRepository.deleteAll();
        studentAssessmentDetailsRepository.deleteAll();
        invigilatorAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();
    }
    @Test
    public void createDurationModification() throws Exception {
        DurationModification modification = this.getFakeDurationModification(uc, studentAssessmentDetails);
        durationModificationsRepository.save(modification);
        DurationModification readModification = durationModificationsRepository.findById(modification.getUuid()).orElseThrow(() -> new Exception("test failed, cant find duration modification"));
        Assertions.assertEquals(modification.getStudentAssessmentDetails(),readModification.getStudentAssessmentDetails());
        Assertions.assertEquals(modification.getCreatedBy(),readModification.getCreatedBy());
        Assertions.assertEquals(modification.getCreatedAt(),readModification.getCreatedAt());
        Assertions.assertEquals(modification.getDuration(),readModification.getDuration());
        Assertions.assertEquals(modification.getReason(),readModification.getReason());
    }

    @Test
    public void failToCreateDurationModificationWithNoCreator(){
        DurationModification modification1 = this.getFakeDurationModification(uc, studentAssessmentDetails);
        modification1.setCreatedBy(null);
        Assertions.assertThrows(DataIntegrityViolationException.class, ()-> durationModificationsRepository.save(modification1));

    }

}

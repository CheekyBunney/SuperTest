package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import edu.curtin.i3.superlab.data.orm.StudentQuestion;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class StudentQuestionRepositoryTest extends AbstractRepositoryTest{

    @Autowired
    private StudentQuestionsRepository studentQuestionsRepository;
    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    private User uc;
    private User student;
    private Assessment assessment;
    private StudentAssessmentDetails studentAssessmentDetails;

    @BeforeEach
    public void setup() {
        uc = this.getFakeUC();
        student = this.getFakeStudent();
        assessment = this.getFakeAssessment(uc);
        assessmentRepository.saveAndFlush(assessment);
        studentAssessmentDetails = this.getFakeStudentAssessmentDetails(assessment, student);
        studentAssessmentDetailsRepository.saveAndFlush(studentAssessmentDetails);
    }

    @AfterEach
    public void tearDown(){
        studentQuestionsRepository.deleteAll();
        studentAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();
    }
    @Test
    public void createStudentQuestion() throws Exception {
        StudentQuestion studentQuestion = this.getFakeStudentQuestion(studentAssessmentDetails, uc);
        studentQuestionsRepository.save(studentQuestion);
        StudentQuestion readStudentQuestion = studentQuestionsRepository.findById(studentQuestion.getUuid()).orElseThrow(() -> new Exception("test failed, cant find student question"));
        Assertions.assertEquals(studentQuestion.getStudentAssessmentDetails(), readStudentQuestion.getStudentAssessmentDetails());
        Assertions.assertEquals(studentQuestion.getQuestion(), readStudentQuestion.getQuestion());
        Assertions.assertEquals(studentQuestion.getCreatedAt(), readStudentQuestion.getCreatedAt());
        Assertions.assertEquals(studentQuestion.getResolvedBy(), readStudentQuestion.getResolvedBy());
        Assertions.assertEquals(studentQuestion.getResolvedAt(), readStudentQuestion.getResolvedAt());
    }
}

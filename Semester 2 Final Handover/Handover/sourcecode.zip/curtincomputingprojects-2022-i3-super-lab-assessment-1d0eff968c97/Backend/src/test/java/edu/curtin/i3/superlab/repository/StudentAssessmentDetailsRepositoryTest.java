package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

import javax.transaction.Transactional;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class StudentAssessmentDetailsRepositoryTest extends AbstractRepositoryTest{

    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    private User uc;
    private User student;
    private Assessment assessment;
    private StudentAssessmentDetails details;

    @BeforeEach
    public void setup(){
        uc = this.getFakeUC();
        student = this.getFakeStudent();
        assessment = this.getFakeAssessment(uc);
        details = this.getFakeStudentAssessmentDetails(this.assessment, this.student);
        assessmentRepository.saveAndFlush(assessment);
    }

    @AfterEach
    public void tearDown(){
        studentAssessmentDetailsRepository.deleteAll();
        assessmentRepository.deleteAll();
    }

    @Test
    @Transactional
    public void createStudentAssessmentDetails() throws Exception {
        studentAssessmentDetailsRepository.save(details);
        StudentAssessmentDetails readDetails = studentAssessmentDetailsRepository.findById(details.getUuid()).orElseThrow(() -> new Exception("test failed, cant find assessment"));

        Assertions.assertEquals(details.getAssessment().getUuid(),readDetails.getAssessment().getUuid());
        Assertions.assertEquals(details.getStudent(),readDetails.getStudent());
        Assertions.assertEquals(details.getFinishTime(),readDetails.getFinishTime());
    }

    @Test
    public void failToCreateWithNonExistentStudent(){
        details.setStudent(null);
        Assertions.assertThrows(DataIntegrityViolationException.class, ()-> studentAssessmentDetailsRepository.save(details));
    }

    @Test
    public void testFindByStudentAndAssessment(){
        StudentAssessmentDetails savedDetails = studentAssessmentDetailsRepository.save(details);
        StudentAssessmentDetails foundDetails  = studentAssessmentDetailsRepository.findByStudentAndAssessment(details.getStudent(), details.getAssessment());
        Assertions.assertEquals(savedDetails.getUuid(), foundDetails.getUuid());
        StudentAssessmentDetails failedFind  = studentAssessmentDetailsRepository.findByStudentAndAssessment("Non existent user", details.getAssessment());
        Assertions.assertNull(failedFind);

    }
}

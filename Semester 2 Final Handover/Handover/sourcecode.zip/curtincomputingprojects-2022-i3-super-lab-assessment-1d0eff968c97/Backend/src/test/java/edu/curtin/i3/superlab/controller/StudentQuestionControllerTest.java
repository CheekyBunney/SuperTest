package edu.curtin.i3.superlab.controller;


import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.StudentQuestionCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentQuestion;
import edu.curtin.i3.superlab.repository.AssessmentRepository;
import edu.curtin.i3.superlab.repository.InvigilatorAssessmentDetailsRepository;
import edu.curtin.i3.superlab.repository.StudentAssessmentDetailsRepository;
import edu.curtin.i3.superlab.repository.StudentQuestionsRepository;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.StudentQuestionService;
import edu.curtin.i3.superlab.service.UserService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class StudentQuestionControllerTest extends AbstractControllerTest{


    private String STUDENT_PASSWORD = "123454";
    private String STUDENT_PASSWORD2 = "1234512124";
    private String UC_PASSOWRD  = "awegqweg";
    private String INVIG_PASSWORD = "ikewek";


    private Assessment assessment;

    private User student;
    private User student2;
    private User uc;
    private User invig;

    private StudentQuestion studentQuestion;

    @Autowired
    private UserService userService;

    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    @Autowired
    private StudentQuestionService studentQuestionService;

    @Autowired
    private StudentQuestionsRepository studentQuestionsRepository;

    @BeforeEach
    public void setup() throws SignupException, IOException {
        this.createUsers();
        AssessmentCreation assessmentCreation = new AssessmentCreation();
        assessmentCreation.setName("new test assessment");
        assessmentCreation.setUnitCode("abc");
        assessmentCreation.setStartsAt(new Date());
        assessmentCreation.setDuration(Duration.ofHours(2));
        assessmentCreation.setStudents(Stream.of(student.getCurtinId(), student2.getCurtinId()).collect(Collectors.toCollection(HashSet::new)));
        assessmentCreation.setInvigilators(Stream.of(invig.getCurtinId()).collect(Collectors.toCollection(HashSet::new)));
        assessmentCreation.setFiles(new MultipartFile[]{});
        this.assessment = assessmentService.createAssessment(uc, assessmentCreation);

        //create question
        StudentQuestionCreation studentQuestionCreation = new StudentQuestionCreation();
        studentQuestionCreation.setQuestion("whats the answerr????");
        studentQuestionCreation.setAssessment(assessment.getUuid());
        studentQuestion = studentQuestionService.createStudentQuestion(studentQuestionCreation, student);

        StudentQuestionCreation studentQuestionCreation2 = new StudentQuestionCreation();
        studentQuestionCreation2.setQuestion("whats the answerr???? please???");
        studentQuestionCreation2.setAssessment(assessment.getUuid());
        studentQuestionService.createStudentQuestion(studentQuestionCreation2, student2);

    }

    @AfterEach
    public void tearDown(){
        this.deleteUsers();
        this.studentQuestionsRepository.deleteAll();
        this.studentAssessmentDetailsRepository.deleteAll();
        this.invigilatorAssessmentDetailsRepository.deleteAll();
        this.assessmentRepository.deleteAll();
    }

    @Test
    public void testListQuestionForStudents(){
        //assert works for students
        HttpEntity httpEntityWithAuthHeader = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD);
        ResponseEntity<StudentQuestion[]> studentResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions/STUDENT/list/" + assessment.getUuid(),
                HttpMethod.GET,
                httpEntityWithAuthHeader,
                StudentQuestion[].class
        );
        Assertions.assertEquals(HttpStatus.OK, studentResponse.getStatusCode());
        Assertions.assertEquals(1, studentResponse.getBody().length);
    }

    @Test
    public void testListQuestionForUCs(){
        //assert works for uc
        HttpEntity httpEntityWithAuthHeaderUC = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        ResponseEntity<StudentQuestion[]> ucResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions/UC/list/" + assessment.getUuid(),
                HttpMethod.GET,
                httpEntityWithAuthHeaderUC,
                StudentQuestion[].class
        );
        Assertions.assertEquals(HttpStatus.OK, ucResponse.getStatusCode());
        Assertions.assertEquals(2, ucResponse.getBody().length);
    }

    @Test
    public void testCreateQuestion(){
        String questionMsg = "test quesiton message213123";
        StudentQuestionCreation studentQuestionCreation = new StudentQuestionCreation();
        studentQuestionCreation.setQuestion(questionMsg);
        studentQuestionCreation.setAssessment(assessment.getUuid());
        HttpEntity ucEntity = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        HttpEntity<StudentQuestionCreation> ucQuestionEntity = new HttpEntity<StudentQuestionCreation>(studentQuestionCreation, ucEntity.getHeaders());
        ResponseEntity<Void> ucResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions",
                HttpMethod.PUT,
                ucQuestionEntity,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.FORBIDDEN, ucResponse.getStatusCode());

        //test that it works for student
        HttpEntity studentEntity = loginAndGetAuthHttpEntity(student, STUDENT_PASSWORD);
        HttpEntity<StudentQuestionCreation> studentQuestionCreationHttpEntity = new HttpEntity<StudentQuestionCreation>(studentQuestionCreation, studentEntity.getHeaders());
        ResponseEntity<Void> studentResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions",
                HttpMethod.PUT,
                studentQuestionCreationHttpEntity,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.OK, studentResponse.getStatusCode());
        //check that its added
        ResponseEntity<StudentQuestion[]> studentResponseList = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions/STUDENT/list/" + assessment.getUuid(),
                HttpMethod.GET,
                studentEntity,
                StudentQuestion[].class
        );
        Assertions.assertEquals(HttpStatus.OK, studentResponseList.getStatusCode());
        //find question with identical msg
        StudentQuestion studentQuestion = Arrays.stream(studentResponseList.getBody()).filter(q -> q.getQuestion().equals(questionMsg)).findFirst().orElse(null);
        Assertions.assertNotNull(studentQuestion);

    }

    @Test
    public void testResolveQuestion(){
        //check it works for uc
        HttpEntity httpEntityWithAuthHeaderUC = loginAndGetAuthHttpEntity(uc, UC_PASSOWRD);
        ResponseEntity<Void> ucResponse = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions/resolve/" + studentQuestion.getUuid(),
                HttpMethod.PUT,
                httpEntityWithAuthHeaderUC,
                Void.class
        );
        Assertions.assertEquals(HttpStatus.OK, ucResponse.getStatusCode());
        //check that its retrieved by list
        ResponseEntity<StudentQuestion[]> ucResponseList = this.restTemplate.exchange(
                "http://localhost:" + this.port + "/questions/UC/list/" + assessment.getUuid(),
                HttpMethod.GET,
                httpEntityWithAuthHeaderUC,
                StudentQuestion[].class
        );
        Assertions.assertEquals(HttpStatus.OK, ucResponseList.getStatusCode());
        StudentQuestion studentQuestion = Arrays.stream(ucResponseList.getBody()).filter(q -> q.getUuid().equals(this.studentQuestion.getUuid())).findFirst().orElse(null);
        Assertions.assertEquals(uc.getId(), studentQuestion.getResolvedBy());
    }




    private void createUsers() throws SignupException {
        student = this.getFakeStudent();
        Signup signup = createSignup(student, STUDENT_PASSWORD);
        student = userService.createUser(signup, "STUDENT");

        student2 = this.getFakeStudent();
        student2.setCurtinId(212349819);
        student2.setEmail("1111@test.com");
        Signup signup2 = createSignup(student2, STUDENT_PASSWORD2);
        student2 = userService.createUser(signup2, "STUDENT");

        uc = this.getFakeUC();
        Signup ucSignup = this.createSignup(uc, UC_PASSOWRD);
        uc = this.userService.createUser(ucSignup, "UC");

        invig = this.getFakeInvigilator();
        Signup invigSignup = createSignup(invig, INVIG_PASSWORD);
        invig = this.userService.createUser(invigSignup, "INVIGILATOR");

    }

    private void deleteUsers(){
        userService.deleteUser(student.getId());
        userService.deleteUser(student2.getId());
        userService.deleteUser(uc.getId());
        userService.deleteUser(invig.getId());
    }
}

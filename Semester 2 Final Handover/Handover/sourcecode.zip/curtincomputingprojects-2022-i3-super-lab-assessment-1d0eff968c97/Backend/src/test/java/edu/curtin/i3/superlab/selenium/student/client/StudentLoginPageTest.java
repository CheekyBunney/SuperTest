package edu.curtin.i3.superlab.selenium.student.client;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.service.UserService;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class StudentLoginPageTest extends AbstractStudentClientPageTest {

    private WebDriver webDriver;

    @Autowired
    private UserService userService;

    String STUDENT_PASSWORD = "123454";
    String UC_PASSOWRD  = "awegqweg";
    User student;
    User uc;

    @BeforeAll
    public void setup() throws SignupException {
        createUsers();
    }

    @BeforeEach
    public void beforeEach(){
        webDriver = this.getChromeDriver();
        this.loadWebsite(this.webDriver);
    }

    @Test
    public void testCorrectUrl() throws InterruptedException {
        synchronized (this.webDriver){
            this.webDriver.wait(500);
        }
        Assertions.assertEquals(this.getApplicationUrl() + "/login", this.webDriver.getCurrentUrl());
    }

    @Test
    public void testStudentLoginAndLogout() throws InterruptedException {
        login(student.getCurtinId(), STUDENT_PASSWORD);
        //check that dashboard page is showing
        Assertions.assertEquals(this.getApplicationUrl() + "/", this.webDriver.getCurrentUrl());
        logout();
        Assertions.assertEquals(this.getApplicationUrl() + "/login", this.webDriver.getCurrentUrl());
    }

    @Test
    public void testBadPassword() throws InterruptedException {
        login(uc.getCurtinId(), "BAD PASSWORD");
        List<WebElement> loginFailedLabels = this.webDriver.findElements(new By.ById("login-failed-lbl"));
        Assertions.assertEquals(1, loginFailedLabels.size());
    }

    @Test
    public void testUCLogin() throws InterruptedException {
        login(uc.getCurtinId(), UC_PASSOWRD);
        List<WebElement> loginFailedLabels = this.webDriver.findElements(new By.ById("login-failed-lbl"));
        //student shouldnt be able to login into the student client
        Assertions.assertEquals(1, loginFailedLabels.size());
    }

    @AfterEach
    public void tearDown(){
        this.webDriver.close();
    }

    @AfterAll
    public void tearDownAfterAll(){
        this.deleteUsers();
    }

    protected void login(int curtinId, String password) throws InterruptedException {
        this.webDriver.findElement(new By.ById("curtinID")).sendKeys(Integer.toString(curtinId));
        this.webDriver.findElement(new By.ById("password")).sendKeys(password);
        WebElement submit = this.webDriver.findElement(new By.ById("submit"));
        submit.click();
        synchronized (submit){
            submit.wait(1000);
        }
    }

    protected void logout() throws InterruptedException {
        WebElement logoutBtn = this.webDriver.findElement(new By.ById("logout-btn"));
        logoutBtn.click();
        synchronized (logoutBtn){
            logoutBtn.wait(1000);
        }
    }

    private void createUsers() throws SignupException {
        student = this.getFakeStudent();
        uc = this.getFakeUC();
        Signup signup = createSignup(student, STUDENT_PASSWORD);
        Signup ucSignup = this.createSignup(uc, UC_PASSOWRD);
        //users may exists from old tests
        deleteUsers();
        student = createUserIfNeed(signup, "STUDENT");
        uc = createUserIfNeed(ucSignup, "UC");
    }

    private User createUserIfNeed(Signup signup, String role) throws SignupException {
        User user = userService.getUser(signup.getCurtinId());
        if(user == null){
            return userService.createUser(signup, role);
        } else {
            return user;
        }
    }

    private void deleteUsers(){
        userService.deleteUser(Integer.toString(uc.getCurtinId()));
        userService.deleteUser(Integer.toString(student.getCurtinId()));
    }
}


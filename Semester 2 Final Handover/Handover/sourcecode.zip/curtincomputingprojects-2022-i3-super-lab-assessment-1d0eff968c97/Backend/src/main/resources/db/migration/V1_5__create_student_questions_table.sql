CREATE TABLE public."student_questions" (
    uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY,
    student_assessment uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    resolved_at timestamp without time zone,
    question text NOT NULL,
    resolved_by text,
    CONSTRAINT "FK_S_Q_STUDENT_ASSESSMENT_UUID"
        FOREIGN KEY (student_assessment)
            REFERENCES public."student_assessment_details"(uuid)
);
CREATE TABLE public."assessments" (
      uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY ,
      name text NOT NULL,
      created_at timestamp without time zone DEFAULT now() NOT NULL,
      created_by text NOT NULL,
      starts_at timestamp without time zone NOT NULL,
      duration interval NOT NULL,
      is_released_to_students boolean NOT NULL,
      assessment_folder_path text NOT NULL
);
create table password_reset_tokens
(
	token uuid default uuid_generate_v4() not null,
	created_by text not null,
	expiry_date timestamp without time zone not null
);

create unique index password_reset_tokens_token_uindex
	on password_reset_tokens (token);

alter table password_reset_tokens
	add constraint password_reset_tokens_pk
		primary key (token);


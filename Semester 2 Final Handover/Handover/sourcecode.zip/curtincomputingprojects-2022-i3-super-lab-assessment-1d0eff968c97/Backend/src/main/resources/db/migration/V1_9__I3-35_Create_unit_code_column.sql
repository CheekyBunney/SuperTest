alter table assessments
    add "unit_code" text;
#!/bin/sh
# $1 is the user to delete
deluser $1
#exit with the error code of deluser
exit $?
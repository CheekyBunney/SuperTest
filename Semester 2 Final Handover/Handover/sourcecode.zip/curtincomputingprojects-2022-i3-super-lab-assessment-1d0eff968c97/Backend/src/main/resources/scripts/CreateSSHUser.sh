#!/bin/sh
# $1 is username
# $2 is password
#create user
echo "$2
$2
" | adduser $1
#check that user exists
id $1
# exit with the exit code of the id command
# if 0 = success
# else = failure
exit $?

##Requirements
- Install Postgresql database

##Flyway
Runs automatically as part spring application. Can also be run through maven
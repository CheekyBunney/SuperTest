alter table uc_notifications drop column resolved_by;
alter table uc_notifications drop column resolved_at;

alter table student_assessment_details alter column finish_time drop not null;
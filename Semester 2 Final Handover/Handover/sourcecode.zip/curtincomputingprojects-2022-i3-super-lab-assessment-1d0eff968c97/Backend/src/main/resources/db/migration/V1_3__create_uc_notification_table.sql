CREATE TABLE public."uc_notifications" (
   uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY ,
   assessment uuid NOT NULL,
   created_by text NOT NULL,
   created_at timestamp without time zone DEFAULT now() NOT NULL,
   resolved_by text NOT NULL,
   resolved_at timestamp without time zone DEFAULT now() NOT NULL,
   message text NOT NULL,
   CONSTRAINT "FK_UC_N_ASSESSMENT"
       FOREIGN KEY (assessment)
           REFERENCES public."assessments"(uuid)
);

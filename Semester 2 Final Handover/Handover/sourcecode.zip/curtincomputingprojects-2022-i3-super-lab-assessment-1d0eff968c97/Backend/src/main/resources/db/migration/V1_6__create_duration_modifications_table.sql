CREATE TABLE public."duration_modifications" (
     uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY ,
     student_assessment uuid NOT NULL,
     created_by text NOT NULL,
     created_at timestamp without time zone DEFAULT now() NOT NULL,
     duration interval NOT NULL,
     reason text,
    CONSTRAINT "FK_D_M_STUDENT_ASSESSMENT"
        FOREIGN KEY (student_assessment)
            REFERENCES public."student_assessment_details"(uuid)
);
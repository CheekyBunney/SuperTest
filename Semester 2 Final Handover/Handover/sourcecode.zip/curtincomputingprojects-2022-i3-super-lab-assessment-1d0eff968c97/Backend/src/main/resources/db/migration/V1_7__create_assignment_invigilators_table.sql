CREATE TABLE public."invigilator_assessment_details" (
  uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY,
  invigilator text NOT NULL,
  assessment uuid NOT NULL,
  CONSTRAINT "FK_INVIGILATOR_ASSESSMENTS_ASSESSMENT_UUID"
      FOREIGN KEY (assessment)
          REFERENCES public."assessments"(uuid)
);
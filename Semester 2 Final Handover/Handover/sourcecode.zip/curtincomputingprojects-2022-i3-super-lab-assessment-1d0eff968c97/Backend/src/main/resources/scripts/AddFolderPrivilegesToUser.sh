#!/bin/sh
# $1 is username
# $2 is folder
#create user
chown $1: $2
exit $?
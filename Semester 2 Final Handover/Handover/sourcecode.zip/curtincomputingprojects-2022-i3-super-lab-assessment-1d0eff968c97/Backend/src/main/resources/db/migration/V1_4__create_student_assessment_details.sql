CREATE TABLE public."student_assessment_details" (
     uuid uuid DEFAULT public.uuid_generate_v4() NOT NULL PRIMARY KEY,
     student text NOT NULL,
     work_folder_path text NOT NULL,
     finish_time timestamp without time zone NOT NULL,
     assessment uuid NOT NULL,
     CONSTRAINT "FK_S_A_D_ASSESSMENT"
         FOREIGN KEY (assessment)
             REFERENCES public."assessments"(uuid)
);
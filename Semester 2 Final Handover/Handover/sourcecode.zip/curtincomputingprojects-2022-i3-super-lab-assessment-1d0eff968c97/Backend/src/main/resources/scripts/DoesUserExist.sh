#!/bin/sh
# $1 = username
id $1
exit $?
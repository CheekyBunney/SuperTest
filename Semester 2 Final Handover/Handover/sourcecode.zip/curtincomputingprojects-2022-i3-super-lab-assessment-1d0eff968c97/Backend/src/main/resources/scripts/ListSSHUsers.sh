#!/bin/sh
#$1 is the suffix that all ssh user will have
cat /etc/passwd | grep "${1}[^:]*:x:[^:]*:[^:]*:Linux User"
#exit with the error code of deluser
exit $?
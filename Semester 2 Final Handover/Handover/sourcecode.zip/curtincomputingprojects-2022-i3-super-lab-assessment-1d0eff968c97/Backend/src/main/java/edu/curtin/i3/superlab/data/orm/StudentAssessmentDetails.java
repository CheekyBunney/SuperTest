package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;
@Entity
@Table(name = "student_assessment_details")
@Getter
@Setter
@NoArgsConstructor
public class StudentAssessmentDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;

    @ManyToOne
    @JoinColumn(name = "assessment")
    private Assessment assessment;
    //userID
    private String student;
    private Date finishTime;

    //todo this work_folder_path should create the workFolder object?
    private String workFolderPath;

}

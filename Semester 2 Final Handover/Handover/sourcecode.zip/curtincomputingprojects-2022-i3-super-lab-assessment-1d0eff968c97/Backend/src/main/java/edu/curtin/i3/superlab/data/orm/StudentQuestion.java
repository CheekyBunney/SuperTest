package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "student_questions")
@Getter
@Setter
@NoArgsConstructor
public class StudentQuestion {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;

    @Column(name = "student_assessment")
    private UUID studentAssessmentDetails;

    private String question;
    private Date createdAt;
    //userID
    private String  resolvedBy;
    private Date resolvedAt;


}

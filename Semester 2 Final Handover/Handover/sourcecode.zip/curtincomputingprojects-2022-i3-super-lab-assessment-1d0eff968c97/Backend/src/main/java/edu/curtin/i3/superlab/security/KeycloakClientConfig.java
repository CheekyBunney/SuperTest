package edu.curtin.i3.superlab.security;

import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.admin.client.token.TokenManager;
import org.keycloak.authorization.client.AuthzClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static org.keycloak.OAuth2Constants.CLIENT_CREDENTIALS;

@Configuration
public class KeycloakClientConfig {
    @Value("${keycloak.credentials.secret}")
    private String secretKey;
    @Value("${keycloak.resource}")
    private String clientId;
    @Value("${keycloak.auth-server-url}")
    private String authUrl;
    @Value("${keycloak.realm}")
    private String realm;


    @Bean
    public KeycloakSpringBootConfigResolver keycloakConfigResolver() {
        return new KeycloakSpringBootConfigResolver();
    }

    @Bean
    public Keycloak keycloak() {
        return KeycloakBuilder.builder()
                .serverUrl(authUrl)
                .grantType(CLIENT_CREDENTIALS)
                .clientSecret(secretKey)
                .realm(realm)
                .clientId(clientId)
                .resteasyClient(new ResteasyClientBuilder().connectionPoolSize(20).build())
                .build();
    }

    @Bean
    public RealmResource realmResource(Keycloak keycloak) {
        return keycloak.realm(realm);
    }

    @Bean
    public TokenManager tokenManager(Keycloak keycloak){
        return keycloak.tokenManager();
    }
    @Bean
    public UsersResource userResource(RealmResource realmResource) {
        return realmResource.users();
    }

    @Bean
    public AuthzClient authzClient(){
        Map<String, Object> clientCredentials = new HashMap<>();
        clientCredentials.put("secret", secretKey);
        clientCredentials.put("grant_type", "password");

        org.keycloak.authorization.client.Configuration configuration =
                new org.keycloak.authorization.client.Configuration(authUrl, realm, clientId, clientCredentials, null);
        return AuthzClient.create(configuration);
    }

}

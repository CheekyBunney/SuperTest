package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.UCNotificationCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.UCNotification;

import java.util.List;
import java.util.UUID;

public interface UCNotificationService {

    List<UCNotification> listUCNotification(UUID assessmentUUID);

    void createUCNotification(UCNotificationCreation notificationCreation, User creator);

}

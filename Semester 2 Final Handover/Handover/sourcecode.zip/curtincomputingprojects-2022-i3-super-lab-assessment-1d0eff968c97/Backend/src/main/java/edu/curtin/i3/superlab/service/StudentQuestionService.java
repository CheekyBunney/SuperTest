package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.StudentQuestionCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.StudentQuestion;

import java.util.List;
import java.util.UUID;

public interface StudentQuestionService {

    StudentQuestion createStudentQuestion(StudentQuestionCreation questionCreation, User creator);
    void resolveQuestion(UUID questionUUID, User resolvedBy);
    StudentQuestion read(UUID questionUUID);
    UUID getAssessmentUUIDFromQuestion(UUID questionUUID);
    List<StudentQuestion> listQuestions(UUID assessmentUUID);
    List<StudentQuestion> listQuestionsAskedByStudent(UUID assessmentUUID, User student);
}

package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.rsync.RsyncConnection;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.UserService;
import edu.curtin.i3.superlab.service.rsync.RsyncManagerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.security.Principal;
import java.util.UUID;

@RequestMapping(value = "/rsync")
@Controller
public class RsyncController {

    private static Logger logger = LoggerFactory.getLogger(RsyncController.class);

    @Autowired
    private RsyncManagerService managerService;

    @Autowired
    private UserService userService;

    @Autowired
    private AssessmentService assessmentService;

    @PreAuthorize("hasRole('ROLE_STUDENT')")
    @GetMapping("/student/connection/{assessment}")
    public ResponseEntity<RsyncConnection> getRsyncConnection(@PathVariable UUID assessment, Principal principal){
        User user = userService.getUser(principal);

        //check student is part of the assessment
        boolean isStudentPartOfAssessment = assessmentService.isValidStudent(assessment, user);
        if(!isStudentPartOfAssessment){
            logger.error("not creating rsync connection for user {} in assessment {} as they are not part of the assessment", user.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        //check assessment is running
        boolean isAssessmentRunning = assessmentService.isAssessmentRunning(assessment);
        if(!isAssessmentRunning){
            logger.error("not creatign rsync connection for user {} in assessment {} as the assessment is not running", user.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        RsyncConnection connection = null;
        try {
            connection = this.managerService.createConnection(user, assessment);
        } catch (InterruptedException | IOException e) {
            logger.error("failed to create connection for user {} assessment {}", user, assessment, e);
            return ResponseEntity.internalServerError().body(null);
        }
        return ResponseEntity.ok(connection);
    }

}


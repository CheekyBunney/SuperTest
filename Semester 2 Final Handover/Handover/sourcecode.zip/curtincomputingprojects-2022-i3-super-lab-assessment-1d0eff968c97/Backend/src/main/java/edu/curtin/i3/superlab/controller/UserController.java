package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.service.UserService;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;


@RequestMapping(value = "/users")
@RestController
public class UserController {

    @Autowired
    private UserService userService;


    @GetMapping("/")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<User> getUserDetails(Principal principal){
        User user = this.userService.getUser(principal);
        return ResponseEntity.ok(user);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<Void> createUser(@RequestBody Signup signup) throws SignupException {

        userService.createUser(signup, "STUDENT");
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_UC')")
    @GetMapping(path = "/list")
    public List<User> listUsers() {
        return userService.listUsers();
    }

}
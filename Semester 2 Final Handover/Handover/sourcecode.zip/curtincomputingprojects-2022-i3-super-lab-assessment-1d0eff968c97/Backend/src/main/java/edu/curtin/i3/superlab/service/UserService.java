package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;

import java.security.Principal;
import java.util.List;
import java.util.Set;

public interface UserService {
    List<User> listUsers();
    User getUser(int curtinId);
    User getUser(String UserUuid);
    User getUser(Principal principal);
    User createUser(Signup signup, String role) throws SignupException;
    void deleteUser(String id);
    void updateUser(String id, String curtinId, String firstName, String lastName, String email, String role);

    User createStudent(int curtinId);

    User createInvigilator(int curtinId);

    Set<String> getRoles(int curtinID);

    void resetPassword(User user, String newPassword);
}

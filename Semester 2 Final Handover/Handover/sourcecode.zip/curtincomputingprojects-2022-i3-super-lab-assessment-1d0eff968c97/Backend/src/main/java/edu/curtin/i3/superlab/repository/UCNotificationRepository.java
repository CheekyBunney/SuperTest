package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.UCNotification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface UCNotificationRepository extends JpaRepository<UCNotification, UUID> {
    List<UCNotification> findAllByAssessment(UUID assessment);
}

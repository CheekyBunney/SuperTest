package edu.curtin.i3.superlab.data.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class PasswordResetDTO {
    @NotNull
    private UUID token;
    @NotNull
    private int curtinId;
    @NotNull
    private String newPassword;
}

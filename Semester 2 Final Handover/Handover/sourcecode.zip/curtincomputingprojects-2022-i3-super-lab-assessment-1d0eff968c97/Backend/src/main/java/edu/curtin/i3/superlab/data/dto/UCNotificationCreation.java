package edu.curtin.i3.superlab.data.dto;

import java.util.UUID;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UCNotificationCreation {
    private UUID assessment;
    private String message;
}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.InvigilatorAssessmentDetails;
import edu.curtin.i3.superlab.repository.InvigilatorAssessmentDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class InvigilatorAssessmentDetailsServiceImpl implements InvigilatorAssessmentDetailsService {

    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;

    @Autowired
    private UserService userService;

    @Override
    public boolean isValidInvigilator(UUID assessmentUUID, User userToCheck) {
        return this.invigilatorAssessmentDetailsRepository.existsByAssessmentAndInvigilator(assessmentUUID, userToCheck.getId());
    }

    @Override
    public void createInvigilatorAssessmentDetails(Assessment assessment, Set<Integer> invigilators) {
        for (int invig : invigilators) {
            User user = userService.getUser(invig);
            //if invigilator doesnt exist create them
            if (user == null) {
                user = userService.createInvigilator(invig);
            }
            InvigilatorAssessmentDetails iaDetails = new InvigilatorAssessmentDetails();
            iaDetails.setAssessment(assessment);
            iaDetails.setInvigilator(user.getId());
            invigilatorAssessmentDetailsRepository.saveAndFlush(iaDetails);
        }
    }

    @Override
    public void updatedInvigilatorsInAssessment(Assessment assessment, Set<Integer> updatedInvigilatorSet) {
        Set<Integer> currentInvigilatorsIds = invigilatorAssessmentDetailsRepository.findByAssessmentUuid(assessment.getUuid())
                .stream()
                .map((InvigilatorAssessmentDetails::getInvigilator))
                .map(uuid -> userService.getUser(uuid).getCurtinId())
                .collect(Collectors.toSet());

        Set<Integer> invigilatorsToAdd = filterUnionFromSet(updatedInvigilatorSet, currentInvigilatorsIds);
        Set<Integer> invigilatorsToDelete = filterUnionFromSet(currentInvigilatorsIds, updatedInvigilatorSet);

        //add invigilators
        this.createInvigilatorAssessmentDetails(assessment, invigilatorsToAdd);
        //remove invigilators
        this.removeInvigilatorsFromAssessment(assessment, invigilatorsToDelete);
    }

    @Override
    public void removeInvigilatorsFromAssessment(Assessment assessment, Set<Integer> invigilatorsToDelete) {
        for(Integer student : invigilatorsToDelete){
            invigilatorAssessmentDetailsRepository.deleteByAssessmentUuidAndInvigilator(assessment.getUuid(), Integer.toString(student));
        }
    }

    /**
     * If set A and B have an intersection C.
     * The function returns A - C
     */
    private Set<Integer> filterUnionFromSet(Set<Integer> a, Set<Integer> b) {
        return a.stream().filter(i -> !b.contains(i)).collect(Collectors.toSet());
    }
}

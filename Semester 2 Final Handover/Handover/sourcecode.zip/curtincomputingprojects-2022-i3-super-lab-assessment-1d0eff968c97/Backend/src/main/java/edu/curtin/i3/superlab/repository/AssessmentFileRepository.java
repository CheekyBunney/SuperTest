package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.Assessment;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

/**
 * This repository is only concerned with files that are given to student during an assessment.
 * This does not include or manage or include student files
 */
public interface AssessmentFileRepository {

    void saveAssessmentFile(Assessment assessment, MultipartFile multipartFile) throws IOException;

    void createZipOfAssessmentFiles(Assessment assessment) throws IOException;

    InputStream getZipOfAssessmentFile(UUID assessmentUUID) throws IOException;

    void deleteAssessmentFiles(Assessment assessment) throws IOException;
}

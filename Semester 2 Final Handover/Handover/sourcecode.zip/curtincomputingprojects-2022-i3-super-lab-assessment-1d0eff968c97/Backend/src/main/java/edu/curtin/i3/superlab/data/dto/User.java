package edu.curtin.i3.superlab.data.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.keycloak.representations.idm.UserRepresentation;

@Getter
@Setter
@NoArgsConstructor
public class User {
    private String id;
    private String email;
    private String firstName;
    private String lastName;
    private int curtinId;

    public User(UserRepresentation userRepresentation){
        this.id = userRepresentation.getId();
        this.email = userRepresentation.getEmail();
        this.firstName = userRepresentation.getFirstName();
        this.lastName = userRepresentation.getLastName();
        this.curtinId = Integer.parseInt(userRepresentation.getUsername());
    }
}
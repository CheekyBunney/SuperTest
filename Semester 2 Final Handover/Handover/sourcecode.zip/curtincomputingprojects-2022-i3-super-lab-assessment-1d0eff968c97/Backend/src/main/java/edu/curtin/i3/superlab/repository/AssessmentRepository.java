package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, UUID> {
    public List<Assessment> findAssessmentsByCreatedBy(String userUuid);

    @Query("SELECT a FROM Assessment a JOIN StudentAssessmentDetails s on s.assessment = a.uuid WHERE s.student = ?1")
    List<Assessment> findAllByStudentUUID(String studentUUID);

    boolean existsByUuidAndCreatedBy(UUID uuid, String createdBy);

}

package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.ws.rs.PathParam;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RequestMapping(value = "/assessments")
@Controller
public class AssessmentController {


    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private UserService userService;


    @PreAuthorize("hasRole('ROLE_UC')")
    @GetMapping(path = "/UC/list")
    public ResponseEntity<List<Assessment>>getUCAssessments(Principal principal){
        User uc = userService.getUser(principal);
        List<Assessment> assessmentList = assessmentService.listAssessmentByUC(uc);
        return new ResponseEntity<>(assessmentList, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_STUDENT')")
    @GetMapping("/student/list")
    public ResponseEntity<List<Assessment>> getStudentAssessments(Principal principal){
        User student = userService.getUser(principal);
        List<Assessment> assessments = assessmentService.listAssessmentsByStudent(student);
        return ResponseEntity.ok(assessments);
    }

    @PutMapping(value = "/", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('ROLE_UC')")
    public ResponseEntity<Void> createAssessment(@Valid @ModelAttribute AssessmentCreation assessmentCreation, Principal principal) throws IOException {

        try{
            assessmentCreation.validate();
        } catch (ValidationException e){
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        }
        User uc = userService.getUser(principal);
        assessmentService.createAssessment(uc, assessmentCreation);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @PutMapping(value = "/update/{assessment}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('ROLE_UC')")
    public ResponseEntity<Void> updateAssessment(@PathVariable UUID assessment, @RequestParam boolean updateFiles, @Valid @ModelAttribute AssessmentCreation assessmentCreation, Principal principal) throws IOException {

        //validate assessmentCreation
        try{
            assessmentCreation.validate();
        } catch (ValidationException e){
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        }

        //check the uc is the  creator of the assessment
        User uc = userService.getUser(principal);
        boolean isValidUC = assessmentService.isValidUC(assessment, uc);
        if(!isValidUC){
            return new ResponseEntity<Void>(HttpStatus.FORBIDDEN);
        }

        //update the assessment
        assessmentService.updateAssessment(assessment, uc, assessmentCreation, updateFiles);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @GetMapping(value = "/files/{assessment}/zip", produces = "application/zip")
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<InputStreamResource> downLoadAssessmentFiles(@PathVariable UUID assessment) throws IOException {
        InputStreamResource assessmentFilesZip;
        try{
            assessmentFilesZip = assessmentService.getAssessmentFilesZip(assessment);

        } catch (FileNotFoundException e){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(assessmentFilesZip);
    }

}

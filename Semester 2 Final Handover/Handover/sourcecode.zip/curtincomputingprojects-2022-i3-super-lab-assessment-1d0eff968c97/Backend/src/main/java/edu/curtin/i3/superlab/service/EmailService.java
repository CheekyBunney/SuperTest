package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.mail.Email;

import javax.mail.MessagingException;
import java.util.UUID;

public interface EmailService {
    void sendHtmlMessage(Email email) throws MessagingException;

    void sendPasswordResetEmail(String email, UUID token) throws MessagingException;
}

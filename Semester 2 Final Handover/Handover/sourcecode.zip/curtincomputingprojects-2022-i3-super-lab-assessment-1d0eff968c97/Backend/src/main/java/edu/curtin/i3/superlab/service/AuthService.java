package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.exceptions.RefreshTokenException;
import org.keycloak.common.VerificationException;
import org.keycloak.representations.AccessTokenResponse;

import javax.servlet.ServletException;

public interface AuthService {
    AccessTokenResponse signIn(int curtinID, String password) throws VerificationException;
    void logout(String refreshToken) throws ServletException;
    AccessTokenResponse refreshToken(String refreshToken) throws RefreshTokenException;

}

package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Duration;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "assessments")
@Getter
@Setter
@NoArgsConstructor
public class Assessment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;
    private String unitCode;
    private String name;
    private Date createdAt;
    //userID
    private String createdBy;
    private Date startsAt;
    @Column(name = "duration")
    private Duration duration;
    private boolean isReleasedToStudents;
}

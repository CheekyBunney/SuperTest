package edu.curtin.i3.superlab.service.rsync;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.rsync.SSHUser;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

public interface RsyncUserService {
    SSHUser createRsyncSSHUser(UUID assessment, User user) throws IOException, InterruptedException;

    void deleteRsyncSSHUser(String username) throws IOException, InterruptedException;

    boolean doesRsyncSSHUserExist(String username) throws InterruptedException, IOException;

    void addFolderPrivilegesToUser(String username, Path folder) throws IOException, InterruptedException;

    List<String> listRsyncSSHUsers() throws IOException, InterruptedException;

    List<String> listRsyncSSHUsersByAssessment(UUID assessment);
}

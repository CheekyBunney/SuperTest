package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Repository
public class StudentAssessmentFileRepositoryImpl extends AbstractFileRepository implements StudentAssessmentFileRepository {

    @Value("${super_lab.file_store.student_assessment}")
    private Path studentAssessmentFileStore;

    /**
     *  life cycle
     */
    @PostConstruct
    public void initialise() throws IOException {
        createDirectoryIfItDoesNotExist(this.studentAssessmentFileStore);
    }

    @Override
    public Path createWorkFolder(UUID assessment, User user) throws IOException {
        Path workFolder = this.getWorkFolderPath(assessment, user);
        createDirectoryIfItDoesNotExist(workFolder);
        return workFolder;
    }

    private Path getWorkFolderPath(UUID assessment, User user){
        return Paths.get(this.studentAssessmentFileStore.toString(), assessment.toString(), user.getId());
    }

}

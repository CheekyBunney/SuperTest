package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.resource.*;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.Response;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UsersResource usersResource;

    @Autowired
    RealmResource realmResource;

    @Override
    public List<User> listUsers() {
        return usersResource.list().stream().map(User::new).collect(Collectors.toList());
    }

    @Override
    public User getUser(int curtinId) {
        UserRepresentation userRepresentation = getUserRepresentation(curtinId);
        if (userRepresentation == null) {
            return null;
        }
        return new User(userRepresentation);
    }

    @Override
    public User getUser(String userUuid) {
        UserResource userResource = usersResource.get(userUuid);
        UserRepresentation userRepresentation = userResource.toRepresentation();
        if(userRepresentation == null){
            return null;
        }
        return new User(userRepresentation);
    }

    @Override
    public User getUser(Principal principal) {
        KeycloakAuthenticationToken keycloakAuthenticationToken = (KeycloakAuthenticationToken) principal;
        AccessToken accessToken = keycloakAuthenticationToken.getAccount().getKeycloakSecurityContext().getToken();
        return this.getUser(Integer.parseInt(accessToken.getPreferredUsername()));
    }

    @Override
    public User createUser(Signup signup, String role) throws SignupException {
        //create user representation for keycloak
        UserRepresentation user = new UserRepresentation();
        user.setEnabled(true);
        user.setUsername(Integer.toString(signup.getCurtinId()));
        user.setFirstName(signup.getFirstName());
        user.setLastName(signup.getLastName());
        user.setEmail(signup.getEmail());

        //try and create the user
        Response response = usersResource.create(user);
        //judge the response to see if creat worked
        if (response.getStatus() == 201) {

            String userId = CreatedResponseUtil.getCreatedId(response);
            log.info("Created userId {}, for email {}", userId, user.getEmail());

            // create password credential
            CredentialRepresentation passwordCred = new CredentialRepresentation();
            passwordCred.setTemporary(false);
            passwordCred.setType(CredentialRepresentation.PASSWORD);
            passwordCred.setValue(signup.getPassword());

            UserResource userResource = usersResource.get(userId);

            // Set password credential
            userResource.resetPassword(passwordCred);

            // Get realm role student
            RolesResource roles = realmResource.roles();
            RoleRepresentation realmRoleUser = roles.get(role).toRepresentation();
            RoleRepresentation realmRoleStudent = roles.get("USER").toRepresentation();
            // Assign realm role student to user
            userResource.roles().realmLevel().add(Arrays.asList(realmRoleUser, realmRoleStudent));
            return new User(userResource.toRepresentation());
        } else {
            String signupErrorMessage = "Signup failed with status: " + response.getStatus() + " and reason: " + response.getStatusInfo() + " for email: " + user.getEmail();
            log.error(signupErrorMessage);
            throw new SignupException(signupErrorMessage);
        }
    }

    @Override
    public void deleteUser(String id) {
        usersResource.delete(id);
    }

    @Override
    public void updateUser(String id, String curtinId, String firstName, String lastName, String email, String role) {
        throw new UnsupportedOperationException("not written yet");
    }

    @Override
    public User createStudent(int curtinId) {
        throw new UnsupportedOperationException("this method will be implemented in the  student signup ticket");
    }

    @Override
    public User createInvigilator(int curtinId) {
        throw  new UnsupportedOperationException("this method will be impleneted in the uc signup ticket");
    }

    @Override
    public Set<String> getRoles(int curtinID) {
        RoleMappingResource roleMappingResource = this.usersResource.get(Integer.toString(curtinID)).roles();
        return roleMappingResource.realmLevel().listAll().stream().map(RoleRepresentation::toString).collect(Collectors.toSet());
    }

    @Override
    public void resetPassword(User user, String newPassword) {
        UserResource userResource = usersResource.get(user.getId());
        CredentialRepresentation passwordCred = new CredentialRepresentation();
        passwordCred.setTemporary(false);
        passwordCred.setType(CredentialRepresentation.PASSWORD);
        passwordCred.setValue(newPassword);
        userResource.resetPassword(passwordCred);
    }

    private UserRepresentation getUserRepresentation(int id) {
        List<UserRepresentation> users = usersResource.search(Integer.toString(id), true);
        if(users.isEmpty()){
            return null;
        }
        if(users.size() > 1){
            log.error("User with id: " + id + " has more than 1 account");
        }
        UserRepresentation userRepresentation = users.get(0);
        return userRepresentation;
    }


}

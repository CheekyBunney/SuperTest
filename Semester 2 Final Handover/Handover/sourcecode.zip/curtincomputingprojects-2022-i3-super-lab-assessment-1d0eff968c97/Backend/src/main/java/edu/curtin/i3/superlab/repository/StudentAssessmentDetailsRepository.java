package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StudentAssessmentDetailsRepository extends JpaRepository<StudentAssessmentDetails, UUID> {
    StudentAssessmentDetails findByStudentAndAssessment(String studentUserID, Assessment assessment);

    @Query("SELECT CASE WHEN count(s) > 0 THEN true ELSE false END from StudentAssessmentDetails s WHERE s.assessment.uuid = ?1 AND s.student = ?2")
    boolean existsByAssessmentAndStudent(UUID assessment, String student);

    StudentAssessmentDetails findByAssessmentUuidAndStudent(UUID assessment_uuid, String student);

    List<StudentAssessmentDetails> findByAssessmentUuid(UUID assessment);

    void deleteByAssessmentUuidAndStudent(UUID assessment, String student);

}

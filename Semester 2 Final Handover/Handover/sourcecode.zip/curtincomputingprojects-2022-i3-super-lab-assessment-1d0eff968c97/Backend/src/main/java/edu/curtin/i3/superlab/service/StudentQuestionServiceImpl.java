package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.StudentQuestionCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import edu.curtin.i3.superlab.data.orm.StudentQuestion;
import edu.curtin.i3.superlab.repository.StudentAssessmentDetailsRepository;
import edu.curtin.i3.superlab.repository.StudentQuestionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class StudentQuestionServiceImpl implements StudentQuestionService {

    @Autowired
    private StudentQuestionsRepository studentQuestionsRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    @Override
    public StudentQuestion createStudentQuestion(StudentQuestionCreation questionCreation, User creator) {
        StudentAssessmentDetails studentAssessmentDetails = studentAssessmentDetailsRepository.findByAssessmentUuidAndStudent(questionCreation.getAssessment(), creator.getId());

        StudentQuestion studentQuestion = new StudentQuestion();
        studentQuestion.setStudentAssessmentDetails(studentAssessmentDetails.getUuid());
        studentQuestion.setQuestion(questionCreation.getQuestion());
        studentQuestion.setCreatedAt(new Date());

        return studentQuestionsRepository.saveAndFlush(studentQuestion);
    }

    @Override
    public void resolveQuestion(UUID questionUUID, User resolvedBy){
        StudentQuestion studentQuestion = studentQuestionsRepository.findById(questionUUID).orElse(null);
        if(studentQuestion != null){
            studentQuestion.setResolvedAt(new Date());
            studentQuestion.setResolvedBy(resolvedBy.getId());
            studentQuestionsRepository.saveAndFlush(studentQuestion);
        } else {
            throw new IllegalArgumentException("question does not exist: " + questionUUID);
        }
    }

    @Override
    public StudentQuestion read(UUID questionUUID){
        return studentQuestionsRepository.findById(questionUUID).orElse(null);
    }

    @Override
    public UUID getAssessmentUUIDFromQuestion(UUID questionUUID){
        StudentQuestion question = this.read(questionUUID);
        StudentAssessmentDetails assessmentDetails = studentAssessmentDetailsRepository.findById(question.getStudentAssessmentDetails()).orElse(null);
        return assessmentDetails.getAssessment().getUuid();
    }

    @Override
    public List<StudentQuestion> listQuestions(UUID assessmentUUID) {
        return studentQuestionsRepository.findAllByAssessmentUUID(assessmentUUID);
    }

    @Override
    public List<StudentQuestion> listQuestionsAskedByStudent(UUID assessmentUUID, User student) {
        return studentQuestionsRepository.findAllByStudentAndAssessmentUUID(assessmentUUID, student.getId());
    }

}

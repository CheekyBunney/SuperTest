package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.UCNotificationCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.UCNotification;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.UCNotificationService;
import edu.curtin.i3.superlab.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RequestMapping(value = "/notifications")
@Controller
public class UCNotificationController {

    private static Logger logger = LoggerFactory.getLogger(UCNotificationController.class);

    @Autowired
    private UCNotificationService ucNotificationService;

    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private UserService userService;

    @PreAuthorize("hasRole('ROLE_UC') or hasRole('ROLE_INVIGILATOR')")
    @PutMapping("")
    public ResponseEntity<Void> createUCNotification(@RequestBody UCNotificationCreation ucNotificationCreation, Principal principal){
        User creator = userService.getUser(principal);
        //check that the assignment exists
        boolean assessmentExists = assessmentService.exists(ucNotificationCreation.getAssessment());
        if(!assessmentExists){
            logger.error("user {}: failed to create notification for assessment: {} as it does not exist", creator.getId(), ucNotificationCreation.getAssessment());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //check that creator is part of this assessment
        boolean isValidUserOrUc = assessmentService.isValidUCOrInvigilator(ucNotificationCreation.getAssessment(), creator);
        if(!isValidUserOrUc){
            logger.error("user {}: failed to create notification for assessment: {} as they are not listed as a uc or invigilator on that assessment", creator.getId(), ucNotificationCreation.getAssessment());
            return new ResponseEntity<Void>(HttpStatus.FORBIDDEN);
        }
        //create the notification
        logger.trace("user {}: created notification for assessment :{}", creator.getId(), ucNotificationCreation.getAssessment());
        ucNotificationService.createUCNotification(ucNotificationCreation, creator);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_USER')")
    @GetMapping("/list/{assessment}")
    public ResponseEntity<List<UCNotification>> listUCNotifications(@PathVariable UUID assessment, Principal principal){
        User user = userService.getUser(principal);
        //check that the assessment exists
        boolean assessmentExists = assessmentService.exists(assessment);
        if(!assessmentExists){
            logger.error("user {}: failed to retrieve notifications for assessment: {} as it does not exist", user.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //check that the user is somehow connected to this assessment
        boolean canAccessAssessment = assessmentService.isValidUser(assessment, user);
        if(!canAccessAssessment){
            logger.error("user {}: failed to retrieve notifications for assessment: {} as they are not related to the assessment", user.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        logger.trace("retrieving uc notifications for assessment {}", assessment);
        List<UCNotification> ucNotifications = ucNotificationService.listUCNotification(assessment);
        return new ResponseEntity<List<UCNotification>>(ucNotifications, HttpStatus.OK);
    }
}

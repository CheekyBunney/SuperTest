/**
 * This package-info allows to map Duration objects to the postgresql interval class, without repeating it in every class
 */
@TypeDef(name = "interval", defaultForType = Duration.class, typeClass = PostgreSQLIntervalType.class)
package edu.curtin.i3.superlab.data.orm;

import com.vladmihalcea.hibernate.type.interval.PostgreSQLIntervalType;
import org.hibernate.annotations.TypeDef;
import java.time.Duration;
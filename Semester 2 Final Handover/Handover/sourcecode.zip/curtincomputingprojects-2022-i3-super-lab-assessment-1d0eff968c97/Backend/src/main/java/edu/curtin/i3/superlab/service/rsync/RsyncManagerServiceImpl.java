package edu.curtin.i3.superlab.service.rsync;

import edu.curtin.i3.superlab.data.rsync.RsyncConnection;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.rsync.SSHUser;
import edu.curtin.i3.superlab.repository.StudentAssessmentFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class RsyncManagerServiceImpl implements RsyncManagerService {

    @Value("${server.rsync_host}")
    private String host;

    @Value("${server.rsync_port}")
    private int rsyncPort;

    @Autowired
    private RsyncUserService rsyncUserService;

    @Autowired
    private StudentAssessmentFileRepository studentAssessmentFileRepository;


    @Override
    public RsyncConnection createConnection(User user, UUID assessment) throws IOException, InterruptedException {
        //create user
        SSHUser sshUser = rsyncUserService.createRsyncSSHUser(assessment, user);
        //create folder
        Path workFolder = studentAssessmentFileRepository.createWorkFolder(assessment, user);
        rsyncUserService.addFolderPrivilegesToUser(sshUser.getUsername(), workFolder);
        //create object
        RsyncConnection rsyncConnection = new RsyncConnection();
        rsyncConnection.setUser(sshUser);
        rsyncConnection.setServer(host);
        rsyncConnection.setPort(rsyncPort);
        rsyncConnection.setDirectory(workFolder);
        return rsyncConnection;
    }

    @Override
    public void removeConnection(UUID connectionUID) {

    }

    @Override
    public List<RsyncConnection> listConnections() {
        return null;
    }

    @Override
    public List<RsyncConnection> listConnections(UUID assessment) {
        return null;
    }

}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.InvigilatorAssessmentDetails;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import edu.curtin.i3.superlab.repository.AssessmentFileRepository;
import edu.curtin.i3.superlab.repository.AssessmentRepository;
import edu.curtin.i3.superlab.repository.InvigilatorAssessmentDetailsRepository;
import edu.curtin.i3.superlab.repository.StudentAssessmentDetailsRepository;
import edu.curtin.i3.superlab.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class AssessmentServiceImpl implements AssessmentService {


    @Autowired
    private AssessmentRepository assessmentRepository;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    @Autowired
    private StudentAssessmentDetailsService studentAssessmentDetailsService;

    @Autowired
    private InvigilatorAssessmentDetailsService invigilatorAssessmentDetailsService;


    @Autowired
    private AssessmentFileRepository assessmentFileRepository;

    @Override
    public List<Assessment> listAssessmentByUC(User uc) {
        return this.assessmentRepository.findAssessmentsByCreatedBy(uc.getId());
    }

    @Override
    public List<Assessment> listAssessmentsByStudent(User student) {
        return this.assessmentRepository.findAllByStudentUUID(student.getId());
    }

    @Override
    public boolean exists(UUID assessment) {
        return this.assessmentRepository.existsById(assessment);
    }

    @Override
    public InputStreamResource getAssessmentFilesZip(UUID assessmentUUID) throws IOException {
        return new InputStreamResource(this.assessmentFileRepository.getZipOfAssessmentFile(assessmentUUID));
    }


    /***
     *  to check if a user is part of assessments
     */
    @Override
    public boolean isValidUC(UUID assessmentUUID, User userToCheck) {
        return this.assessmentRepository.existsByUuidAndCreatedBy(assessmentUUID, userToCheck.getId());
    }


    @Override
    public boolean isValidStudent(UUID assessmentUUID, User userToCheck) {
        return this.studentAssessmentDetailsRepository.existsByAssessmentAndStudent(assessmentUUID, userToCheck.getId());
    }

    @Override
    public boolean isValidUCOrInvigilator(UUID assessmentUUID, User userToCheck) {
        return this.isValidUC(assessmentUUID, userToCheck) || invigilatorAssessmentDetailsService.isValidInvigilator(assessmentUUID, userToCheck);
    }

    @Override
    public boolean isValidUser(UUID assessmentUUID, User userToCheck) {
        return this.isValidUCOrInvigilator(assessmentUUID, userToCheck) || this.isValidStudent(assessmentUUID, userToCheck);
    }

    @Override
    public boolean isAssessmentRunning(UUID assessment) {

        Assessment assessment1 = this.assessmentRepository.findById(assessment).orElseThrow(() -> new IllegalArgumentException("assessment doesnt exist"));
        Date now = new Date();
        Date endTime = DateUtil.addDuration(assessment1.getStartsAt(), assessment1.getDuration());
        boolean isGreaterThanOrEqualToStart = now.after(assessment1.getStartsAt()) || assessment1.getStartsAt().equals(now);
        boolean isLessThanEndTime = now.before(endTime);
        return  isGreaterThanOrEqualToStart && isLessThanEndTime;
    }


    @Override
    public Assessment createAssessment(User uc, AssessmentCreation assessmentCreation) throws IOException {

        Assessment assessment = assessmentCreationToAssessment(uc, assessmentCreation);
        //create assessment
        assessment = assessmentRepository.saveAndFlush(assessment);
        //create supporting tables
        studentAssessmentDetailsService.createStudentAssessmentDetails(assessment, assessmentCreation.getStudents());
        invigilatorAssessmentDetailsService.createInvigilatorAssessmentDetails(assessment, assessmentCreation.getInvigilators());
        //save files
        for(MultipartFile file : assessmentCreation.getFiles()){
            assessmentFileRepository.saveAssessmentFile(assessment, file);
        }
        assessmentFileRepository.createZipOfAssessmentFiles(assessment);
        return assessment;
    }

    @Override
    public Assessment updateAssessment(UUID assessmentUUID, User uc, AssessmentCreation assessmentCreation, boolean updateFiles) throws IOException {
        //get the old assessment
        Assessment oldAssessment = assessmentRepository.findById(assessmentUUID).orElseThrow(() -> new IllegalArgumentException("assessment cant be updated as it does not exist"));
        //convert the assessment creation obj to assessment
        Assessment assessment = assessmentCreationToAssessment(uc, assessmentCreation);
        //set the uuid
        assessment.setUuid(assessmentUUID);
        //update the assessment
        assessment = assessmentRepository.save(assessment);

        //update supporting tables
        studentAssessmentDetailsService.updatedStudentsInAssessment(oldAssessment, assessmentCreation.getStudents());
        invigilatorAssessmentDetailsService.updatedInvigilatorsInAssessment(oldAssessment, assessmentCreation.getInvigilators());

        //update files
        if(updateFiles){
            assessmentFileRepository.deleteAssessmentFiles(assessment);
            for(MultipartFile file : assessmentCreation.getFiles()){
                assessmentFileRepository.saveAssessmentFile(assessment, file);
            }
            assessmentFileRepository.createZipOfAssessmentFiles(assessment);
        }
        return assessment;
    }

    /** HElPER **/

    private Assessment assessmentCreationToAssessment(User uc, AssessmentCreation assessmentCreation) {
        Assessment assessment = new Assessment();
        assessment.setName(assessmentCreation.getName());
        assessment.setUnitCode(assessmentCreation.getUnitCode());
        assessment.setCreatedAt(new Date());
        assessment.setCreatedBy(uc.getId());
        assessment.setStartsAt(assessmentCreation.getStartsAt());
        assessment.setDuration(assessmentCreation.getDuration());
        assessment.setReleasedToStudents(false);
        return assessment;
    }
}
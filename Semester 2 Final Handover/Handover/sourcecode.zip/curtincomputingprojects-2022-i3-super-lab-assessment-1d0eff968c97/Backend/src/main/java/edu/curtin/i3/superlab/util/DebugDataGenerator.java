package edu.curtin.i3.superlab.util;

import edu.curtin.i3.superlab.data.dto.Signup;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.SignupException;
import edu.curtin.i3.superlab.data.orm.*;
import edu.curtin.i3.superlab.repository.*;
import edu.curtin.i3.superlab.service.UserService;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Component
@ConditionalOnProperty(name = "super_lab.create_debug_data")
public class DebugDataGenerator {

    private static Logger logger = LoggerFactory.getLogger(DebugDataGenerator.class);
    private static int STUDENT1_ID = 18457890;
    private static int STUDENT2_ID = 12152830;
    private static int STUDENT3_ID = 12389452;
    private static int STUDENT4_ID = 17520121;
    private static int STUDENT5_ID = 18906353;
    private static int STUDENT6_ID = 12321452;

    private static int UC1_ID = 11311921;
    private static int UC2_ID = 10236121;
    private static int UC3_ID = 10110111;

    private static int INVIGILATOR1_ID = 11311925;
    private static int INVIGILATOR2_ID = 10254227;

    //UCS
    private User uc1;
    private User uc2;
    private User uc3;

    //Invigilators
    private User invigilator1;
    private User invigilator2;

    //Students
    private User student1;
    private User student2;
    private User student3;
    private User student4;
    private User student5;
    private User student6;

    //Assessments
    private Assessment pastAssessment1;
    private Assessment pastAssessment2;
    private Assessment pastAssessment3;
    private Assessment futureAssessment1;
    private Assessment futureAssessment2;
    private Assessment futureAssessment3;

    //Assessment students
    private User[] futureAssessment1Students;
    private User[] futureAssessment2Students;
    private User[] futureAssessment3Students;
    private User[] pastAssessment1Students;
    private User[] pastAssessment2Students;
    private User[] pastAssessment3Students;

    //Assessment invigilators
    private User[] futureAssessment1Invigilators;
    private User[] futureAssessment2Invigilators;
    private User[] futureAssessment3Invigilators;
    private User[] pastAssessment1Invigilators;
    private User[] pastAssessment2Invigilators;
    private User[] pastAssessment3Invigilators;

    @Autowired
    private UserService userService;

    @Autowired
    private AssessmentRepository assessmentRepository;
    @Autowired
    private DurationModificationsRepository durationModificationsRepository;
    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;
    @Autowired
    private InvigilatorAssessmentDetailsRepository invigilatorAssessmentDetailsRepository;
    @Autowired
    private StudentQuestionsRepository studentQuestionsRepository;
    @Autowired
    private UCNotificationRepository ucNotificationRepository;
    @Autowired
    private AssessmentFileRepository assessmentFileRepository;


    @PostConstruct
    public void init() throws SignupException, IOException {
        logger.info("Running DebugDataGenerator");
        initUsers();
        initAssessments();
    }

    /**
     * Main initiations
     */

    private void initUsers() throws SignupException {
        initStudents();
        initInvigilators();
        initUCs();

        futureAssessment1Students = new User[]{student1, student2, student3, student4};
        futureAssessment2Students = new User[]{student1, student6, student5, student4, student2};
        futureAssessment3Students = new User[]{student1, student2};
        pastAssessment1Students = new User[]{student2, student4, student6};
        pastAssessment2Students = new User[]{student1, student2, student4, student6};
        pastAssessment3Students = new User[]{student1, student2, student5};

        //Assessment invigilators
        futureAssessment1Invigilators = new User[]{invigilator1};
        futureAssessment2Invigilators = new User[]{invigilator1, invigilator2, uc2}; //an assessment can have a uc invigilator
        futureAssessment3Invigilators = new User[]{}; //an assessment can have no invigilators
        pastAssessment1Invigilators = new User[]{uc1, invigilator2};
        pastAssessment2Invigilators = new User[]{};
        pastAssessment3Invigilators = new User[]{invigilator1, invigilator2};

    }

    private void initStudents() throws SignupException {

        student1 = createUser("student", "1", "STUDENT", STUDENT1_ID);
        student2 = createUser("student", "2", "STUDENT", STUDENT2_ID);
        student3 = createUser("student", "3", "STUDENT", STUDENT3_ID);
        student4 = createUser("student", "4", "STUDENT", STUDENT4_ID);
        student5 = createUser("student", "5", "STUDENT", STUDENT5_ID);
        student6 = createUser("student", "6", "STUDENT", STUDENT6_ID);
    }

    private void initUCs() throws SignupException {

        uc1 = createUser("uc", "1", "UC", UC1_ID);
        uc2 = createUser("uc", "2", "UC", UC2_ID);
        uc3 = createUser("uc", "3", "UC", UC3_ID);
    }

    private void initInvigilators() throws SignupException {

        invigilator1 = createUser("invigilator", "1", "INVIGILATOR", INVIGILATOR1_ID);
        invigilator2 = createUser("invigilator", "2", "INVIGILATOR", INVIGILATOR2_ID);
    }

    @Transactional
    public void initAssessments() throws IOException {
        if(assessmentRepository.count() > 0){
            logger.info("some assessments already exist, not creating debug assessments");
            return;
        }

        LocalDateTime localDateTime = LocalDateTime.now();

        futureAssessment1 = createAssessment("Example Future Assessment 1", uc1, localDateTime.plusWeeks(5), Duration.ofMinutes(45),false, "COMP1001");
        futureAssessment2 = createAssessment("Example Future Assessment 2", uc1, localDateTime.plusWeeks(2), Duration.ofMinutes(135),false,"COMP1002" );
        futureAssessment3 = createAssessment("Example Future Assessment 3", uc2, localDateTime.plusWeeks(1).plusDays(2), Duration.ofMinutes(60),false,"COMP1003");
        pastAssessment1 = createAssessment("Example Past Assessment 1", uc2, localDateTime.minusWeeks(1), Duration.ofMinutes(30),true,"COMP1004");
        pastAssessment2 = createAssessment("Example Past Assessment 2", uc3, localDateTime.minusWeeks(3), Duration.ofMinutes(115),false,"COMP1005");
        pastAssessment3 = createAssessment("Example Past Assessment 3", uc3, localDateTime.minusWeeks(3), Duration.ofMinutes(60),true,"COMP1006");

        initStudentAssessmentDetails();
        initInvigilatorAssessmentDetails();
        initDurationModification();
        initStudentQuestions();
        initUCNotifications();
        initAssessmentFiles();
    }

    private void initAssessmentFiles() throws IOException {
        assessmentFileRepository.saveAssessmentFile(futureAssessment1, getMockFile("futureAssessmentFile1.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(futureAssessment1, getMockFile("futureAssessmentFile1-2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(futureAssessment2, getMockFile("futureAssessmentFile2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(futureAssessment2, getMockFile("futureAssessmentFile2-2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(futureAssessment3, getMockFile("futureAssessmentFile3.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(futureAssessment3, getMockFile("futureAssessmentFile3-2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment1, getMockFile("pastAssessmentFile1.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment1, getMockFile("pastAssessmentFile1-2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment2, getMockFile("pastAssessmentFile2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment2, getMockFile("pastAssessmentFile2-2.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment3, getMockFile("pastAssessmentFile3.txt", "testdata"));
        assessmentFileRepository.saveAssessmentFile(pastAssessment3, getMockFile("pastAssessmentFile3-2.txt", "testdata"));

        assessmentFileRepository.createZipOfAssessmentFiles(futureAssessment1);
        assessmentFileRepository.createZipOfAssessmentFiles(futureAssessment2);
        assessmentFileRepository.createZipOfAssessmentFiles(futureAssessment3);
        assessmentFileRepository.createZipOfAssessmentFiles(pastAssessment1);
        assessmentFileRepository.createZipOfAssessmentFiles(pastAssessment2);
        assessmentFileRepository.createZipOfAssessmentFiles(pastAssessment3);

    }

    private void initStudentAssessmentDetails(){
        if(studentAssessmentDetailsRepository.count() > 0){
            logger.info("some studentAssessmentDetails already exist, not creating debug studentAssessmentDetails");
            return;
        }

        //future assessment1
        Date[] futureAssessment1FinishTime  = {null, null, null, null};
        createStudentAssessmentDetails(futureAssessment1Students, futureAssessment1, futureAssessment1FinishTime);
        //future assessment2
        Date[] futureAssessment2FinishTime  = {null, null, null, null, null};
        createStudentAssessmentDetails(futureAssessment2Students, futureAssessment2, futureAssessment2FinishTime);
        //future assessment3
        Date[] futureAssessment3FinishTime  = {null, null};
        createStudentAssessmentDetails(futureAssessment3Students, futureAssessment3, futureAssessment3FinishTime);
        //past assessment1
        Date[] pastAssessment1FinishTime = {
                DateUtil.addMins(pastAssessment1.getStartsAt(), pastAssessment1.getDuration().toMinutes() - 10),
                DateUtil.addMins(pastAssessment1.getStartsAt(), pastAssessment1.getDuration().toMinutes() - 5),
                DateUtil.addMins(pastAssessment1.getStartsAt(), pastAssessment1.getDuration().toMinutes() - 1)
        };
        createStudentAssessmentDetails(pastAssessment1Students, pastAssessment1, pastAssessment1FinishTime);
        //past assessment2
        Date[] pastAssessment2FinishTime = {
                DateUtil.addMins(pastAssessment2.getStartsAt(), pastAssessment2.getDuration().toMinutes() - 20),
                DateUtil.addMins(pastAssessment2.getStartsAt(), pastAssessment2.getDuration().toMinutes() - 7),
                DateUtil.addMins(pastAssessment2.getStartsAt(), pastAssessment2.getDuration().toMinutes() - 2),
                DateUtil.addMins(pastAssessment2.getStartsAt(), pastAssessment2.getDuration().toMinutes() - 1)
        };
        createStudentAssessmentDetails(pastAssessment2Students, pastAssessment2, pastAssessment2FinishTime);
        //past assessment3
        Date[] pastAssessment3FinishTime = {
                DateUtil.addMins(pastAssessment3.getStartsAt(), pastAssessment3.getDuration().toMinutes() - 15),
                DateUtil.addMins(pastAssessment3.getStartsAt(), pastAssessment3.getDuration().toMinutes() - 2),
                DateUtil.addMins(pastAssessment3.getStartsAt(), pastAssessment3.getDuration().toMinutes() - 0)
        };
        createStudentAssessmentDetails(pastAssessment3Students, pastAssessment3, pastAssessment3FinishTime);
    }

    private void initInvigilatorAssessmentDetails(){
        createInvigilatorAssessmentDetails(futureAssessment1, futureAssessment1Invigilators);
        createInvigilatorAssessmentDetails(futureAssessment2, futureAssessment2Invigilators);
        createInvigilatorAssessmentDetails(futureAssessment3, futureAssessment3Invigilators);
        createInvigilatorAssessmentDetails(pastAssessment1, pastAssessment1Invigilators);
        createInvigilatorAssessmentDetails(pastAssessment2,  pastAssessment2Invigilators);
        createInvigilatorAssessmentDetails(pastAssessment3, pastAssessment3Invigilators);
    }

    private void initDurationModification(){
        if(durationModificationsRepository.count() > 0){
            logger.info("some durationModifications already exist, not creating debug durationModifications");
            return;
        }
        createDurationModification(student2, pastAssessment1, "Extension for good reason",10, 5);
        createDurationModification(student2, pastAssessment1, "Second Extension for good reason",32, -20);
        createDurationModification(student4, pastAssessment1, "other reason", 21, -40);
        createDurationModification(student1, pastAssessment2, "Because, I said so",30, 10);
        createDurationModification(student1, pastAssessment3, " WHY NOT????",50, 20);
    }

    private void initStudentQuestions(){
        if(studentQuestionsRepository.count() > 0){
            logger.info("some studentQuestions already exist, not creating debug studentQuestions");
            return;
        }
        createStudentQuestions(student2, uc1, pastAssessment1, "heLLO HELP PLEASE", 5, 20);
        createStudentQuestions(student2, null, pastAssessment1, "There is a fire in the hall!!!", 7, null);
        createStudentQuestions(student1, invigilator1 ,pastAssessment3, "what is the answerw to question2?", 10, 7);
    }

    private void initUCNotifications(){
        if(ucNotificationRepository.count() > 0){
            logger.info("some ucNotifications already exist, not creating debug ucNotification");
            return;
        }
        createUCNotification(uc1, pastAssessment1, "good luck please begin", 1);
        createUCNotification(uc1, pastAssessment1, "there is a fire in the hall, please leave imediately", 8);
        createUCNotification(invigilator1, pastAssessment3, "please do not ask for the answer to questions", 20);
    }

    /**
     * Helper functions
     */
    public User createUser(String firstName, String lastName, String role, int curtinId) throws SignupException {
        User existingUser = userService.getUser(curtinId);
        if(existingUser != null){
            return existingUser;
        }

        Signup signup = new Signup();
        signup.setEmail(curtinId + "@" + role + ".curtin.edu.au");
        signup.setFirstName(firstName);
        signup.setLastName(lastName);
        signup.setCurtinId(curtinId);
        signup.setPassword(firstName);
        return userService.createUser(signup, role);
    }

    public Assessment createAssessment(String name, User uc, LocalDateTime startsAt, Duration duration, boolean isReleasedToStudents, String unitCode){
        LocalDateTime localDateTime = LocalDateTime.now();
        if(localDateTime.isBefore(startsAt)){
            localDateTime = startsAt.minusWeeks(3);
        }
        Assessment assessment = new Assessment();
        assessment.setName(name);
        assessment.setCreatedAt(DateUtil.toDate(localDateTime.minusWeeks(5)));
        assessment.setCreatedBy(uc.getId());
        assessment.setStartsAt(DateUtil.toDate(startsAt));
        assessment.setDuration(duration);
        assessment.setReleasedToStudents(isReleasedToStudents);
        assessment.setUnitCode(unitCode);
        return assessmentRepository.saveAndFlush(assessment);
    }



    private StudentAssessmentDetails createStudentAssessmentDetails(Assessment assessment, User student, Date finishTime) {
        StudentAssessmentDetails studentAssessmentDetails = new StudentAssessmentDetails();
        studentAssessmentDetails.setAssessment(assessment);
        studentAssessmentDetails.setStudent(student.getId());
        studentAssessmentDetails.setFinishTime(finishTime);
        studentAssessmentDetails.setWorkFolderPath("//mock work dir path");
        return studentAssessmentDetailsRepository.save(studentAssessmentDetails);
    }


    private void createStudentAssessmentDetails(User[] students, Assessment assessment, Date[] finishTimes) {
        for (int ii = 0; ii < students.length; ii++) {
            User student = students[ii];
            Date finishTime = finishTimes[ii];
            createStudentAssessmentDetails(assessment, student, finishTime);
        }
    }

    private void createInvigilatorAssessmentDetails(Assessment assessment, User[] inviglators) {
        for(User u : inviglators){
            InvigilatorAssessmentDetails details = new InvigilatorAssessmentDetails();
            details.setAssessment(assessment);
            details.setInvigilator(u.getId());
            invigilatorAssessmentDetailsRepository.save(details);
        }
    }

    private void createDurationModification(User student, Assessment assessment, String reason, int durationMins, int createdAtOffsetMins) {

        StudentAssessmentDetails studentAssessmentDetails = studentAssessmentDetailsRepository.findByStudentAndAssessment(student.getId(), assessment);
        DurationModification durationModification = new DurationModification();
        durationModification.setStudentAssessmentDetails(studentAssessmentDetails.getUuid());
        durationModification.setCreatedBy(assessment.getCreatedBy());
        durationModification.setCreatedAt(DateUtil.addMins(assessment.getStartsAt(), createdAtOffsetMins));
        durationModification.setDuration(Duration.ofMinutes(durationMins));
        durationModification.setReason(reason);
        durationModificationsRepository.save(durationModification);
    }

    private void createStudentQuestions(User student, User invigilatorOrUC, Assessment assessment, String question, int askedTimeInMinAfterStart, Integer answeredTimeInMinAfterStart) {
        StudentAssessmentDetails studentAssessmentDetails = studentAssessmentDetailsRepository.findByStudentAndAssessment(student.getId(), assessment);
        StudentQuestion studentQuestion = new StudentQuestion();
        studentQuestion.setStudentAssessmentDetails(studentAssessmentDetails.getUuid());
        studentQuestion.setQuestion(question);
        studentQuestion.setCreatedAt(DateUtil.addMins(assessment.getStartsAt(), askedTimeInMinAfterStart));
        if(invigilatorOrUC != null){
            studentQuestion.setResolvedBy(invigilatorOrUC.getId());
        }
        if(answeredTimeInMinAfterStart != null){
            studentQuestion.setResolvedAt(DateUtil.addMins(assessment.getStartsAt(), answeredTimeInMinAfterStart));
        }
        studentQuestionsRepository.save(studentQuestion);
    }

    private void createUCNotification(User ucOrInvigilator, Assessment assessment, String message, int askedTimeOffset) {
        UCNotification ucNotification = new UCNotification();
        ucNotification.setAssessment(assessment.getUuid());
        ucNotification.setCreatedBy(ucOrInvigilator.getId());
        ucNotification.setCreatedAt(DateUtil.addMins(assessment.getStartsAt(), askedTimeOffset));
        ucNotification.setMessage(message);
        ucNotificationRepository.save(ucNotification);
    }


    private MultipartFile getMockFile(String fileName, String content) throws IOException {

        Path tempFilePath = Files.createTempFile("i3-super-lab-", ".txt");
        Files.writeString(tempFilePath, content);

        DiskFileItemFactory diskFileItemFactory = new DiskFileItemFactory();
        FileItem item = diskFileItemFactory.createItem(fileName, "text/plain", false, tempFilePath.toFile().getName());
        InputStream is = Files.newInputStream(tempFilePath);
        OutputStream os = item.getOutputStream();
        IOUtils.copy(is, os);
        return new CommonsMultipartFile(item);
    }
}

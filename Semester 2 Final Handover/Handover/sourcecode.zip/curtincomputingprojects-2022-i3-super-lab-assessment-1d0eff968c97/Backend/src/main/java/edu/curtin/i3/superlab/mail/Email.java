package edu.curtin.i3.superlab.mail;

import lombok.Data;

import java.util.Map;

@Data
public class Email {
    //example = "test@gmail.com")
    String to;
    //example = "test@gmail.com")
    String from;
    //example = "Welcome Email ")
    String subject;
    //example = "test-template.html")
    String template;
    /*
        Map of template variables
     */
    Map<String, Object> properties;
}

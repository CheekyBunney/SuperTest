package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.dto.User;

import java.io.IOException;
import java.nio.file.Path;
import java.util.UUID;

public interface StudentAssessmentFileRepository {
    Path createWorkFolder(UUID assessment, User user) throws IOException;
}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.UCNotificationCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.UCNotification;
import edu.curtin.i3.superlab.repository.UCNotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class UCNotificationServiceImpl implements UCNotificationService {

    @Autowired
    private UCNotificationRepository ucNotificationRepository;

    @Override
    public List<UCNotification> listUCNotification(UUID assessmentUUID){
        return ucNotificationRepository.findAllByAssessment(assessmentUUID);
    }

    @Override
    public void createUCNotification(UCNotificationCreation notificationCreation, User creator){
        UCNotification ucNotification = new UCNotification();
        ucNotification.setAssessment(notificationCreation.getAssessment());
        ucNotification.setCreatedBy(creator.getId());
        ucNotification.setCreatedAt(new Date());
        ucNotification.setMessage(notificationCreation.getMessage());
        ucNotificationRepository.saveAndFlush(ucNotification);
    }
}

package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.StudentQuestionCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.StudentQuestion;
import edu.curtin.i3.superlab.service.AssessmentService;
import edu.curtin.i3.superlab.service.StudentQuestionServiceImpl;
import edu.curtin.i3.superlab.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RequestMapping(value = "/questions")
@Controller
public class StudentQuestionController {

    private static Logger logger = LoggerFactory.getLogger(StudentQuestionController.class);

    @Autowired
    private StudentQuestionServiceImpl studentQuestionService;

    @Autowired
    private UserService userService;

    @Autowired
    private AssessmentService assessmentService;

    @PreAuthorize("hasRole('ROLE_STUDENT')")
    @PutMapping
    public ResponseEntity<Void> createStudentQuestion(@RequestBody StudentQuestionCreation questionCreation, Principal principal){
        User creator = userService.getUser(principal);
        //check that the assignment exists
        boolean assessmentExists = assessmentService.exists(questionCreation.getAssessment());
        if(!assessmentExists){
            logger.error("user {}: failed to create question for assessment: {} as it does not exist", creator.getId(), questionCreation.getAssessment());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //check that student is part of this assessment
        boolean isValidStudent = assessmentService.isValidStudent(questionCreation.getAssessment(), creator);
        if(!isValidStudent){
            logger.error("user {}: failed to create question for assessment: {} as the student is not part of the assessment", creator.getId(), questionCreation.getAssessment());
            return new ResponseEntity<Void>(HttpStatus.FORBIDDEN);
        }
        //create the notification
        studentQuestionService.createStudentQuestion(questionCreation, creator);
        logger.trace("user {}: created notification for assessment :{}", creator.getId(), questionCreation.getAssessment());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_UC') or hasRole('ROLE_INVIGILATOR')")
    @GetMapping("/UC/list/{assessment}")
    public ResponseEntity<List<StudentQuestion>> listQuestionsForUC(@PathVariable UUID assessment, Principal principal){
        User user = userService.getUser(principal);
        //check that assignment exists
        boolean assessmentExists = assessmentService.exists(assessment);
        if(!assessmentExists){
            logger.error("user {}: failed to list question for assessment: {} as it does not exist", user.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //check that uc/invigilator is part of this assessment
        boolean isValidUCorInvig = assessmentService.isValidUCOrInvigilator(assessment, user);
        if(!isValidUCorInvig){
            logger.error("user {}: failed to list questions for assessment: {} as the users is not part of the assessment", user.getId(), assessment);
            return new ResponseEntity<List<StudentQuestion>>(HttpStatus.FORBIDDEN);
        }
        //return list
        List<StudentQuestion> studentQuestions = studentQuestionService.listQuestions(assessment);
        return ResponseEntity.ok(studentQuestions);
    }

    @PreAuthorize("hasRole('ROLE_STUDENT')")
    @GetMapping("/STUDENT/list/{assessment}")
    public ResponseEntity<List<StudentQuestion>> listQuestionsAskedByStudent(@PathVariable UUID assessment, Principal principal){
        User student = userService.getUser(principal);
        //check that the assignment exists
        boolean assessmentExists = assessmentService.exists(assessment);
        if(!assessmentExists){
            logger.error("user {}: failed to list question for assessment: {} as it does not exist", student.getId(), assessment);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //check that student is part of this assessment
        boolean isValidStudent = assessmentService.isValidStudent(assessment, student);
        if(!isValidStudent){
            logger.error("user {}: failed to list questions for assessment: {} as the student is not part of the assessment", student.getId(), assessment);
            return new ResponseEntity<List<StudentQuestion>>(HttpStatus.FORBIDDEN);
        }
        //return list
        List<StudentQuestion> studentQuestions = studentQuestionService.listQuestionsAskedByStudent(assessment, student);
        return ResponseEntity.ok(studentQuestions);
    }

    @PreAuthorize("hasRole('ROLE_UC') or hasRole('ROLE_INVIGILATOR')")
    @PutMapping("/resolve/{question}")
    public ResponseEntity<Void> resolveQuestion(@PathVariable UUID question, Principal principal){
        User user = userService.getUser(principal);
        StudentQuestion studentQuestion = studentQuestionService.read(question);
        if(studentQuestion == null){
            logger.error("user {}: failed to resolve question: {} as it does not exists", user.getId(), question);
            return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
        }
        UUID assessment = studentQuestionService.getAssessmentUUIDFromQuestion(question);
        //check that uc/invigilator is part of this assessment
        boolean isValidUCorInvig = assessmentService.isValidUCOrInvigilator(assessment, user);
        if(!isValidUCorInvig){
            logger.error("user {}: failed to resolve questions for assessment: {} as the users is not part of the assessment", user.getId(), assessment);
            return new ResponseEntity<Void>(HttpStatus.FORBIDDEN);
        }
        //resolve question
        studentQuestionService.resolveQuestion(question, user);
        return new ResponseEntity<Void>(HttpStatus.OK);


    }

}

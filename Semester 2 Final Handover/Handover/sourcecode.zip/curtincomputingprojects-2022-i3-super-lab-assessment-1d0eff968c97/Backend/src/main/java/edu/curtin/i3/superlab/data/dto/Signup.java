package edu.curtin.i3.superlab.data.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Signup extends User{
    private String email;
    private String firstName;
    private String lastName;
    private int curtinId;
    private String password;
}

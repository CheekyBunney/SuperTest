package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.Assessment;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Repository
public class AssessmentFileRepositoryImpl extends AbstractFileRepository implements AssessmentFileRepository {

    @Value("${super_lab.file_store.assessment}")
    private Path assessmentFileStore;

    @Value("${super_lab.file_store.zip}")
    private Path zipFileStore;

    /**
     *  life cycle
     */
    @PostConstruct
    public void initialise() throws IOException {
        createDirectoryIfItDoesNotExist(this.assessmentFileStore);
        createDirectoryIfItDoesNotExist(this.zipFileStore);
    }

    /**
     * Interface Implementation
     */
    @Override
    public void saveAssessmentFile(Assessment assessment, MultipartFile multipartFile) throws IOException {
        Path assessmentDir = getAssessmentFilePath(assessment);
        this.createDirectoryIfItDoesNotExist(assessmentDir);
        Path filePath = Paths.get(assessmentDir.toString(), multipartFile.getOriginalFilename());
        multipartFile.transferTo(filePath);
    }

    @Override
    public void createZipOfAssessmentFiles(Assessment assessment) throws IOException {
        Path assessmentFilePath = getAssessmentFilePath(assessment);
        Path zipOfAssessmentFilesPath = getZipOfAssessmentFilesPath(assessment.getUuid());
        zipFolder(assessmentFilePath, zipOfAssessmentFilesPath);
    }

    @Override
    public InputStream getZipOfAssessmentFile(UUID assessmentUUID) throws IOException {
        Path zipOfAssessmentFilesPath = this.getZipOfAssessmentFilesPath(assessmentUUID);
        if(Files.exists(zipOfAssessmentFilesPath)){
            return Files.newInputStream(zipOfAssessmentFilesPath);
        } else {
            throw new FileNotFoundException("file: " + zipOfAssessmentFilesPath + " not found");
        }
    }

    @Override
    public void deleteAssessmentFiles(Assessment assessment) throws IOException {
        //delete assessment files
        Path assessmentFilePath = getAssessmentFilePath(assessment);
        File assessmentFileFolder = assessmentFilePath.toFile();
        if(assessmentFileFolder.exists()){
            FileUtils.cleanDirectory(assessmentFileFolder);
        }

        //delete zip file
        Path zipOfAssessmentFilesPath = getZipOfAssessmentFilesPath(assessment.getUuid());
        File zipFile = zipOfAssessmentFilesPath.toFile();
        if(zipFile.exists()){
            boolean successfullyDeletedZip = zipFile.delete();
            if(!successfullyDeletedZip){
                throw new IOException("Failed to delete zip file for assessment: " + assessment.getUuid());
            }
        }
    }

    /**
     * Helper
     */

    private Path getAssessmentFilePath(Assessment assessment){
        return Paths.get(this.assessmentFileStore.toString(), assessment.getUuid().toString());
    }

    private Path getZipOfAssessmentFilesPath(UUID assessmentUUID){
        return Paths.get(this.zipFileStore.toString(), assessmentUUID.toString() + ".zip");
    }

}

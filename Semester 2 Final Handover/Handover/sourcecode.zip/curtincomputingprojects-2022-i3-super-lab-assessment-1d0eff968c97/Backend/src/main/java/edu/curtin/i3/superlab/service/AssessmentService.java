package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.AssessmentCreation;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import org.springframework.core.io.InputStreamResource;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface AssessmentService {
    Assessment createAssessment(User uc, AssessmentCreation assessmentCreation) throws IOException;
    Assessment updateAssessment(UUID assessment, User uc, AssessmentCreation assessmentCreation, boolean updateFiles) throws IOException;

    List<Assessment> listAssessmentByUC(User uc);
    List<Assessment> listAssessmentsByStudent(User student);
    boolean exists(UUID assessment);
    InputStreamResource getAssessmentFilesZip(UUID assessmentUUID) throws IOException;

    boolean isValidUC(UUID assessmentUUID, User userToCheck);
    boolean isValidStudent(UUID assessmentUUID, User userToCheck);
    boolean isValidUCOrInvigilator(UUID assessmentUUID, User userToCheck);

    boolean isValidUser(UUID assessmentUUID, User userToCheck);

    boolean isAssessmentRunning(UUID assessment);
}

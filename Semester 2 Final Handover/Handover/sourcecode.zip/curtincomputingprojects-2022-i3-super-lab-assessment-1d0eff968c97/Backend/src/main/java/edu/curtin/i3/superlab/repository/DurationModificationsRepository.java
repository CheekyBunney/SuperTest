package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.DurationModification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface DurationModificationsRepository extends JpaRepository<DurationModification, UUID> {
}

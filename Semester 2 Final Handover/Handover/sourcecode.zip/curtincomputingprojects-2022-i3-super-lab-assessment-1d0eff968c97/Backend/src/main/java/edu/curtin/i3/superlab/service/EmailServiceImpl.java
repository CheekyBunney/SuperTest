package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.mail.Email;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class EmailServiceImpl implements EmailService{

    private static Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${super_lab.mail_admin}")
    private String superLabEmailAddress;


    @Override
    public void sendHtmlMessage(Email email) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
        Context context = new Context();
        context.setVariables(email.getProperties());
        helper.setFrom(email.getFrom());
        helper.setTo(email.getTo());
        helper.setSubject(email.getSubject());
        String html = templateEngine.process(email.getTemplate(), context);
        helper.setText(html, true);
        logger.debug("Sending email: {} with html body: {}", email, html);
        javaMailSender.send(message);
    }

    @Override
    public void sendPasswordResetEmail(String recipientEmail, UUID token) throws MessagingException {
        Email email = new Email();
        email.setTo(recipientEmail);
        email.setFrom(this.superLabEmailAddress);
        email.setSubject("Super Lab Password Reset Token");
        email.setTemplate("passwordReset.html");
        Map<String, Object> templateVariables = new HashMap<>();
        templateVariables.put("token", token.toString());
        email.setProperties(templateVariables);
        this.sendHtmlMessage(email);
    }
}

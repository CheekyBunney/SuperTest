package edu.curtin.i3.superlab.service.rsync;

import edu.curtin.i3.superlab.data.rsync.RsyncConnection;
import edu.curtin.i3.superlab.data.dto.User;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface RsyncManagerService {

    RsyncConnection createConnection(User user, UUID assessment) throws IOException, InterruptedException;
    void removeConnection(UUID connectionUID);
    List<RsyncConnection> listConnections();
    List<RsyncConnection> listConnections(UUID assessment);

}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;
import edu.curtin.i3.superlab.data.orm.StudentAssessmentDetails;
import edu.curtin.i3.superlab.repository.StudentAssessmentDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class StudentAssessmentDetailsServiceImpl implements StudentAssessmentDetailsService {

    @Autowired
    private UserService userService;

    @Autowired
    private StudentAssessmentDetailsRepository studentAssessmentDetailsRepository;

    @Override
    public void createStudentAssessmentDetails(Assessment assessment, Set<Integer> students) {
        for (int st : students) {
            User user = userService.getUser(st);
            //if student doesnt exist create them
            if (user == null) {
                user = userService.createStudent(st);
            }
            StudentAssessmentDetails saDetails = new StudentAssessmentDetails();
            saDetails.setAssessment(assessment);
            saDetails.setStudent(user.getId());
            saDetails.setWorkFolderPath("/");
            this.studentAssessmentDetailsRepository.saveAndFlush(saDetails);

        }
    }

    @Override
    public void updatedStudentsInAssessment(Assessment assessment, Set<Integer> updatedStudentsSet) {
        Set<Integer> currentStudentsIds = studentAssessmentDetailsRepository.findByAssessmentUuid(assessment.getUuid())
                .stream()
                .map((StudentAssessmentDetails::getStudent))
                .map(uuid -> userService.getUser(uuid).getCurtinId())
                .collect(Collectors.toSet());

        Set<Integer> studentsToAdd = filterUnionFromSet(updatedStudentsSet, currentStudentsIds);
        Set<Integer> studentsToDelete = filterUnionFromSet(currentStudentsIds, updatedStudentsSet);

        //add students
        this.createStudentAssessmentDetails(assessment, studentsToAdd);
        //remove students
        this.removeStudentsFromAssessment(assessment, studentsToDelete);
    }

    @Override
    public void removeStudentsFromAssessment(Assessment assessment, Set<Integer> studentsToDelete) {
        for(Integer student : studentsToDelete){
            studentAssessmentDetailsRepository.deleteByAssessmentUuidAndStudent(assessment.getUuid(), Integer.toString(student));
        }
    }

    /**
     * If set A and B have an intersection C.
     * The function returns A - C
     */
    private Set<Integer> filterUnionFromSet(Set<Integer> a, Set<Integer> b) {
        return a.stream().filter(i -> !b.contains(i)).collect(Collectors.toSet());
    }
}

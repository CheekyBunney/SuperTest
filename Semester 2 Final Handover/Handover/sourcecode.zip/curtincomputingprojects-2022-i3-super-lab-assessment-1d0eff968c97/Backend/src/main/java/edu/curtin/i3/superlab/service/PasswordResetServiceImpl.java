package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.PasswordResetToken;
import edu.curtin.i3.superlab.repository.PasswordResetTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.MessagingException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.UUID;

@Service
@Transactional
public class PasswordResetServiceImpl implements PasswordResetService {

    @Value("${super_lab.password_reset_token_duration}")
    private int tokenDuration;

    @Autowired
    private PasswordResetTokenRepository passwordResetTokenRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService;

    @Override
    public void sendPasswordResetTokenEmail(User user) throws MessagingException {
        //if the user has existing tokens delete them
        passwordResetTokenRepository.deleteAllByCreatedBy(user.getId());
        //create the token
        PasswordResetToken passwordResetToken = this.createPasswordResetToken(user);
        //send the token
        emailService.sendPasswordResetEmail(user.getEmail(), passwordResetToken.getToken());
    }

    @Override
    public void resetPassword(User user, String newPassword, UUID passwordResetToken) {
        //find token
        PasswordResetToken token = this.passwordResetTokenRepository.findById(passwordResetToken).orElseThrow(() -> new IllegalArgumentException("token could not be found"));
        //verify that this token was created by the user
        if(!token.getCreatedBy().equals(user.getId())){
            throw new AccessDeniedException("the token provided is not related to the user");
        }
        //delete the token
        this.passwordResetTokenRepository.deleteById(passwordResetToken);
        //reset the password
        this.userService.resetPassword(user, newPassword);
    }

    private PasswordResetToken createPasswordResetToken(User user) {
        PasswordResetToken passwordResetToken = new PasswordResetToken();
        passwordResetToken.setCreatedBy(user.getId());
        passwordResetToken.setExpiryDate(this.getTokenExpiryDate());
        return passwordResetTokenRepository.saveAndFlush(passwordResetToken);
    }


    public Date getTokenExpiryDate(){
        LocalDateTime expiryDate = LocalDateTime.now().plusHours(this.tokenDuration);
        return Date.from(expiryDate.atZone(ZoneId.systemDefault()).toInstant());
    }
}

package edu.curtin.i3.superlab.data.exceptions;

public class SignupException extends Exception{
    public SignupException() {
    }

    public SignupException(String message) {
        super(message);
    }

    public SignupException(String message, Throwable cause) {
        super(message, cause);
    }
}

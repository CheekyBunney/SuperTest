package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Duration;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "duration_modifications")
@Getter
@Setter
@NoArgsConstructor
public class DurationModification {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;

    @Column(name = "student_assessment")
    private UUID studentAssessmentDetails;
    //userID
    private String createdBy;
    private Date createdAt;
    private Duration duration;
    private String reason;

   }

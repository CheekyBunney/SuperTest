package edu.curtin.i3.superlab.data.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@NoArgsConstructor
@Getter
@Setter
public class StudentQuestionCreation {
    private String question;
    private UUID assessment;
}

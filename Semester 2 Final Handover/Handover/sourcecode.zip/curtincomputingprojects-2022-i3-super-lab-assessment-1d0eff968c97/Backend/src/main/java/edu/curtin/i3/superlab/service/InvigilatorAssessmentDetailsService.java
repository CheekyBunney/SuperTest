package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.orm.Assessment;

import java.util.Set;
import java.util.UUID;

public interface InvigilatorAssessmentDetailsService {
    boolean isValidInvigilator(UUID assessmentUUID, User userToCheck);

    void createInvigilatorAssessmentDetails(Assessment assessment, Set<Integer> invigilators);

    void updatedInvigilatorsInAssessment(Assessment assessment, Set<Integer> updatedInvigilatorSet);

    void removeInvigilatorsFromAssessment(Assessment assessment, Set<Integer> invigilatorsToDelete);
}

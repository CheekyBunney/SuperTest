package edu.curtin.i3.superlab.repository;

import edu.curtin.i3.superlab.data.orm.InvigilatorAssessmentDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

@Repository
public interface InvigilatorAssessmentDetailsRepository extends JpaRepository<InvigilatorAssessmentDetails, UUID> {
    @Query("SELECT CASE WHEN count(i) > 0 THEN true ELSE false END FROM InvigilatorAssessmentDetails i WHERE i.assessment.uuid = ?1 AND i.invigilator = ?2")
    boolean existsByAssessmentAndInvigilator(UUID assessment, String invigilator);

    List<InvigilatorAssessmentDetails> findByAssessmentUuid(UUID assessmentUuid);

    void deleteByAssessmentUuidAndInvigilator(UUID assessmentUuid, String invigilator);
}

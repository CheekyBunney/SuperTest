package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "invigilator_assessment_details")
@Getter
@Setter
@NoArgsConstructor
public class InvigilatorAssessmentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;


    @ManyToOne
    @JoinColumn(name = "assessment")
    private Assessment assessment;

    private String invigilator;
}


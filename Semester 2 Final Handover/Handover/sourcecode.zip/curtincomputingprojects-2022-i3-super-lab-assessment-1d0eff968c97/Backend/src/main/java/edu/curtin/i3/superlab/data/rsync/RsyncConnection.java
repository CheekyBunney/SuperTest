package edu.curtin.i3.superlab.data.rsync;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.nio.file.Path;

@Getter
@Setter
@NoArgsConstructor
public class RsyncConnection {
    private SSHUser user;
    private String server;
    private int port;
    private Path directory;

    public String getConnection(){
        return user.getUsername() + "@" + server;
    }
}

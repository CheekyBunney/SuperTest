package edu.curtin.i3.superlab.data.orm;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;
@Entity
@Table(name = "uc_notifications")
@Getter
@Setter
@NoArgsConstructor
public class UCNotification {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID uuid;
    private UUID assessment;
    //userID
    private String createdBy;
    private Date createdAt;
    private String message;
}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.dto.User;

import javax.mail.MessagingException;
import java.util.UUID;

public interface PasswordResetService {
    void sendPasswordResetTokenEmail(User user) throws MessagingException;

    void resetPassword(User user, String newPassword, UUID passwordResetToken);
}

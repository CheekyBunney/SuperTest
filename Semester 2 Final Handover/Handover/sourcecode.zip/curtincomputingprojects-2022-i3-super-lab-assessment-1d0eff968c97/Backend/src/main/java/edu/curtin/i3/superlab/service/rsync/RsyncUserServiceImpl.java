package edu.curtin.i3.superlab.service.rsync;

import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.rsync.SSHUser;
import net.bytebuddy.utility.RandomString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class RsyncUserServiceImpl implements RsyncUserService {

    private static Logger logger = LoggerFactory.getLogger(RsyncUserServiceImpl.class);
    //SL_ for super lab
    private static final String USER_PREFIX = "SL_";
    private File createSSHUserScript;
    private File deleteSSHUserScript;
    private File listSSHUserScript;
    private File doesUserExistScript;
    private File addFolderPrivilegesToUserScript;

    public RsyncUserServiceImpl() throws IOException, InterruptedException {
        this.createSSHUserScript = copyResourcesScriptToTempFile("/scripts/CreateSSHUser.sh");
        this.deleteSSHUserScript = copyResourcesScriptToTempFile("/scripts/DeleteSSHUser.sh");
        this.listSSHUserScript = copyResourcesScriptToTempFile("/scripts/ListSSHUsers.sh");
        this.doesUserExistScript = copyResourcesScriptToTempFile("/scripts/DoesUserExist.sh");
        this.addFolderPrivilegesToUserScript = copyResourcesScriptToTempFile("/scripts/AddFolderPrivilegesToUser.sh");
        makeTmpExecutable();
    }

    @Override
    public SSHUser createRsyncSSHUser(UUID assessment, User user) throws IOException, InterruptedException {
        ProcessBuilder createUserBuilder = new ProcessBuilder();
        String username = getUsername(assessment, user);
        logger.trace("creating user with name {}", username);
        if(this.doesRsyncSSHUserExist(username)){
            logger.trace("user {} already exists, deleting before recreating", user);
            this.deleteRsyncSSHUser(username);
        }

        String password = UUID.randomUUID().toString();
        createUserBuilder.command(createSSHUserScript.getAbsolutePath(), username, password);
        Process createProcess = createUserBuilder.start();
        int exitCode = createProcess.waitFor();
        createProcess.destroy();
        if(exitCode != 0){
            String errorMsg = "failed to create ssh user for user: " + user.getCurtinId() + ", for assessment: " + assessment;
            logger.error(errorMsg);
            throw new IOException(errorMsg);
        } else {
            logger.info("successfully created ssh user {} ", username);
            SSHUser sshUser = new SSHUser();
            sshUser.setUsername(username);
            sshUser.setPassword(password);
            sshUser.setAssessment(assessment);
            return sshUser;
        }
    }

    @Override
    public void deleteRsyncSSHUser(String username) throws IOException, InterruptedException {
        ProcessBuilder deleteUserBuilder = new ProcessBuilder();
        logger.trace("deleting ssh user with id: {}", username);
        deleteUserBuilder.command(deleteSSHUserScript.getAbsolutePath(), username);
        Process deleteProcess = deleteUserBuilder.start();
        int exitCode = deleteProcess.waitFor();
        deleteProcess.destroy();
        if(exitCode != 0){
            String errorMsg = "failed to delete ssh user with username: " + username;
            logger.error(errorMsg);
            throw new IOException(errorMsg);
        } else {
            logger.info("successfully deleted ssh user {}", username);
        }
    }

    @Override
    public boolean doesRsyncSSHUserExist(String username) throws InterruptedException, IOException {
        ProcessBuilder doesUserExistBuilder = new ProcessBuilder();
        logger.trace("checking if user {} exists: ", username);
        doesUserExistBuilder.command(doesUserExistScript.getAbsolutePath(), username);
        Process doesUserExistProcess = doesUserExistBuilder.start();
        //if exit code is 0 the user exists
        return doesUserExistProcess.waitFor() == 0;
    }

    @Override
    public void addFolderPrivilegesToUser(String username, Path folder) throws IOException, InterruptedException {
        ProcessBuilder addFolderPrivilegesBuilder = new ProcessBuilder();
        logger.trace("adding folder privileges for user {} to folder {} exists: ", username, folder.toString());
        addFolderPrivilegesBuilder.command(addFolderPrivilegesToUserScript.getAbsolutePath(), username, folder.toAbsolutePath().toString());
        Process addFolderPrivilegesProcess = addFolderPrivilegesBuilder.start();
        int responseCode = addFolderPrivilegesProcess.waitFor();
        if(responseCode != 0){
            throw new IOException("failed to add folder privileges for user: " + username);
        }
    }


    @Override
    public List<String> listRsyncSSHUsers() throws IOException, InterruptedException {
        ProcessBuilder listUserBuilder = new ProcessBuilder();
        logger.trace("listing ssh users");
        listUserBuilder.command(listSSHUserScript.getAbsolutePath(), USER_PREFIX);
        Process listUsersProcess = listUserBuilder.start();
        List<String> userList = getProcessOutput(listUsersProcess);
        int exitCode = listUsersProcess.waitFor();
        listUsersProcess.destroy();
        if(exitCode != 0){
            String errorMsg = "failed to list users";
            logger.error(errorMsg);
            throw new IOException(errorMsg);
        } else {
            //filter strings for userids todo

            //return users
            return userList;
        }
    }

    @Override
    public List<String> listRsyncSSHUsersByAssessment(UUID assessment) {
        return null;
    }

    private String getUsername(UUID assessment, User user) {
        return USER_PREFIX + assessment.toString() + "_" + user.getCurtinId();
    }

    private List<String> getProcessOutput(Process process) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        List<String> output = new ArrayList<>();
        String line;
        while((line = reader.readLine()) != null){
            output.add(line);
        }
        return output;
    }

    private File copyResourcesScriptToTempFile(String resourceLocation) throws IOException {
        InputStream resourceAsStream = getClass().getResourceAsStream(resourceLocation);
        File tempExport = File.createTempFile("temp_script", ".sh");
        tempExport.deleteOnExit();
        Files.copy(resourceAsStream, tempExport.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return tempExport;
    }

    private void makeTmpExecutable() throws InterruptedException, IOException {
        Process exec = Runtime.getRuntime().exec("chmod -R 777 /tmp/");
        exec.waitFor();
    }




}

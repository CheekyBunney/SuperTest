package edu.curtin.i3.superlab.data.rsync;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class SSHUser {
    private String username;
    private String password;
    private UUID assessment;
}

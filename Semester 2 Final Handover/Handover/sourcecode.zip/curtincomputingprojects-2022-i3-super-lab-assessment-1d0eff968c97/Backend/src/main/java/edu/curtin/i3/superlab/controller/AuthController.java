package edu.curtin.i3.superlab.controller;

import edu.curtin.i3.superlab.data.dto.Login;
import edu.curtin.i3.superlab.data.dto.PasswordResetDTO;
import edu.curtin.i3.superlab.data.dto.User;
import edu.curtin.i3.superlab.data.exceptions.RefreshTokenException;
import edu.curtin.i3.superlab.service.AuthService;
import edu.curtin.i3.superlab.service.PasswordResetService;
import edu.curtin.i3.superlab.service.UserService;
import org.keycloak.common.VerificationException;
import org.keycloak.representations.AccessTokenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import java.security.Principal;

@RequestMapping(value = "/auth")
@Controller
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private PasswordResetService passwordResetService;

    @Autowired
    private UserService userService;

    @PostMapping(path = "/login")
    public ResponseEntity<AccessTokenResponse> signIn(@RequestBody Login login) throws VerificationException {
        AccessTokenResponse response = authService.signIn(login.getCurtinID(), login.getPassword());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@RequestBody String refreshToken) throws ServletException {
        authService.logout(refreshToken);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @PostMapping("/refresh")
    public ResponseEntity<AccessTokenResponse> refreshToken(@RequestBody String refreshToken) {

        try {
            AccessTokenResponse accessTokenResponse = authService.refreshToken(refreshToken);
            return new ResponseEntity<AccessTokenResponse>(accessTokenResponse, HttpStatus.OK);
        } catch (RefreshTokenException e) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
    }

    @PostMapping("/password/reset/sendToken")
    public ResponseEntity<Void> sendPasswordRestWithToken(@RequestBody int curtinId) throws MessagingException {
        User user = userService.getUser(curtinId);
        this.passwordResetService.sendPasswordResetTokenEmail(user);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @PostMapping("/password/reset")
    public ResponseEntity<Void> resetPassword(@RequestBody PasswordResetDTO passwordResetDTO){
        User user = userService.getUser(passwordResetDTO.getCurtinId());
        this.passwordResetService.resetPassword(user, passwordResetDTO.getNewPassword(), passwordResetDTO.getToken());
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

}

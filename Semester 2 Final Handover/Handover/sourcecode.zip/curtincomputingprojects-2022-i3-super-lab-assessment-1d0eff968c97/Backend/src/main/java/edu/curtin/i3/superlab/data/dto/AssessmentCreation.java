package edu.curtin.i3.superlab.data.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ValidationException;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.Duration;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class AssessmentCreation {
    @NotNull
    private String name;
    @NotNull
    private String unitCode;
    @NotNull
    private Date startsAt;
    @NotNull
    private Duration duration;
    @NotEmpty
    private Set<Integer> students;
    private Set<Integer> invigilators;
    private MultipartFile[] files;

    public void validate(){
        if(areInvigilatorAlsoStudents()){
            throw new ValidationException("the assessment creation object contains students that are also invigilators");
        }
        if(!isStartDateIsInFuture()){
            throw new ValidationException("the assessment creation object start date must be in the future");
        }
    }

    private boolean areInvigilatorAlsoStudents() {
        for(int st : students){
            if(invigilators.contains(st)){
                return true;
            }
        }
        return false;
    }

    private boolean isStartDateIsInFuture() {
        return startsAt.after(new Date());
    }
}

package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.exceptions.RefreshTokenException;
import org.keycloak.TokenVerifier;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.common.VerificationException;
import org.keycloak.representations.AccessToken;
import org.keycloak.representations.AccessTokenResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.servlet.ServletException;
import java.util.Set;

@Service
public class AuthServiceImpl implements AuthService {

    private static Logger logger = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    private AuthzClient authzClient;

    @Value("${keycloak.credentials.secret}")
    private String secretKey;
    @Value("${keycloak.resource}")
    private String clientId;
    @Value("${keycloak.auth-server-url}")
    private String authUrl;
    @Value("${keycloak.realm}")
    private String realm;


    @Override
    public AccessTokenResponse signIn(int curtinID, String password) throws VerificationException {
        AccessTokenResponse tokenResponse = authzClient.obtainAccessToken(Integer.toString(curtinID), password);
        return addRolesToAccessTokenResponse(tokenResponse);
    }


    @Override
    public void logout(String refreshToken) throws ServletException {
        //request.logout();
        //this is currently thrown as our keycloak is misconfigured somewhere
        //request.logout should handle the logout but it doesnt invalidate the keycloak session

        //create url
        String logoutUrl = String.format("%s/realms/%s/protocol/openid-connect/logout", authUrl, realm);

        //create form data
        HttpEntity formEntity = getKeyCloakRequestEntity(refreshToken);
        //post
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.exchange(logoutUrl, HttpMethod.POST, formEntity, Object.class);
    }

    @Override
    public AccessTokenResponse refreshToken(String refreshToken) throws RefreshTokenException {
        //create url
        String logoutUrl = String.format("%s/realms/%s/protocol/openid-connect/token", authUrl, realm);
        HttpEntity<MultiValueMap<String, String>> formEntity = getKeyCloakRequestEntity(refreshToken);
        formEntity.getBody().add("grant_type","refresh_token");
        //post
        RestTemplate restTemplate = new RestTemplate();
        try{
            ResponseEntity<AccessTokenResponse> response = restTemplate.exchange(logoutUrl, HttpMethod.POST, formEntity, AccessTokenResponse.class);
            AccessTokenResponse accessTokenResponse = response.getBody();
            return addRolesToAccessTokenResponse(accessTokenResponse);
        } catch (HttpClientErrorException | VerificationException e){
            logger.error("failed to refresh token: " + e.getMessage());
            throw new RefreshTokenException(e.getMessage(), e);
        }
    }

    private AccessTokenResponse addRolesToAccessTokenResponse(AccessTokenResponse accessTokenResponse) throws VerificationException {
        AccessToken token = TokenVerifier.create(accessTokenResponse.getToken(), AccessToken.class).getToken();
        Set<String> roles = token.getRealmAccess().getRoles();
        accessTokenResponse.setOtherClaims("roles", roles);
        return accessTokenResponse;
    }

    private HttpEntity<MultiValueMap<String, String>> getKeyCloakRequestEntity(String refreshToken) {
        //create form data
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", clientId);
        map.add("refresh_token", refreshToken);
        map.add("client_secret", secretKey);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        return new HttpEntity<MultiValueMap<String, String>>(map, headers);
    }

}

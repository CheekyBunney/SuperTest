package edu.curtin.i3.superlab.util;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class DateUtil {

    public static Date toDate(LocalDateTime dateToConvert) {
        return Date.from(dateToConvert.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date addMins(Date date, long mins){
        LocalDateTime localDateTime = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime addedTime = localDateTime.plusMinutes(mins);
        return toDate(addedTime);
    }

    public static Date addDuration(Date date, Duration duration){
        LocalDateTime localDateTime = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime addedTime = localDateTime.plus(duration);
        return toDate(addedTime);
    }


}

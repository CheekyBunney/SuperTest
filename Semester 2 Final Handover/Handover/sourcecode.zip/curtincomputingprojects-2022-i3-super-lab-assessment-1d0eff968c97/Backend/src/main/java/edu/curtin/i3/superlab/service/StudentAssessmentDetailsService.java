package edu.curtin.i3.superlab.service;

import edu.curtin.i3.superlab.data.orm.Assessment;

import java.util.Set;

public interface StudentAssessmentDetailsService {

    void createStudentAssessmentDetails(Assessment assessment, Set<Integer> students);

    void updatedStudentsInAssessment(Assessment assessment, Set<Integer> updatedStudentsSet);

    void removeStudentsFromAssessment(Assessment assessment, Set<Integer> studentsToDelete);
}

<script>

import timerComponent from "@/components/timerComponent";
import FileDownload from "@/components/FileDownload";
import FileService from "../services/file.service"
import NotificationsBarStudent from "@/components/bars/notificationsBar/NotificationsBarStudent";
import { notificationsBarWidth } from "../../../../Commons/NotificationsBar-Commons/state";
import ToastNotificationService from "@/services/toast.notification.service";
import AssessmentService from "@/services/assessment.service";

export default {
  name: "App",

  components: {
    NotificationsBarStudent,
    timerComponent,
    FileDownload
  },

  data() {
    return {
      notificationsBarWidth,
      assessment: null,
      rsyncConnection: null,
      rsyncIntervalSeconds: 30,
      rsyncIntervalFn: null,
      rsyncInProgress:false
    }
  },
  mounted() {
    const assessmentUUID = this.$route.params.assessment
    AssessmentService.getAllAssessments().then(res => {
      this.assessment = res.data.find(a => a.uuid === assessmentUUID);
      this.getRsyncConnection(this.assessment).then(rsyncConnection => {
        this.rsyncConnection = rsyncConnection
        this.startRsyncInterval();
      })
    });
  },
  methods: {
    getRsyncConnection(assessment) {
      return FileService.getRsyncConnection(assessment.uuid).then(res => {
          return res.data;
      }).catch(() => {
        ToastNotificationService.errorNotification("failed to create file sync");
      })

    },
    startRsyncInterval(){
      this.rsyncInterval = setInterval(() => this.runRsync(), this.rsyncIntervalSeconds * 1000)
      //run immediately
      this.runRsync();

    },
    //returns if it ran rsync or not
     runRsync(){
      if(this.rsyncInProgress){
        console.log("didnt run rsync")
        return false
      }
      this.rsyncInProgress = true;
      const workingDir = FileService.getWorkingDirectory();
      const con = this.rsyncConnection;
      console.log("starting rsync process")
      FileService.rsyncWorkingDirectory(con, workingDir).then(() => {
        this.rsyncInProgress = false
        console.log("rsync finished rsync")
       })
      console.log("did run rsync")
      return  true
    },
    doSave() {
      this.runRsync();
      ToastNotificationService.doSaveNotification();
    },
    onRsyncUpdateSuccess(){

    },
    onRsyncError(error){
      console.error(error)
    }

  }

};
</script>


<template>

  <div class="content">

    <!-- main view column -->
    <div
        class="column view-body"
        :style="{ 'margin-right': notificationsBarWidth }">

      <!-- timer component -->
      <div class="timer-component">
        <timerComponent
            v-if="this.assessment != null"
            :assessment="this.assessment"/>
      </div>

      <div class="save-submit-button-tray">
        <b-row>
          <b-col>
            <b-button
                class="oa-buttons"
                variant="outline-primary"
                @click="doSave()"
                pill>
              Save
            </b-button>
          </b-col>

          <b-col>
            <FileDownload
                class="oa-buttons"
                icon="fas fa-folder-open">
            </FileDownload>
          </b-col>

          <b-col>
            <b-button
                class="oa-buttons bg-primary text-white border-0"
                pill
                href="/">
              Submit
            </b-button>
          </b-col>
        </b-row>
      </div>
    </div>

    <!-- notification bar column -->
    <div class="column">
      <NotificationsBarStudent
          :withSession="true"/>
    </div>
  </div>
</template>


<style>

/** { outline: 2px dotted red }*/
/** * { outline: 2px dotted green }*/
/** * * { outline: 2px dotted orange }*/
/** * * * { outline: 2px dotted blue }*/
/** * * * * { outline: 1px solid red }*/
/** * * * * * { outline: 1px solid green }*/
/** * * * * * * { outline: 1px solid orange }*/
/** * * * * * * * { outline: 1px solid blue }*/

body {
  background-color: #fff;
}
.column{
  height: 100%;
  box-sizing: border-box;
}
.view-body{
  height: 100%;
  max-width: 100%;
}
.timer-component{
  margin-bottom: 30%;
}

.save-submit-button-tray{
  width: 100%;
}
.oa-buttons{
  width: 250px;
  transition: 0.2s linear;
  padding: 15px;
}

.content:after {
  content: "";
  display: table;
  clear: both;
}
</style>
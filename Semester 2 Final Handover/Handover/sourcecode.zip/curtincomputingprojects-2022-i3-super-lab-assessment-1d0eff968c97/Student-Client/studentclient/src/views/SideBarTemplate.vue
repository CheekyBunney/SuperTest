<script>

import SideBarStudent from "@/components/bars/sidebar/SideBarStudent";
import { sidebarWidth } from "../../../../Commons/Sidebar-Commons/state";

export default {
  components: { SideBarStudent },
  setup() {
    return { sidebarWidth }
  }
}
</script>


<template>

  <SideBarStudent/>

  <div :style="{ 'margin-left': sidebarWidth }">
    <router-view />
  </div>


</template>

<style>
#nav {
  padding: 30px;
  /*test words*/
}
#nav a {
  font-weight: bold;
  color: #2c3e50;
}
#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
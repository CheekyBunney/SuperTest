<template>
  <div class="login">
    <Form class="login-form bg-secondary rounded" @submit="handleLogin">
      <h1 class="mb-4">Super Test Portal</h1>
      <h4 class="mb-3 font-weight-normal">Please Login</h4>
      <div class="mb-2">
        <Field
            id="curtinID"
            name="curtinID"
            class="form-control"
            placeholder="Enter Curtin id"
            :rules="validateCurtinID"
            v-on:keydown="hideBadLoginMsg"
        ></Field>
        <ErrorMessage class="text-danger" name="curtinID"/>
      </div>
      <div class="mb-2">
        <Field
            id="password"
            name="password"
            class="form-control"
            type="password"
            placeholder="Enter Password"
            :rules="validatePassword"
            v-on:keydown="hideBadLoginMsg"
        ></Field>
        <ErrorMessage class="text-danger" name="password"/>
        <label id="login-failed-lbl" v-if="showBadLoginMsg" class="text-danger">Login failed</label>
      </div>
      <a href="#">Forgot Password</a>
      <b-button class="btn-lg btn-block"  id="submit" type="submit" variant="primary">Log in</b-button>
    </Form>
  </div>
</template>

<script>
import {ErrorMessage, Field, Form} from "vee-validate";
import {validRoles} from "@/router";

export  default {
  components:{
    Form,
    Field,
    ErrorMessage
  },
  data(){
    return {
      showBadLoginMsg: false
    }
  },
  methods:{
    hideBadLoginMsg(){
      this.showBadLoginMsg = false;
    },
    validateCurtinID(curtinID){
      if(this.validateRequired(curtinID)){
        return true;
      } else {
        return "Curtin ID is required"
      }
    },
    validatePassword(password){
      if(this.validateRequired(password)){
        return true;
      } else {
        return "Password is required"
      }
    },
    validateRequired(value){
      return value != null && value.length > 0;
    },
    handleLogin(login){
      this.$store.dispatch("auth/login", { user:login, validRoles:validRoles }).then(
          () => {
            this.$router.push("/");
          },
          (error) => {
            this.showBadLoginMsg = true;
            console.error(error.toString());
          }
      )
    }
  }
}

</script>

<style>
.login{
  align-items: center;
  display: flex;
  height: 100%;
}

.login-form {
  width: 100%;
  max-width: 430px;
  padding: 15px;
  margin: 0 auto;
}

.btn-block {
  display: block;
  width: 100%;
}
</style>
<script>
import AssessmentService from "../services/assessment.service";
import assessmentInfoCard from "@/components/assessmentInfoCard"
import FileService from "../services/file.service"
export default {
  name: "App",

  components: {
    assessmentInfoCard
  },

  data() {
    return {
      assessment: null
    }
  },
  mounted() {
    const assessmentUUID = this.$route.params.assessment

    AssessmentService.getAllAssessments().then(res => {
      this.assessment = res.data.find(a => a.uuid === assessmentUUID);
    });
  },
  methods: {
    startAssessment() {
      FileService.createWorkingDirectory(this.assessment);
      this.$router.push({path:"/assessment/" + this.assessment.uuid});
    }
  }
};
</script>


<template>
  <div>
    <h1 style="color:#507DBC"><u>Pre Assessment Information</u></h1>
  </div>
  <div class="cards">
    <b-row>
      <b-col>
        <b-card no-body="" class="bg-primary border-0 text-center" v-if="this.assessment !== null">
          <assessmentInfoCard :assessment="this.assessment"/>
        </b-card>
      </b-col>
    </b-row>

  </div>
  <div class="cards" >
    <b-card-group deck="">
      <b-card class="bg-light text-secondary border-0">
        <h1> Notes </h1>
        <div>This assessment will be 120 minutes</div>
      </b-card>
      <b-card class="bg-primary my-3 text-white" title="Banned Materials">
        <b-card class="text-secondary bg-tertiary m-2">
          <b-row>
            Programmable Calculators
          </b-row>
        </b-card>

      </b-card>
    </b-card-group>
  </div>


  <b-card
      v-if="this.assessment !== null"
      no-body
      class="start">

    <b-button class="start-button"
              @click="startAssessment()">
      Start
    </b-button>
  </b-card>
</template>

<style>
.cards{
  margin: 15px 300px 15px 300px;
  width: available;
  text-align: left;
  border: 0;

}
.start{
  margin-left: 300px;
  margin-right: 300px;
  width: available;
  border: none;
}
.start-button{
  color: white;
  font-size: 30px;
  border-radius: 20px;
  transition: 0.2s linear;
}
</style>
<template>
  <b-button @click="openFileExplorer()" class="bg-primary text-white border-0" pill>
    <i class="icon" :class="icon"/>
    Open Files
  </b-button>
</template>


<script>
import FileService from "@/services/file.service";
export default{
  props:{
    icon: {type: String, required: true}
  },
  methods:{
    openFileExplorer(){
      const {shell} = window.require('electron');
      console.log(FileService.getWorkingDirectory());
      shell.openPath(FileService.getWorkingDirectory());
    }
  }
}
</script>

<style scoped>
.icon{
  flex-shrink: 0;
  width: 25px;
  margin-right: 10px;
}
</style>
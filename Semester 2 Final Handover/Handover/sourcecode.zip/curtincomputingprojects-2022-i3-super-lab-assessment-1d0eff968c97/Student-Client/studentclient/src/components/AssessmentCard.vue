<script>
import moment from "moment/moment";
import {parse} from "tinyduration";
export default{
  props: ['assessment'],
  methods:{
    formattedTime(){
      return moment(new Date(this.assessment.startsAt)).format('MMMM Do YYYY, h:mm:ss a');
    },
    formattedDuration(){
      const durationStr = parse(this.assessment.duration)
      if (durationStr.hours === undefined){
        return durationStr.minutes + " Minutes ";
      }
      else if (durationStr.minutes === undefined){
        return durationStr.hours + " Hours ";
      }
      else{
        return durationStr.hours + " Hours " + durationStr.minutes + " Minutes "
      }

    }
  }
}
</script>

<template>

  <b-card class="text-secondary bg-tertiary m-2">

    <b-row>
      <b-col>
        {{assessment.name}}
      </b-col>
      <b-col>
        {{assessment.unitCode}}
      </b-col>
      <b-col>
        {{formattedDuration()}}
      </b-col>
      <b-col :set="d=new Date(assessment.startsAt)">
        {{formattedTime()}}
      </b-col>

    </b-row>
  </b-card>




</template>
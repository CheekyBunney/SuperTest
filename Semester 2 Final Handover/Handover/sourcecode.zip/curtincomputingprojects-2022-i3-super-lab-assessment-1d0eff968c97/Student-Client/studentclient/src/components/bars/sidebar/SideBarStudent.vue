<script>
import SidebarLink from '../../../../../../Commons/Sidebar-Commons/SidebarLink'
import { collapsed, toggleSidebar, sidebarWidth } from '../../../../../../Commons/Sidebar-Commons/state'
export default {
  props: {},
  components: { SidebarLink },
  setup() {
    return { collapsed, toggleSidebar, sidebarWidth }
  },
  methods:{
    logout(event){
      this.$store.dispatch('auth/logout');
      event.preventDefault();
    }
  }
}
</script>

<template>
  <div class="sidebar" :style="{ width: sidebarWidth }">
    <h1>
      <span v-if="collapsed">
        S
        T
      </span>
      <span v-else>
        Super
        Test
      </span>
    </h1>

    <SidebarLink to="/" icon="fas fa-home">Home</SidebarLink>
    <SidebarLink @click="logout" to="/login" id="logout-btn" icon="fas fa-sign-out">Logout</SidebarLink>

    <span
        class="collapse-icon"
        :class="{ 'rotate-180': collapsed }"
        @click="toggleSidebar"
    >
      <i class="fas fa-angle-double-left" />
    </span>
  </div>
</template>

<style>
:root {
  --sidebar-bg-color: #8BA9D3;
  --sidebar-item-hover: #3685D3;
  --sidebar-item-active: #507DBC;
}
</style>

<style scoped>
.sidebar {
  color: white;
  background-color: var(--sidebar-bg-color);
  float: right;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  bottom: 0;
  padding: 0.5em;
  transition: 0.3s ease;
  display: flex;
  flex-direction: column;
  border-bottom-right-radius: 20px;
  border-top-right-radius: 20px;
}
.sidebar h1 {
  height: 2.5em;
}
.collapse-icon {
  position: absolute;
  bottom: 0;
  padding: 0.75em;
  color: rgba(255, 255, 255, 0.7);
  transition: 0.2s linear;
}
.rotate-180 {
  transform: rotate(180deg);
  transition: 0.2s linear;
}
</style>
<script>
import moment from 'moment'
import {parse} from "tinyduration";

export default{
  props: ['assessment'],
  methods:{
    formattedTime(){
      return moment(new Date(this.assessment.startsAt)).calendar();
    },
    formattedDuration(){
      const durationStr = parse(this.assessment.duration)
      if (durationStr.hours === undefined){
        return durationStr.minutes + " Minutes ";
      }
      else if (durationStr.minutes === undefined){
        return durationStr.hours + " Hours ";
      }
      else{
        return durationStr.hours + " Hours " + durationStr.minutes + " Minutes "
      }

    }
  }
}
</script>

<template>
  <div class="m-2">
    <div>
        <div class="mb-4">
          <h3 style="color:white">{{assessment.unitCode}}</h3>
          <h3 style="color:white">{{assessment.name}}</h3>
        </div>
    </div>
    <div class="mb-4">
      <h4 style="color:white">Date and Time</h4>
      <div style="color:white">{{formattedTime()}}</div>
    </div>
    <div>
      <h4 style="color:white">Duration</h4>
      <div style="color:white">{{formattedDuration()}}</div>
    </div>
  </div>
</template>


import { createApp } from 'vue'
import '@fortawesome/fontawesome-free/js/all'
import App from './App.vue'
import router from './router'
import store from './store'
import {BootstrapVue3} from 'bootstrap-vue-3'
import  'boostrap-scss/boostrap-custom.scss'
import 'tinyduration'
import 'moment'
import Toast from "vue-toastification"
import "vue-toastification/dist/index.css"
import setupInterceptors from "../../../Commons/axios/setupInterceptors";
setupInterceptors(store);
createApp(App)
    .use(store)
    .use(router)
    .use(BootstrapVue3)
    .use(Toast)
    .mount('#app')

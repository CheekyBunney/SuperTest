import { createStore } from 'vuex'
import {auth} from "../../../../Commons/store/auth.module";

export default createStore({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
    auth
  }
})

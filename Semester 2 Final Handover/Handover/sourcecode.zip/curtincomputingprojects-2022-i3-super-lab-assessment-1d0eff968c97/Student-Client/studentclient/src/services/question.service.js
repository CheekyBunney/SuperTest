
import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";
const API_URL = '/questions';
class QuestionService {

    getQuestions(assessmentUUID){
        return api.get(API_URL + "/STUDENT/list/" + assessmentUUID, { headers: authHeader() });
    }

    createQuestion(question, assessmentUUID){
        return api.put(API_URL, {
            question: question,
            assessment: assessmentUUID
        }, { headers: authHeader() });
    }
}
export default new QuestionService();
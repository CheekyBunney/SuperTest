
import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";
const API_URL = '/assessments/';
class AssessmentService {

    getAllAssessments(){
        return api.get(API_URL + "student/list", { headers: authHeader() });
    }
    getAssessmentFiles(assessmentUUID){
        return api(API_URL + "files/" + assessmentUUID + "/zip",  {
            method:"GET",
            responseType: 'blob',
            headers: authHeader()
        });
    }
}
export default new AssessmentService();
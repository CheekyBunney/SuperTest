
import api from "../../../../Commons/axios/api"
import authHeader from "../../../../Commons/services/auth-header.service";
const API_URL = '/notifications';
class NotificationService {
    getNotifications(assessmentUUID){
        return api.get(API_URL + "/list/" + assessmentUUID, { headers: authHeader() });
    }
}
export default new NotificationService();
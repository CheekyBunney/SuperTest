import {useToast} from "vue-toastification";

class ToastNotificationService{
    doFifteenNotification(toastContent) {
        const toast = useToast();
        toast.info(toastContent, {
            timeout: false,
            pauseOnFocusLoss: false
        });
    }
    doFiveNotification(toastContent) {
        const toast = useToast();
        toast.warning(toastContent, {
            timeout: false,
            pauseOnFocusLoss: false
        });
    }
    doSaveNotification() {
        const toast = useToast();
        toast.info("your work has been saved", {
            timeout: 2000,
            showCloseButtonOnHover: true,
            pauseOnFocusLoss: false
        });
    }
    pushNotification(toastContent){
        const toast = useToast();
        toast.info(toastContent, {
            timeout: false,
            pauseOnFocusLoss: false
        });
    }
    errorNotification(toastContent){
        const toast = useToast();
        toast.error(toastContent, {
            timeout: 2000,
            showCloseButtonOnHover: true,
            pauseOnFocusLoss: false
        })
    }

}

export default new ToastNotificationService();
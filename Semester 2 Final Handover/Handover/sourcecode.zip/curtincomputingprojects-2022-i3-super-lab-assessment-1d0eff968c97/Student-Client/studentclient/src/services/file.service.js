import AssessmentService from "../services/assessment.service"
import {useToast} from "vue-toastification";
import api from "../../../../Commons/axios/api";
import authHeader from "../../../../Commons/services/auth-header.service";
'use strict'
const API_URL = '/rsync';

class FileService{

    fs = window.require('fs');
    path = window.require('path');
    os = window.require('os')
    childProcess = window.require("child_process");

    constructor(){
    }

    getWorkingDirectory()
    {
        return localStorage.getItem('workingDir');
    }
    createWorkingDirectory(assessment) {
        let newPath = this.path.join(this.os.homedir(), "/SuperLabAssessment/", assessment.unitCode + "_" + assessment.name.replaceAll(" ", "_"));
        if (!this.fs.existsSync(newPath))
        {
            this.fs.mkdirSync(newPath, { recursive: true });
        }

        localStorage.setItem('workingDir', newPath);
        AssessmentService.getAssessmentFiles(assessment.uuid).then(response => {
            //
            const output = this.fs.createWriteStream(this.path.join(newPath, 'assessmentFiles.zip'))
            const ws = new WritableStream(output);
            const blobStream = new Blob([response.data], {type: 'application/zip'}).stream()
            blobStream.pipeTo(ws);
            this.notifyOnSuccess("Your assessment files have successfully been downloaded to your desktop, you can access them by clicking the 'Open Files' button or navigating to your desktop");
        }).catch(e => console.error(e))
    }
    getRsyncConnection(assessmentUUID){
        return api.get(API_URL + `/student/connection/${assessmentUUID}`, { headers: authHeader() });
    }
    rsyncWorkingDirectory(rsyncConnection, workingDirectory){
        return new Promise(resolve => {
            var directory = rsyncConnection.directory.replace("file://","");
            var process = this.childProcess.exec(`sshpass -p ${rsyncConnection.user.password} rsync --progress -avz -e 'ssh -p ${rsyncConnection.port} -o StrictHostKeyChecking=no' ${workingDirectory} ${rsyncConnection.connection}:${directory}`, (error, stdout, stderr) => {
                if(error){
                    console.error(`rsync error: ${error}`)
                }
                if(stderr){
                    console.error(`rsync stderr ${stderr}`)
                }
                console.info(`rsync stdout ${stdout}`)
            })
            process.on("exit", () => resolve());
        })

    }

    /**
     * Check that system has the required services
     */
    systemHasService(){

    }

    notifyOnSuccess(toastContent) {
        const toast = useToast();
        toast.info(toastContent, {
            timeout: false,
            pauseOnFocusLoss: false
        })
    }

}

export default new FileService();
import {createRouter, createWebHashHistory} from 'vue-router'

import AuthService from "../../../../Commons/services/auth.service";
import Dashboard from "@/views/DashboardView";
import SideBarTemplate from "@/views/SideBarTemplate";

export var validRoles = ["STUDENT"]

const routes = [
  {
    path: '/login',
    name: "login",
    component: () => import(/* webpackChunkName: "LoginView" */ '../views/LoginView.vue'),
  },
  //WITH SESSION
  {
    path: '/assessment/:assessment',
    name: "with_session",
    component: SideBarTemplate,
    children: [
      {
        path: '',
        name: 'assessment',

        component: () => import('../views/OngoingAssessment')
      },
      {
        path: 'preAssessment',
        name: 'preAssessment',
        component: () => import('../views/PreAssessmentPage')
      }
    ]
  },
  //WITHOUT SESSION
  {
    path: '',
    name: "without_session",
    component: SideBarTemplate,
    children: [
      {
        path: '',
        name: 'dashboard',
        component: Dashboard
      }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const publicPages = ['/login'];
  const authRequired = !publicPages.includes(to.path);
  let roles = AuthService.getRoles();
  const isLoggedIn = roles.filter(r => validRoles.includes(r)).length > 0;
  // trying to access a restricted page + not logged in
  // redirect to login page
  if (authRequired && !isLoggedIn) {
    next('/login');
  } else {
    next();
  }

})
export default router